#ifndef GEMM_ROWMAJOR_NOTRANS_KERNEL_HPP_
#define GEMM_ROWMAJOR_NOTRANS_KERNEL_HPP_
//#include "cpu_runtime.hpp"

enum CPUModel {
  CortexA53,
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, typename Com, int M, int N,
    bool ReA, bool ReB, bool ReC, bool Load, bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel {
};


template <typename Lhs, typename Rhs, typename Res, typename Itm, typename Com, int M, int N, CPUModel Model,
    bool ReA, bool ReB, bool ReC, bool Load, bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernelv2 {
    static void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias);
};



#endif  // GEMM_ROWMAJOR_NOTRANS_KERNEL_HPP_
