#ifndef GEMM_ROWMAJOR_NOTRANS_GEMM_ALGO_HPP_
#define GEMM_ROWMAJOR_NOTRANS_GEMM_ALGO_HPP_

#ifdef __ARM_NEON
#include <arm_neon.h>
#endif
#include <array>
#include <vector>
#include <type_traits>
#include "kernels/1x20.hpp"
#include "kernels/2x20.hpp"
#include "kernels/3x16.hpp"
#include "kernels/4x12.hpp"
#include "kernels/5x12.hpp"
#include "kernels/6x8.hpp"
#include "kernels/7x8.hpp"
#include "kernels/8x8.hpp"
#include "kernels/8x12.hpp"
#include "aligned_allocator.hpp"

namespace gemm_rowmajor_notrans {
#ifdef USE_CXX17

#ifdef __aarch64__

template <typename Lhs, typename Rhs, typename Res, typename Itm, typename Com, CPUModel Model,
    bool ReA, bool ReB, bool ReC, bool Load, bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernelProviderv2 {
  static constexpr int m_size=8;
  static constexpr int n_size[m_size]={20, 20, 16, 12, 12, 8, 8, 8};
  static constexpr int max_n_size=20;
  static constexpr int GetMaxWidth(int m) {
    return n_size[m-1];
  }

  using func=void(*)(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias);
  static constexpr func Get(int m, int n) {
    return kernels[(m-1)*max_n_size+(n-1)];
  }

  static constexpr std::array<func, m_size*max_n_size> kernels={
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1,  1, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1,  2, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1,  3, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1,  4, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1,  5, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1,  6, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1,  7, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1,  8, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1,  9, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1, 10, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1, 11, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1, 12, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1, 13, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1, 14, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1, 15, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1, 16, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1, 17, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1, 18, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1, 19, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 1, 20, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2,  1, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2,  2, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2,  3, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2,  4, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2,  5, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2,  6, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2,  7, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2,  8, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2,  9, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2, 10, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2, 11, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2, 12, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2, 13, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2, 14, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2, 15, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2, 16, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2, 17, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2, 18, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2, 19, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 2, 20, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 3,  1, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 3,  2, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 3,  3, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 3,  4, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 3,  5, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 3,  6, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 3,  7, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 3,  8, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 3,  9, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 3, 10, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 3, 11, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 3, 12, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 3, 13, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 3, 14, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 3, 15, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 3, 16, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 4,  1, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 4,  2, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 4,  3, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 4,  4, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 4,  5, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 4,  6, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 4,  7, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 4,  8, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 4,  9, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 4, 10, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 4, 11, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 4, 12, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 5,  1, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 5,  2, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 5,  3, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 5,  4, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 5,  5, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 5,  6, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 5,  7, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 5,  8, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 5,  9, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 5, 10, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 5, 11, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 5, 12, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 6,  1, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 6,  2, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 6,  3, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 6,  4, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 6,  5, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 6,  6, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 6,  7, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 6,  8, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 7,  1, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 7,  2, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 7,  3, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 7,  4, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 7,  5, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 7,  6, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 7,  7, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 7,  8, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 8,  1, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 8,  2, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 8,  3, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 8,  4, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 8,  5, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 8,  6, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 8,  7, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernel<Lhs, Rhs, Res, Itm, Com, 8,  8, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter>::Run,
      GEMMKernelv2<Lhs, Rhs, Res, Itm, Com, 8,  9, Model, true, true, false, Load, Itm2Res, Blend, false, false, RBias, ReLU, FstIter>::Run,
      GEMMKernelv2<Lhs, Rhs, Res, Itm, Com, 8,  10, Model, true, true, false, Load, Itm2Res, Blend, false, false, RBias, ReLU, FstIter>::Run,
      GEMMKernelv2<Lhs, Rhs, Res, Itm, Com, 8,  11, Model, true, true, false, Load, Itm2Res, Blend, false, false, RBias, ReLU, FstIter>::Run,
      GEMMKernelv2<Lhs, Rhs, Res, Itm, Com, 8,  12, Model, true, true, false, Load, Itm2Res, Blend, false, false, RBias, ReLU, FstIter>::Run,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr,
      nullptr};
};

#endif // USE_CXX17

#endif  // __aarch64__

template <int Height, typename Scalar>
static inline void PackReorderA(
    int rows, int cols, const Scalar* src, const int ld, Scalar* dst) {
  int r=0;
  for(; r<rows-Height+1; r+=Height) {
    for(int c=0; c<cols; c++) {
      for(int rr=r; rr<r+Height; rr++) {
        *(dst++)=*(src+rr*ld+c);
      }
    }
  }
  if(r<rows) {
    for(int c=0; c<cols; c++) {
      for(int rr=r; rr<rows; rr++) {
        *(dst++)=*(src+rr*ld+c);
      }
    }
  }
}

#ifdef __aarch64__
template <>
void PackReorderA <8, float> (
    int rows, int cols, const float* src, const int ld, float* dst) {

  int r = 0;
  const float* src_start = src;
  for( ; r < rows - 7; r += 8) {
    src = src_start;
    int c = 0;
    for( ; c < cols - 3; c += 4) {
      const float* row0 = src;
      const float* row1 = src + ld;
      const float* row2 = src + ld * 2;
      const float* row3 = src + ld * 3;
      const float* row4 = src + ld * 4;
      const float* row5 = src + ld * 5;
      const float* row6 = src + ld * 6;
      const float* row7 = src + ld * 7;
      float32x4_t vr0 = vld1q_f32(row0);
      float32x4_t vr1 = vld1q_f32(row1);
      float32x4_t vr2 = vld1q_f32(row2);
      float32x4_t vr3 = vld1q_f32(row3);
      float32x4_t vr4 = vld1q_f32(row4);
      float32x4_t vr5 = vld1q_f32(row5);
      float32x4_t vr6 = vld1q_f32(row6);
      float32x4_t vr7 = vld1q_f32(row7);
      float32x4_t tr0 = vtrn1q_f32(vr0, vr1);
      float32x4_t tr1 = vtrn1q_f32(vr2, vr3);
      float32x4_t tr2 = vtrn1q_f32(vr4, vr5);
      float32x4_t tr3 = vtrn1q_f32(vr6, vr7);
      float32x4_t tr4 = vtrn2q_f32(vr0, vr1);
      float32x4_t tr5 = vtrn2q_f32(vr2, vr3);
      float32x4_t tr6 = vtrn2q_f32(vr4, vr5);
      float32x4_t tr7 = vtrn2q_f32(vr6, vr7);
      float64x2_t re0 = vtrn1q_f64(vreinterpretq_f64_f32(tr0), vreinterpretq_f64_f32(tr1));
      float64x2_t re1 = vtrn1q_f64(vreinterpretq_f64_f32(tr2), vreinterpretq_f64_f32(tr3));
      float64x2_t re2 = vtrn1q_f64(vreinterpretq_f64_f32(tr4), vreinterpretq_f64_f32(tr5));
      float64x2_t re3 = vtrn1q_f64(vreinterpretq_f64_f32(tr6), vreinterpretq_f64_f32(tr7));
      float64x2_t re4 = vtrn2q_f64(vreinterpretq_f64_f32(tr0), vreinterpretq_f64_f32(tr1));
      float64x2_t re5 = vtrn2q_f64(vreinterpretq_f64_f32(tr2), vreinterpretq_f64_f32(tr3));
      float64x2_t re6 = vtrn2q_f64(vreinterpretq_f64_f32(tr4), vreinterpretq_f64_f32(tr5));
      float64x2_t re7 = vtrn2q_f64(vreinterpretq_f64_f32(tr6), vreinterpretq_f64_f32(tr7));
      vst1q_f32(dst, vreinterpretq_f32_f64(re0));
      dst += 4;
      vst1q_f32(dst, vreinterpretq_f32_f64(re1));
      dst += 4;
      vst1q_f32(dst, vreinterpretq_f32_f64(re2));
      dst += 4;
      vst1q_f32(dst, vreinterpretq_f32_f64(re3));
      dst += 4;
      vst1q_f32(dst, vreinterpretq_f32_f64(re4));
      dst += 4;
      vst1q_f32(dst, vreinterpretq_f32_f64(re5));
      dst += 4;
      vst1q_f32(dst, vreinterpretq_f32_f64(re6));
      dst += 4;
      vst1q_f32(dst, vreinterpretq_f32_f64(re7));
      dst += 4;

      src += 4;
    }

    for ( ; c < cols; c++) {
      for (int rr = 0; rr < 8; rr++) {
        *dst++ = *(src + rr * ld);
      }
      src++;
    }

    src_start += 8 * ld;
  }

  if (r < rows) {
    src = src_start;
    for (int c = 0; c < cols; c++) {
      for (int rr = 0; rr < rows; rr++) {
        *dst++ = *(src + rr * ld + c);
      }
    }
  }
}
#endif

template <int Width, typename Scalar>
static inline void PackBlockReorder(
    int rows, int cols, const Scalar* src, const int ld, Scalar* dst) {
#ifdef __ARM_NEON
  if constexpr (std::is_same<Scalar, float>::value) {
    static_assert(Width % 4 == 0, "max_width must be a multiply of 4!");

    int c = 0;
    int r_remain_start = ((rows >> 2) << 2);
    for ( ; c < cols - Width + 1; c += Width) {
      int r = 0;
      for ( ; r < r_remain_start; r += 4) {
        const Scalar  *src_ptr0 = src + ld * r;
        const Scalar  *src_ptr1 = src + ld * (r+1);
        const Scalar  *src_ptr2 = src + ld * (r+2);
        const Scalar  *src_ptr3 = src + ld * (r+3);
        Scalar  *dst_ptr0 = dst + Width * r;
        Scalar  *dst_ptr1 = dst + Width * (r+1);
        Scalar  *dst_ptr2 = dst + Width * (r+2);
        Scalar  *dst_ptr3 = dst + Width * (r+3);
        for (int cc = 0; cc < Width/4; cc++) {
          float32x4_t vsrc0 = vld1q_f32(src_ptr0);
          float32x4_t vsrc1 = vld1q_f32(src_ptr1);
          float32x4_t vsrc2 = vld1q_f32(src_ptr2);
          float32x4_t vsrc3 = vld1q_f32(src_ptr3);

          vst1q_f32(dst_ptr0, vsrc0);
          vst1q_f32(dst_ptr1, vsrc1);
          vst1q_f32(dst_ptr2, vsrc2);
          vst1q_f32(dst_ptr3, vsrc3);

          src_ptr0 += 4;
          src_ptr1 += 4;
          src_ptr2 += 4;
          src_ptr3 += 4;
          dst_ptr0 += 4;
          dst_ptr1 += 4;
          dst_ptr2 += 4;
          dst_ptr3 += 4;
        }
      } 
      for ( ; r < rows; r++) {
        const Scalar  *src_ptr0 = src + ld * r;
        Scalar  *dst_ptr0 = dst + Width * r;
        for (int cc = 0; cc < Width/4; cc++) {
          float32x4_t vsrc0 = vld1q_f32(src_ptr0);

          vst1q_f32(dst_ptr0, vsrc0);

          src_ptr0 += 4;
          dst_ptr0 += 4;
        }
      }
        src += Width;
        dst += Width * rows;
    }
    if (c < cols) {
        for (int r = 0; r < rows; r++) {
        const Scalar  *src_ptr0 = src + ld * r;
        for (int cc = c; cc < cols; cc++ ) {
            *(dst++) = *src_ptr0++;
        }
      }
    }
  } else { //if constexpr (std::is_same<Scalar, float>::value)
#endif
    int c=0;
    for(; c<cols-Width+1; c+=Width) {
      for(int r=0; r<rows; r++) {
        for(int cc=c; cc<c+Width; cc++) {
          *(dst++)=src[r*ld+cc];
        }
      }
    }
    if(c<cols) {
      for(int r=0; r<rows; r++) {
        for(int cc=c; cc<cols; cc++) {
          *(dst++)=src[r*ld+cc];
        }
      }
    }
#ifdef __ARM_NEON
  }
#endif
}

/**
 * @brief   Do packing block, reorder all the source aligned to 'Width'
 */
template <int Width, typename Scalar>
static inline void PackBlockReorderAligned(
    int rows, int cols, const Scalar* src, const int ld, Scalar* dst) {

  static_assert(Width % 4 == 0, "max_width must be a multiply of 4!");
  const int cols_aligned = (cols + Width - 1) / Width * Width;
#ifdef __ARM_NEON
  if constexpr (std::is_same<Scalar, float>::value) {  
    int r_remain_start = ((rows >> 2) << 2);
    for (int c = 0; c < cols_aligned; c += Width) {
      int r = 0;
      for ( ; r < r_remain_start; r += 4) {
        const Scalar  *src_ptr0 = src + ld * r;
        const Scalar  *src_ptr1 = src + ld * (r+1);
        const Scalar  *src_ptr2 = src + ld * (r+2);
        const Scalar  *src_ptr3 = src + ld * (r+3);
        Scalar  *dst_ptr0 = dst + Width * r;
        Scalar  *dst_ptr1 = dst + Width * (r+1);
        Scalar  *dst_ptr2 = dst + Width * (r+2);
        Scalar  *dst_ptr3 = dst + Width * (r+3);
        for (int cc = 0; cc < Width/4; cc++) {
          float32x4_t vsrc0 = vld1q_f32(src_ptr0);
          float32x4_t vsrc1 = vld1q_f32(src_ptr1);
          float32x4_t vsrc2 = vld1q_f32(src_ptr2);
          float32x4_t vsrc3 = vld1q_f32(src_ptr3);

          vst1q_f32(dst_ptr0, vsrc0);
          vst1q_f32(dst_ptr1, vsrc1);
          vst1q_f32(dst_ptr2, vsrc2);
          vst1q_f32(dst_ptr3, vsrc3);

          src_ptr0 += 4;
          src_ptr1 += 4;
          src_ptr2 += 4;
          src_ptr3 += 4;
          dst_ptr0 += 4;
          dst_ptr1 += 4;
          dst_ptr2 += 4;
          dst_ptr3 += 4;
        }
      }
      for ( ; r < rows; r++) {
        const Scalar  *src_ptr0 = src + ld * r;
        Scalar  *dst_ptr0 = dst + Width * r;
        for (int cc = 0; cc < Width/4; cc++) {
          float32x4_t vsrc0 = vld1q_f32(src_ptr0);

          vst1q_f32(dst_ptr0, vsrc0);

          src_ptr0 += 4;
          dst_ptr0 += 4;
        }
      }
      src += Width;
      dst += Width * rows;
    }
  } else { //if constexpr (std::is_same<Scalar, float>::value)
#endif
    for(int c=0; c<cols_aligned; c+=Width) {
      for(int r=0; r<rows; r++) {
        for(int cc=c; cc<c+Width; cc++) {
          *(dst++)=src[r*ld+cc];
        }
      }
    }
#ifdef __ARM_NEON
  }
#endif
} 

template <typename Lhs, typename Rhs, typename Res, typename Itm, typename Com, CPUModel Model,
    bool RBias, bool Blend, bool ReLU, int KM, int KN>
struct GEMM {
public:
  static void Run(const int m, const int n, const int k, const Lhs* a, int lda,
      const Rhs* b, int ldb, Res* c, int ldc, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
  
    static thread_local std::vector<Lhs, AlignedAllocator<Lhs, 4096>> pack_a_buf(0);
    static thread_local std::vector<Rhs, AlignedAllocator<Rhs, 4096>> pack_b_buf(0);

    const int avail_elem = 2097152 * 0.65 / 4;
    const int avail_elem2 = 32768 / 4;

    const int m_avail_elem = avail_elem / k - KN;
    const int m_max = m / KM * KM;
    int m_remain = m - m_max;
    int m_step = std::max(KM, std::min(m_max, m_avail_elem));
    m_step = m_step / KM * KM;
    int m_num = (m_max + m_step - 1) / m_step;
    m_step = m_num ? (m_max + m_num - 1) / m_num : KM;
    m_step = (m_step + KM - 1) / KM * KM;
    int m_last = m_max - (m_step * (m_num - 1));

    int n_step = KN;
    int n_max = n / KN * KN;
    int n_remain = n - n_max;
    int n_num = (n_max + n_step - 1) / n_step;
    int n_last = KN;

    const Lhs* a_ptr = a;
    const Res* rbias_ptr = rbias;
    Res* c_start = c;
    pack_a_buf.reserve(m_step * k);
    pack_b_buf.reserve(n_step * k);
    Lhs* pack_a = pack_a_buf.data();
    Rhs* pack_b = pack_b_buf.data();
    auto LoadA = PackReorderA<KM, Lhs>;
    auto LoadB = PackBlockReorderAligned<KN, Rhs>;
    for (int i = 0; i < m_num; i++) {
      const Rhs* b_ptr = b;
      Res* c_ptr = c_start;

      int ms = (i == m_num - 1) ? m_last : m_step;
      LoadA(ms, k, a_ptr, lda, pack_a);

      for (int j = 0; j < n_num; j++) {
        int ns = KN;
        LoadB(k, ns, b_ptr, ldb, pack_b);
        auto Func = KernelProvider::Get(KM, KN);

        for (int mi = 0; mi < ms; mi += KM) {
          Func(k, pack_a + mi * k, KM, pack_b, KN, c_ptr + mi * ldc , ldc, nullptr, nullptr, nullptr, rbias_ptr + mi);
        }

        b_ptr += ns;
        c_ptr += ns;
      }

      if (n_remain) {
        if (n_remain <= KernelProvider::n_size[KM-1]) {
          LoadB = PackBlockReorder<KN, Rhs>;
        }
        LoadB(k, n_remain, b_ptr, ldb, pack_b);
        auto Func = KernelProvider::Get(KM, n_remain);

        for (int mi = 0; mi < ms; mi += KM) {
          Func(k, pack_a + mi * k, KM, pack_b, KN, c_ptr + mi * ldc, ldc, nullptr, nullptr, nullptr, rbias_ptr + mi);
        }
      }

      a_ptr += ms * lda;
      rbias_ptr += ms;
      c_start += ms * ldc;
    }

    if (m_remain) {
      const int max_width = KernelProvider::n_size[m_remain-1];
      switch (m_remain) {
        case 1: 
          LoadA = PackReorderA<1, Lhs>;
          LoadB = PackBlockReorder<KernelProvider::n_size[0], Rhs>;
          break;
        case 2: 
          LoadA = PackReorderA<2, Lhs>;
          LoadB = PackBlockReorder<KernelProvider::n_size[1], Rhs>;
          break;
        case 3: 
          LoadA = PackReorderA<3, Lhs>;
          LoadB = PackBlockReorder<KernelProvider::n_size[2], Rhs>;
          break;
        case 4:
          LoadA = PackReorderA<4, Lhs>;
          LoadB = PackBlockReorder<KernelProvider::n_size[3], Rhs>;
          break;
        case 5:
          LoadA = PackReorderA<5, Lhs>;
          LoadB = PackBlockReorder<KernelProvider::n_size[4], Rhs>;
          break;
        case 6: 
          LoadA = PackReorderA<6, Lhs>;
          LoadB = PackBlockReorder<KernelProvider::n_size[5], Rhs>;
          break;
        case 7:
          LoadA = PackReorderA<7, Lhs>;
          LoadB = PackBlockReorder<KernelProvider::n_size[6], Rhs>;
          break;
        default: 
          break;
      }

      const int n_avail_elem = avail_elem2 / k - m_remain;
      n_max = n / max_width * max_width;
      n_remain = n - n_max;
      n_step = std::max(max_width, std::min(n_max, n_avail_elem));
      n_step = n_step / max_width * max_width;
      n_num = (n_max + n_step - 1) / n_step;
      n_step = n_num ? (n_max + n_num - 1) / n_num : max_width;
      n_step = (n_step + max_width - 1) / max_width * max_width;
      n_last = n_max - (n_step * (n_num - 1));

      pack_b_buf.reserve(n_step * k);
      pack_b = pack_b_buf.data();

      const Rhs* b_ptr = b;
      Res* c_ptr = c_start;

      LoadA(m_remain, k, a_ptr, lda, pack_a);

      for (int j = 0; j < n_num; j++) {
        int ns = (j == n_num - 1) ? n_last : n_step;
        LoadB(k, ns, b_ptr, ldb, pack_b);
        auto Func = KernelProvider::Get(m_remain, max_width);

        for (int ni = 0; ni < ns; ni += max_width) {
          Func(k, pack_a, m_remain, pack_b + ni * k, max_width, c_ptr + ni, ldc, nullptr, nullptr, nullptr, rbias_ptr);
        }

        b_ptr += ns;
        c_ptr += ns;
      }

      if (n_remain) {
        LoadB(k, n_remain, b_ptr, ldb, pack_b);
        auto Func = KernelProvider::Get(m_remain, n_remain);

        Func(k, pack_a, m_remain, pack_b, n_remain, c_ptr, ldc, nullptr, nullptr, nullptr, rbias_ptr);
      }
    }
  }

private:
  using KernelProvider = GEMMKernelProviderv2<Lhs, Rhs, Res, Itm, Com, Model, true, true, false, Blend, true, Blend, false, false, RBias, ReLU, true>;
};


}  // namespace gemm_rowmajor_notrans


#endif  // GEMM_ROWMAJOR_NOTRANS_GEMM_ALGO_HPP_
