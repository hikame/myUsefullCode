#ifndef ALIGNED_ALLOCATOR_HPP_
#define ALIGNED_ALLOCATOR_HPP_

#include <cstdlib>

namespace detail {

static inline void* __malloc_aligned(std::size_t size, std::size_t align) {
  size+=sizeof(void*)+align;
  void* base_ptr;
  base_ptr=std::malloc(size);
  if(base_ptr==nullptr) {
    return nullptr;
  }
  else {
    std::size_t start=*reinterpret_cast<std::size_t*>(&base_ptr)+sizeof(void*);
    start=((start+align-1)/align)*align;
    char* return_ptr=*reinterpret_cast<char**>(&start);
    *reinterpret_cast<void**>(return_ptr-sizeof(void*))=base_ptr;
    return static_cast<void*>(return_ptr);
  }
}

static inline void __free_aligned(void* ptr) {
  std::free(*reinterpret_cast<void**>(static_cast<char*>(ptr)-sizeof(void*)));
}

}

template <class T, std::size_t Align>
struct AlignedAllocator {
  using value_type=T;

  template <class U>
  struct rebind {
    using other=AlignedAllocator<U, Align>;
  };

  T* allocate(std::size_t n) {
    if(n>std::size_t(-1)/sizeof(T)) {
      throw std::bad_alloc();
    }
    else {
      auto p=static_cast<T*>(detail::__malloc_aligned(n*sizeof(T), Align));
      if(p!=nullptr) {
        return p;
      }
      else {
        throw std::bad_alloc();
      }
    }
  }
  void deallocate(T* p, std::size_t) noexcept {
    detail::__free_aligned(p);
  }
};

template <class T, class U, std::size_t AlignT, std::size_t AlignU>
bool operator==(const AlignedAllocator<T, AlignT>&, const AlignedAllocator<U, AlignU>&) {
  return AlignT==AlignU;
}
template <class T, class U, std::size_t AlignT, std::size_t AlignU>
bool operator!=(const AlignedAllocator<T, AlignT>&, const AlignedAllocator<U, AlignU>&) {
  return AlignT!=AlignU;
}

#endif  // ALIGNED_ALLOCATOR_HPP_
