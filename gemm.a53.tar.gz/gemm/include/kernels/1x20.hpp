#ifndef GEMM_ROWMAJOR_NOTRANS_KERNELS_1X20_HPP_
#define GEMM_ROWMAJOR_NOTRANS_KERNELS_1X20_HPP_

#include <kernel.hpp>


#ifdef __aarch64__

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 20, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+20*(kk+0)+0),
[addr_b1] "r" (b+20*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+20*(kk+0)+0),
[addr_b1] "r" (b+20*(kk+0)+16),
[addr_b2] "r" (b+20*(kk+1)+0),
[addr_b3] "r" (b+20*(kk+1)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
:
: [addr_b0] "r" (b+20*(kk+0)+0),
[addr_b1] "r" (b+20*(kk+0)+16),
[addr_b2] "r" (b+20*(kk+1)+0),
[addr_b3] "r" (b+20*(kk+1)+16),
[addr_b4] "r" (b+20*(kk+2)+0),
[addr_b5] "r" (b+20*(kk+2)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16),
[addr_b4] "r" (b+ldb*(kk+2)+0),
[addr_b5] "r" (b+ldb*(kk+2)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b6]] \r\n"
"ld1    {v25.4s}, [%[addr_b7]] \r\n"
:
: [addr_b0] "r" (b+20*(kk+0)+0),
[addr_b1] "r" (b+20*(kk+0)+16),
[addr_b2] "r" (b+20*(kk+1)+0),
[addr_b3] "r" (b+20*(kk+1)+16),
[addr_b4] "r" (b+20*(kk+2)+0),
[addr_b5] "r" (b+20*(kk+2)+16),
[addr_b6] "r" (b+20*(kk+3)+0),
[addr_b7] "r" (b+20*(kk+3)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b6]] \r\n"
"ld1    {v25.4s}, [%[addr_b7]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16),
[addr_b4] "r" (b+ldb*(kk+2)+0),
[addr_b5] "r" (b+ldb*(kk+2)+16),
[addr_b6] "r" (b+ldb*(kk+3)+0),
[addr_b7] "r" (b+ldb*(kk+3)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
else {
asm volatile(
"	fmla	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmla	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmla	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmla	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+20*(kk+0) + 0*16),
[addr_b1] "r" (b+20*(kk+0) + 1*16)
: "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
asm volatile(
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b0]] \r\n"
"ld1    {v15.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+20*(kk+1) + 0*16),
[addr_b1] "r" (b+20*(kk+1) + 1*16)
: "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b0]] \r\n"
"ld1    {v15.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1)+0),
[addr_b1] "r" (b+ldb*(kk+1)+16)
: "v11", "v12", "v13", "v14", "v15");
}
asm volatile(
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b0]] \r\n"
"ld1    {v20.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+20*(kk+2) + 0*16),
[addr_b1] "r" (b+20*(kk+2) + 1*16)
: "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b0]] \r\n"
"ld1    {v20.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2)+0),
[addr_b1] "r" (b+ldb*(kk+2)+16)
: "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmla	v0.4s,  v21.4s, v5.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v5.s[3]  \r\n"
"	fmla	v2.4s,  v23.4s, v5.s[3]  \r\n"
"	fmla	v3.4s,  v24.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v25.4s, v5.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b0]] \r\n"
"ld1    {v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+20*(kk+3) + 0*16),
[addr_b1] "r" (b+20*(kk+3) + 1*16)
: "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b0]] \r\n"
"ld1    {v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3)+0),
[addr_b1] "r" (b+ldb*(kk+3)+16)
: "v21", "v22", "v23", "v24", "v25");
}
asm volatile(
"	fmla	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmla	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmla	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmla	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
asm volatile(
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v21.4s, v5.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v5.s[3]  \r\n"
"	fmla	v2.4s,  v23.4s, v5.s[3]  \r\n"
"	fmla	v3.4s,  v24.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v25.4s, v5.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s5, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+20*(kk+0)+0),
[addr_b1] "r" (b+20*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d5, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+20*(kk+0)+0),
[addr_b1] "r" (b+20*(kk+0)+16),
[addr_b2] "r" (b+20*(kk+1)+0),
[addr_b3] "r" (b+20*(kk+1)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q5, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
:
: [addr_b0] "r" (b+20*(kk+0)+0),
[addr_b1] "r" (b+20*(kk+0)+16),
[addr_b2] "r" (b+20*(kk+1)+0),
[addr_b3] "r" (b+20*(kk+1)+16),
[addr_b4] "r" (b+20*(kk+2)+0),
[addr_b5] "r" (b+20*(kk+2)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16),
[addr_b4] "r" (b+ldb*(kk+2)+0),
[addr_b5] "r" (b+ldb*(kk+2)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
"dup     v4.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3", "v4");
}
asm volatile(
"ldr    q5, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b6]] \r\n"
"ld1    {v25.4s}, [%[addr_b7]] \r\n"
:
: [addr_b0] "r" (b+20*(kk+0)+0),
[addr_b1] "r" (b+20*(kk+0)+16),
[addr_b2] "r" (b+20*(kk+1)+0),
[addr_b3] "r" (b+20*(kk+1)+16),
[addr_b4] "r" (b+20*(kk+2)+0),
[addr_b5] "r" (b+20*(kk+2)+16),
[addr_b6] "r" (b+20*(kk+3)+0),
[addr_b7] "r" (b+20*(kk+3)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b6]] \r\n"
"ld1    {v25.4s}, [%[addr_b7]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16),
[addr_b4] "r" (b+ldb*(kk+2)+0),
[addr_b5] "r" (b+ldb*(kk+2)+16),
[addr_b6] "r" (b+ldb*(kk+3)+0),
[addr_b7] "r" (b+ldb*(kk+3)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25");
}
asm volatile(
"	fmla	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmla	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmla	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmla	v4.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
"	fmla	v0.4s,  v21.4s, v5.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v5.s[3]  \r\n"
"	fmla	v2.4s,  v23.4s, v5.s[3]  \r\n"
"	fmla	v3.4s,  v24.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v25.4s, v5.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v5.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v5.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v5.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v5.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v5.s[0]       \r\n"
"fmul    v4.4s,  v4.4s,  v5.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v10.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_c0]] \r\n"
"ld1    {v9.4s}, [%[addr_c1]] \r\n"
"fmla    v0.4s,  v5.4s,  v10.s[0]       \r\n"
"fmla    v1.4s,  v6.4s,  v10.s[0]       \r\n"
"fmla    v2.4s,  v7.4s,  v10.s[0]       \r\n"
"fmla    v3.4s,  v8.4s,  v10.s[0]       \r\n"
"fmla    v4.4s,  v9.4s,  v10.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0+0),
[addr_c1] "r" (c+ldc*0+16)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_itm0]] \r\n"
"ld1    {v9.4s}, [%[addr_itm1]] \r\n"
:
: [addr_itm0] "r" (itm+20*0+0),
[addr_itm1] "r" (itm+20*0+16)
: "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_c0]] \r\n"
"ld1    {v9.4s}, [%[addr_c1]] \r\n"
:
: [addr_c0] "r" (c+ldc*0+0),
[addr_c1] "r" (c+ldc*0+16)
: "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"fadd     v0.4s, v5.4s,  v0.4s \r\n"
"fadd     v1.4s, v6.4s,  v1.4s \r\n"
"fadd     v2.4s, v7.4s,  v2.4s \r\n"
"fadd     v3.4s, v8.4s,  v3.4s \r\n"
"fadd     v4.4s, v9.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v5.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v5.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v5.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v5.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v5.s[0]       \r\n"
"fmul    v4.4s,  v4.4s,  v5.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_c0]] \r\n"
"ld1    {v9.4s}, [%[addr_c1]] \r\n"
:
: [addr_c0] "r" (c+ldc*0+0),
[addr_c1] "r" (c+ldc*0+16)
: "v5", "v6", "v7", "v8", "v9");
asm volatile(
"fadd     v0.4s, v5.4s,  v0.4s \r\n"
"fadd     v1.4s, v6.4s,  v1.4s \r\n"
"fadd     v2.4s, v7.4s,  v2.4s \r\n"
"fadd     v3.4s, v8.4s,  v3.4s \r\n"
"fadd     v4.4s, v9.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v10.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_c0]] \r\n"
"ld1    {v9.4s}, [%[addr_c1]] \r\n"
"fmla    v0.4s,  v5.4s,  v10.s[0]       \r\n"
"fmla    v1.4s,  v6.4s,  v10.s[0]       \r\n"
"fmla    v2.4s,  v7.4s,  v10.s[0]       \r\n"
"fmla    v3.4s,  v8.4s,  v10.s[0]       \r\n"
"fmla    v4.4s,  v9.4s,  v10.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0+0),
[addr_c1] "r" (c+ldc*0+16)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v5.4s}, [%[addr_bias]] \r\n"
"dup    v6.4s, v5.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v6.4s \r\n"
"fadd     v1.4s, v1.4s,  v6.4s \r\n"
"fadd     v2.4s, v2.4s,  v6.4s \r\n"
"fadd     v3.4s, v3.4s,  v6.4s \r\n"
"fadd     v4.4s, v4.4s,  v6.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5", "v5", "v6");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v5.4s, w9             \r\n"
"fmax    v0.4s, v5.4s,  v0.4s \r\n"
"fmax    v1.4s, v5.4s,  v1.4s \r\n"
"fmax    v2.4s, v5.4s,  v2.4s \r\n"
"fmax    v3.4s, v5.4s,  v3.4s \r\n"
"fmax    v4.4s, v5.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"st1    { v0.4s,  v1.4s,  v2.4s,  v3.4s}, [%[addr_itm0]] \r\n"
"st1    { v4.4s}, [%[addr_itm1]] \r\n"
:
: [addr_itm0] "r" (itm+8*0),
[addr_itm1] "r" (itm+8*2)
: "memory");}
else {
asm volatile(
"st1    {v0.4s, v1.4s, v2.4s, v3.4s}, [%[addr_c0]] \r\n"
"st1    {v4.4s}, [%[addr_c1]] \r\n"
:
: [addr_c0] "r" ((c+ldc*0)+0),
[addr_c1] "r" ((c+ldc*0)+16)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 19, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+19*(kk+0)+0),
[addr_b1] "r" (b+19*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+19*(kk+0)+0),
[addr_b1] "r" (b+19*(kk+0)+16),
[addr_b2] "r" (b+19*(kk+1)+0),
[addr_b3] "r" (b+19*(kk+1)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
:
: [addr_b0] "r" (b+19*(kk+0)+0),
[addr_b1] "r" (b+19*(kk+0)+16),
[addr_b2] "r" (b+19*(kk+1)+0),
[addr_b3] "r" (b+19*(kk+1)+16),
[addr_b4] "r" (b+19*(kk+2)+0),
[addr_b5] "r" (b+19*(kk+2)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16),
[addr_b4] "r" (b+ldb*(kk+2)+0),
[addr_b5] "r" (b+ldb*(kk+2)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b6]] \r\n"
"ld1    {v25.4s}, [%[addr_b7]] \r\n"
:
: [addr_b0] "r" (b+19*(kk+0)+0),
[addr_b1] "r" (b+19*(kk+0)+16),
[addr_b2] "r" (b+19*(kk+1)+0),
[addr_b3] "r" (b+19*(kk+1)+16),
[addr_b4] "r" (b+19*(kk+2)+0),
[addr_b5] "r" (b+19*(kk+2)+16),
[addr_b6] "r" (b+19*(kk+3)+0),
[addr_b7] "r" (b+19*(kk+3)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b6]] \r\n"
"ld1    {v25.4s}, [%[addr_b7]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16),
[addr_b4] "r" (b+ldb*(kk+2)+0),
[addr_b5] "r" (b+ldb*(kk+2)+16),
[addr_b6] "r" (b+ldb*(kk+3)+0),
[addr_b7] "r" (b+ldb*(kk+3)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
else {
asm volatile(
"	fmla	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmla	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmla	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmla	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+19*(kk+0) + 0*16),
[addr_b1] "r" (b+19*(kk+0) + 1*16)
: "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
asm volatile(
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b0]] \r\n"
"ld1    {v15.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+19*(kk+1) + 0*16),
[addr_b1] "r" (b+19*(kk+1) + 1*16)
: "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b0]] \r\n"
"ld1    {v15.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1)+0),
[addr_b1] "r" (b+ldb*(kk+1)+16)
: "v11", "v12", "v13", "v14", "v15");
}
asm volatile(
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b0]] \r\n"
"ld1    {v20.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+19*(kk+2) + 0*16),
[addr_b1] "r" (b+19*(kk+2) + 1*16)
: "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b0]] \r\n"
"ld1    {v20.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2)+0),
[addr_b1] "r" (b+ldb*(kk+2)+16)
: "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmla	v0.4s,  v21.4s, v5.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v5.s[3]  \r\n"
"	fmla	v2.4s,  v23.4s, v5.s[3]  \r\n"
"	fmla	v3.4s,  v24.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v25.4s, v5.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b0]] \r\n"
"ld1    {v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+19*(kk+3) + 0*16),
[addr_b1] "r" (b+19*(kk+3) + 1*16)
: "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b0]] \r\n"
"ld1    {v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3)+0),
[addr_b1] "r" (b+ldb*(kk+3)+16)
: "v21", "v22", "v23", "v24", "v25");
}
asm volatile(
"	fmla	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmla	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmla	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmla	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
asm volatile(
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v21.4s, v5.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v5.s[3]  \r\n"
"	fmla	v2.4s,  v23.4s, v5.s[3]  \r\n"
"	fmla	v3.4s,  v24.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v25.4s, v5.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s5, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+19*(kk+0)+0),
[addr_b1] "r" (b+19*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d5, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+19*(kk+0)+0),
[addr_b1] "r" (b+19*(kk+0)+16),
[addr_b2] "r" (b+19*(kk+1)+0),
[addr_b3] "r" (b+19*(kk+1)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q5, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
:
: [addr_b0] "r" (b+19*(kk+0)+0),
[addr_b1] "r" (b+19*(kk+0)+16),
[addr_b2] "r" (b+19*(kk+1)+0),
[addr_b3] "r" (b+19*(kk+1)+16),
[addr_b4] "r" (b+19*(kk+2)+0),
[addr_b5] "r" (b+19*(kk+2)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16),
[addr_b4] "r" (b+ldb*(kk+2)+0),
[addr_b5] "r" (b+ldb*(kk+2)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
"dup     v4.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3", "v4");
}
asm volatile(
"ldr    q5, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b6]] \r\n"
"ld1    {v25.4s}, [%[addr_b7]] \r\n"
:
: [addr_b0] "r" (b+19*(kk+0)+0),
[addr_b1] "r" (b+19*(kk+0)+16),
[addr_b2] "r" (b+19*(kk+1)+0),
[addr_b3] "r" (b+19*(kk+1)+16),
[addr_b4] "r" (b+19*(kk+2)+0),
[addr_b5] "r" (b+19*(kk+2)+16),
[addr_b6] "r" (b+19*(kk+3)+0),
[addr_b7] "r" (b+19*(kk+3)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b6]] \r\n"
"ld1    {v25.4s}, [%[addr_b7]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16),
[addr_b4] "r" (b+ldb*(kk+2)+0),
[addr_b5] "r" (b+ldb*(kk+2)+16),
[addr_b6] "r" (b+ldb*(kk+3)+0),
[addr_b7] "r" (b+ldb*(kk+3)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25");
}
asm volatile(
"	fmla	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmla	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmla	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmla	v4.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
"	fmla	v0.4s,  v21.4s, v5.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v5.s[3]  \r\n"
"	fmla	v2.4s,  v23.4s, v5.s[3]  \r\n"
"	fmla	v3.4s,  v24.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v25.4s, v5.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v5.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v5.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v5.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v5.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v5.s[0]       \r\n"
"fmul    v4.4s,  v4.4s,  v5.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v10.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_c0]] \r\n"
"ld1    {v9.4s}, [%[addr_c1]] \r\n"
"fmla    v0.4s,  v5.4s,  v10.s[0]       \r\n"
"fmla    v1.4s,  v6.4s,  v10.s[0]       \r\n"
"fmla    v2.4s,  v7.4s,  v10.s[0]       \r\n"
"fmla    v3.4s,  v8.4s,  v10.s[0]       \r\n"
"fmla    v4.4s,  v9.4s,  v10.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0+0),
[addr_c1] "r" (c+ldc*0+16)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_itm0]] \r\n"
"ld1    {v9.4s}, [%[addr_itm1]] \r\n"
:
: [addr_itm0] "r" (itm+19*0+0),
[addr_itm1] "r" (itm+19*0+16)
: "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_c0]] \r\n"
"ld1    {v9.4s}, [%[addr_c1]] \r\n"
:
: [addr_c0] "r" (c+ldc*0+0),
[addr_c1] "r" (c+ldc*0+16)
: "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"fadd     v0.4s, v5.4s,  v0.4s \r\n"
"fadd     v1.4s, v6.4s,  v1.4s \r\n"
"fadd     v2.4s, v7.4s,  v2.4s \r\n"
"fadd     v3.4s, v8.4s,  v3.4s \r\n"
"fadd     v4.4s, v9.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v5.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v5.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v5.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v5.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v5.s[0]       \r\n"
"fmul    v4.4s,  v4.4s,  v5.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_c0]] \r\n"
"ld1    {v9.4s}, [%[addr_c1]] \r\n"
:
: [addr_c0] "r" (c+ldc*0+0),
[addr_c1] "r" (c+ldc*0+16)
: "v5", "v6", "v7", "v8", "v9");
asm volatile(
"fadd     v0.4s, v5.4s,  v0.4s \r\n"
"fadd     v1.4s, v6.4s,  v1.4s \r\n"
"fadd     v2.4s, v7.4s,  v2.4s \r\n"
"fadd     v3.4s, v8.4s,  v3.4s \r\n"
"fadd     v4.4s, v9.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v10.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_c0]] \r\n"
"ld1    {v9.4s}, [%[addr_c1]] \r\n"
"fmla    v0.4s,  v5.4s,  v10.s[0]       \r\n"
"fmla    v1.4s,  v6.4s,  v10.s[0]       \r\n"
"fmla    v2.4s,  v7.4s,  v10.s[0]       \r\n"
"fmla    v3.4s,  v8.4s,  v10.s[0]       \r\n"
"fmla    v4.4s,  v9.4s,  v10.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0+0),
[addr_c1] "r" (c+ldc*0+16)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v5.4s}, [%[addr_bias]] \r\n"
"dup    v6.4s, v5.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v6.4s \r\n"
"fadd     v1.4s, v1.4s,  v6.4s \r\n"
"fadd     v2.4s, v2.4s,  v6.4s \r\n"
"fadd     v3.4s, v3.4s,  v6.4s \r\n"
"fadd     v4.4s, v4.4s,  v6.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5", "v5", "v6");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v5.4s, w9             \r\n"
"fmax    v0.4s, v5.4s,  v0.4s \r\n"
"fmax    v1.4s, v5.4s,  v1.4s \r\n"
"fmax    v2.4s, v5.4s,  v2.4s \r\n"
"fmax    v3.4s, v5.4s,  v3.4s \r\n"
"fmax    v4.4s, v5.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"mov    s5,  v4.s[2]           \r\n"
"str     q0, [%[addr_itm],   0] \r\n"
"str     q1, [%[addr_itm],   16] \r\n"
"str     q2, [%[addr_itm],   32] \r\n"
"str     q3, [%[addr_itm],   48] \r\n"
"str     d4, [%[addr_itm],   64] \r\n"
"str     s5, [%[addr_itm],   72] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"mov    s5,  v4.s[2]           \r\n"
"str     q0, [%[addr_c0],   0] \r\n"
"str     q1, [%[addr_c0],   16] \r\n"
"str     q2, [%[addr_c0],   32] \r\n"
"str     q3, [%[addr_c0],   48] \r\n"
"str     d4, [%[addr_c0],   64] \r\n"
"str     s5, [%[addr_c0],   72] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 18, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+18*(kk+0)+0),
[addr_b1] "r" (b+18*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+18*(kk+0)+0),
[addr_b1] "r" (b+18*(kk+0)+16),
[addr_b2] "r" (b+18*(kk+1)+0),
[addr_b3] "r" (b+18*(kk+1)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
:
: [addr_b0] "r" (b+18*(kk+0)+0),
[addr_b1] "r" (b+18*(kk+0)+16),
[addr_b2] "r" (b+18*(kk+1)+0),
[addr_b3] "r" (b+18*(kk+1)+16),
[addr_b4] "r" (b+18*(kk+2)+0),
[addr_b5] "r" (b+18*(kk+2)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16),
[addr_b4] "r" (b+ldb*(kk+2)+0),
[addr_b5] "r" (b+ldb*(kk+2)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b6]] \r\n"
"ld1    {v25.4s}, [%[addr_b7]] \r\n"
:
: [addr_b0] "r" (b+18*(kk+0)+0),
[addr_b1] "r" (b+18*(kk+0)+16),
[addr_b2] "r" (b+18*(kk+1)+0),
[addr_b3] "r" (b+18*(kk+1)+16),
[addr_b4] "r" (b+18*(kk+2)+0),
[addr_b5] "r" (b+18*(kk+2)+16),
[addr_b6] "r" (b+18*(kk+3)+0),
[addr_b7] "r" (b+18*(kk+3)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b6]] \r\n"
"ld1    {v25.4s}, [%[addr_b7]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16),
[addr_b4] "r" (b+ldb*(kk+2)+0),
[addr_b5] "r" (b+ldb*(kk+2)+16),
[addr_b6] "r" (b+ldb*(kk+3)+0),
[addr_b7] "r" (b+ldb*(kk+3)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
else {
asm volatile(
"	fmla	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmla	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmla	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmla	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+18*(kk+0) + 0*16),
[addr_b1] "r" (b+18*(kk+0) + 1*16)
: "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
asm volatile(
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b0]] \r\n"
"ld1    {v15.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+18*(kk+1) + 0*16),
[addr_b1] "r" (b+18*(kk+1) + 1*16)
: "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b0]] \r\n"
"ld1    {v15.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1)+0),
[addr_b1] "r" (b+ldb*(kk+1)+16)
: "v11", "v12", "v13", "v14", "v15");
}
asm volatile(
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b0]] \r\n"
"ld1    {v20.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+18*(kk+2) + 0*16),
[addr_b1] "r" (b+18*(kk+2) + 1*16)
: "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b0]] \r\n"
"ld1    {v20.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2)+0),
[addr_b1] "r" (b+ldb*(kk+2)+16)
: "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmla	v0.4s,  v21.4s, v5.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v5.s[3]  \r\n"
"	fmla	v2.4s,  v23.4s, v5.s[3]  \r\n"
"	fmla	v3.4s,  v24.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v25.4s, v5.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b0]] \r\n"
"ld1    {v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+18*(kk+3) + 0*16),
[addr_b1] "r" (b+18*(kk+3) + 1*16)
: "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b0]] \r\n"
"ld1    {v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3)+0),
[addr_b1] "r" (b+ldb*(kk+3)+16)
: "v21", "v22", "v23", "v24", "v25");
}
asm volatile(
"	fmla	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmla	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmla	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmla	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
asm volatile(
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v21.4s, v5.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v5.s[3]  \r\n"
"	fmla	v2.4s,  v23.4s, v5.s[3]  \r\n"
"	fmla	v3.4s,  v24.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v25.4s, v5.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s5, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+18*(kk+0)+0),
[addr_b1] "r" (b+18*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d5, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+18*(kk+0)+0),
[addr_b1] "r" (b+18*(kk+0)+16),
[addr_b2] "r" (b+18*(kk+1)+0),
[addr_b3] "r" (b+18*(kk+1)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q5, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
:
: [addr_b0] "r" (b+18*(kk+0)+0),
[addr_b1] "r" (b+18*(kk+0)+16),
[addr_b2] "r" (b+18*(kk+1)+0),
[addr_b3] "r" (b+18*(kk+1)+16),
[addr_b4] "r" (b+18*(kk+2)+0),
[addr_b5] "r" (b+18*(kk+2)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16),
[addr_b4] "r" (b+ldb*(kk+2)+0),
[addr_b5] "r" (b+ldb*(kk+2)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
"dup     v4.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3", "v4");
}
asm volatile(
"ldr    q5, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b6]] \r\n"
"ld1    {v25.4s}, [%[addr_b7]] \r\n"
:
: [addr_b0] "r" (b+18*(kk+0)+0),
[addr_b1] "r" (b+18*(kk+0)+16),
[addr_b2] "r" (b+18*(kk+1)+0),
[addr_b3] "r" (b+18*(kk+1)+16),
[addr_b4] "r" (b+18*(kk+2)+0),
[addr_b5] "r" (b+18*(kk+2)+16),
[addr_b6] "r" (b+18*(kk+3)+0),
[addr_b7] "r" (b+18*(kk+3)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b6]] \r\n"
"ld1    {v25.4s}, [%[addr_b7]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16),
[addr_b4] "r" (b+ldb*(kk+2)+0),
[addr_b5] "r" (b+ldb*(kk+2)+16),
[addr_b6] "r" (b+ldb*(kk+3)+0),
[addr_b7] "r" (b+ldb*(kk+3)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25");
}
asm volatile(
"	fmla	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmla	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmla	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmla	v4.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
"	fmla	v0.4s,  v21.4s, v5.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v5.s[3]  \r\n"
"	fmla	v2.4s,  v23.4s, v5.s[3]  \r\n"
"	fmla	v3.4s,  v24.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v25.4s, v5.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v5.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v5.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v5.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v5.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v5.s[0]       \r\n"
"fmul    v4.4s,  v4.4s,  v5.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v10.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_c0]] \r\n"
"ld1    {v9.4s}, [%[addr_c1]] \r\n"
"fmla    v0.4s,  v5.4s,  v10.s[0]       \r\n"
"fmla    v1.4s,  v6.4s,  v10.s[0]       \r\n"
"fmla    v2.4s,  v7.4s,  v10.s[0]       \r\n"
"fmla    v3.4s,  v8.4s,  v10.s[0]       \r\n"
"fmla    v4.4s,  v9.4s,  v10.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0+0),
[addr_c1] "r" (c+ldc*0+16)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_itm0]] \r\n"
"ld1    {v9.4s}, [%[addr_itm1]] \r\n"
:
: [addr_itm0] "r" (itm+18*0+0),
[addr_itm1] "r" (itm+18*0+16)
: "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_c0]] \r\n"
"ld1    {v9.4s}, [%[addr_c1]] \r\n"
:
: [addr_c0] "r" (c+ldc*0+0),
[addr_c1] "r" (c+ldc*0+16)
: "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"fadd     v0.4s, v5.4s,  v0.4s \r\n"
"fadd     v1.4s, v6.4s,  v1.4s \r\n"
"fadd     v2.4s, v7.4s,  v2.4s \r\n"
"fadd     v3.4s, v8.4s,  v3.4s \r\n"
"fadd     v4.4s, v9.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v5.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v5.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v5.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v5.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v5.s[0]       \r\n"
"fmul    v4.4s,  v4.4s,  v5.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_c0]] \r\n"
"ld1    {v9.4s}, [%[addr_c1]] \r\n"
:
: [addr_c0] "r" (c+ldc*0+0),
[addr_c1] "r" (c+ldc*0+16)
: "v5", "v6", "v7", "v8", "v9");
asm volatile(
"fadd     v0.4s, v5.4s,  v0.4s \r\n"
"fadd     v1.4s, v6.4s,  v1.4s \r\n"
"fadd     v2.4s, v7.4s,  v2.4s \r\n"
"fadd     v3.4s, v8.4s,  v3.4s \r\n"
"fadd     v4.4s, v9.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v10.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_c0]] \r\n"
"ld1    {v9.4s}, [%[addr_c1]] \r\n"
"fmla    v0.4s,  v5.4s,  v10.s[0]       \r\n"
"fmla    v1.4s,  v6.4s,  v10.s[0]       \r\n"
"fmla    v2.4s,  v7.4s,  v10.s[0]       \r\n"
"fmla    v3.4s,  v8.4s,  v10.s[0]       \r\n"
"fmla    v4.4s,  v9.4s,  v10.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0+0),
[addr_c1] "r" (c+ldc*0+16)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v5.4s}, [%[addr_bias]] \r\n"
"dup    v6.4s, v5.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v6.4s \r\n"
"fadd     v1.4s, v1.4s,  v6.4s \r\n"
"fadd     v2.4s, v2.4s,  v6.4s \r\n"
"fadd     v3.4s, v3.4s,  v6.4s \r\n"
"fadd     v4.4s, v4.4s,  v6.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5", "v5", "v6");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v5.4s, w9             \r\n"
"fmax    v0.4s, v5.4s,  v0.4s \r\n"
"fmax    v1.4s, v5.4s,  v1.4s \r\n"
"fmax    v2.4s, v5.4s,  v2.4s \r\n"
"fmax    v3.4s, v5.4s,  v3.4s \r\n"
"fmax    v4.4s, v5.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"str     q0, [%[addr_itm],   0] \r\n"
"str     q1, [%[addr_itm],   16] \r\n"
"str     q2, [%[addr_itm],   32] \r\n"
"str     q3, [%[addr_itm],   48] \r\n"
"str     d4, [%[addr_itm],   64] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"str     q0, [%[addr_c0],   0] \r\n"
"str     q1, [%[addr_c0],   16] \r\n"
"str     q2, [%[addr_c0],   32] \r\n"
"str     q3, [%[addr_c0],   48] \r\n"
"str     d4, [%[addr_c0],   64] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 17, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+17*(kk+0)+0),
[addr_b1] "r" (b+17*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+17*(kk+0)+0),
[addr_b1] "r" (b+17*(kk+0)+16),
[addr_b2] "r" (b+17*(kk+1)+0),
[addr_b3] "r" (b+17*(kk+1)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
:
: [addr_b0] "r" (b+17*(kk+0)+0),
[addr_b1] "r" (b+17*(kk+0)+16),
[addr_b2] "r" (b+17*(kk+1)+0),
[addr_b3] "r" (b+17*(kk+1)+16),
[addr_b4] "r" (b+17*(kk+2)+0),
[addr_b5] "r" (b+17*(kk+2)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16),
[addr_b4] "r" (b+ldb*(kk+2)+0),
[addr_b5] "r" (b+ldb*(kk+2)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b6]] \r\n"
"ld1    {v25.4s}, [%[addr_b7]] \r\n"
:
: [addr_b0] "r" (b+17*(kk+0)+0),
[addr_b1] "r" (b+17*(kk+0)+16),
[addr_b2] "r" (b+17*(kk+1)+0),
[addr_b3] "r" (b+17*(kk+1)+16),
[addr_b4] "r" (b+17*(kk+2)+0),
[addr_b5] "r" (b+17*(kk+2)+16),
[addr_b6] "r" (b+17*(kk+3)+0),
[addr_b7] "r" (b+17*(kk+3)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b6]] \r\n"
"ld1    {v25.4s}, [%[addr_b7]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16),
[addr_b4] "r" (b+ldb*(kk+2)+0),
[addr_b5] "r" (b+ldb*(kk+2)+16),
[addr_b6] "r" (b+ldb*(kk+3)+0),
[addr_b7] "r" (b+ldb*(kk+3)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
else {
asm volatile(
"	fmla	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmla	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmla	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmla	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+17*(kk+0) + 0*16),
[addr_b1] "r" (b+17*(kk+0) + 1*16)
: "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
asm volatile(
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b0]] \r\n"
"ld1    {v15.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+17*(kk+1) + 0*16),
[addr_b1] "r" (b+17*(kk+1) + 1*16)
: "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b0]] \r\n"
"ld1    {v15.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1)+0),
[addr_b1] "r" (b+ldb*(kk+1)+16)
: "v11", "v12", "v13", "v14", "v15");
}
asm volatile(
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b0]] \r\n"
"ld1    {v20.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+17*(kk+2) + 0*16),
[addr_b1] "r" (b+17*(kk+2) + 1*16)
: "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b0]] \r\n"
"ld1    {v20.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2)+0),
[addr_b1] "r" (b+ldb*(kk+2)+16)
: "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmla	v0.4s,  v21.4s, v5.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v5.s[3]  \r\n"
"	fmla	v2.4s,  v23.4s, v5.s[3]  \r\n"
"	fmla	v3.4s,  v24.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v25.4s, v5.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b0]] \r\n"
"ld1    {v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+17*(kk+3) + 0*16),
[addr_b1] "r" (b+17*(kk+3) + 1*16)
: "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b0]] \r\n"
"ld1    {v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3)+0),
[addr_b1] "r" (b+ldb*(kk+3)+16)
: "v21", "v22", "v23", "v24", "v25");
}
asm volatile(
"	fmla	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmla	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmla	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmla	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
asm volatile(
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v21.4s, v5.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v5.s[3]  \r\n"
"	fmla	v2.4s,  v23.4s, v5.s[3]  \r\n"
"	fmla	v3.4s,  v24.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v25.4s, v5.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s5, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+17*(kk+0)+0),
[addr_b1] "r" (b+17*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16)
: "v6", "v7", "v8", "v9", "v10");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d5, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+17*(kk+0)+0),
[addr_b1] "r" (b+17*(kk+0)+16),
[addr_b2] "r" (b+17*(kk+1)+0),
[addr_b3] "r" (b+17*(kk+1)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q5, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
:
: [addr_b0] "r" (b+17*(kk+0)+0),
[addr_b1] "r" (b+17*(kk+0)+16),
[addr_b2] "r" (b+17*(kk+1)+0),
[addr_b3] "r" (b+17*(kk+1)+16),
[addr_b4] "r" (b+17*(kk+2)+0),
[addr_b5] "r" (b+17*(kk+2)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16),
[addr_b4] "r" (b+ldb*(kk+2)+0),
[addr_b5] "r" (b+ldb*(kk+2)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmul	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmul	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmul	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
"dup     v4.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3", "v4");
}
asm volatile(
"ldr    q5, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b6]] \r\n"
"ld1    {v25.4s}, [%[addr_b7]] \r\n"
:
: [addr_b0] "r" (b+17*(kk+0)+0),
[addr_b1] "r" (b+17*(kk+0)+16),
[addr_b2] "r" (b+17*(kk+1)+0),
[addr_b3] "r" (b+17*(kk+1)+16),
[addr_b4] "r" (b+17*(kk+2)+0),
[addr_b5] "r" (b+17*(kk+2)+16),
[addr_b6] "r" (b+17*(kk+3)+0),
[addr_b7] "r" (b+17*(kk+3)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v6.4s, v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
"ld1    {v10.4s}, [%[addr_b1]] \r\n"
"ld1    {v11.4s, v12.4s, v13.4s, v14.4s}, [%[addr_b2]] \r\n"
"ld1    {v15.4s}, [%[addr_b3]] \r\n"
"ld1    {v16.4s, v17.4s, v18.4s, v19.4s}, [%[addr_b4]] \r\n"
"ld1    {v20.4s}, [%[addr_b5]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s, v24.4s}, [%[addr_b6]] \r\n"
"ld1    {v25.4s}, [%[addr_b7]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)+0),
[addr_b1] "r" (b+ldb*(kk+0)+16),
[addr_b2] "r" (b+ldb*(kk+1)+0),
[addr_b3] "r" (b+ldb*(kk+1)+16),
[addr_b4] "r" (b+ldb*(kk+2)+0),
[addr_b5] "r" (b+ldb*(kk+2)+16),
[addr_b6] "r" (b+ldb*(kk+3)+0),
[addr_b7] "r" (b+ldb*(kk+3)+16)
: "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25");
}
asm volatile(
"	fmla	v0.4s,  v6.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v7.4s, v5.s[0]  \r\n"
"	fmla	v2.4s,  v8.4s, v5.s[0]  \r\n"
"	fmla	v3.4s,  v9.4s, v5.s[0]  \r\n"
"	fmla	v4.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v12.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v13.4s, v5.s[1]  \r\n"
"	fmla	v3.4s,  v14.4s, v5.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v5.s[1]  \r\n"
"	fmla	v0.4s,  v16.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v17.4s, v5.s[2]  \r\n"
"	fmla	v2.4s,  v18.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v19.4s, v5.s[2]  \r\n"
"	fmla	v4.4s,  v20.4s, v5.s[2]  \r\n"
"	fmla	v0.4s,  v21.4s, v5.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v5.s[3]  \r\n"
"	fmla	v2.4s,  v23.4s, v5.s[3]  \r\n"
"	fmla	v3.4s,  v24.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v25.4s, v5.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v5.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v5.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v5.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v5.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v5.s[0]       \r\n"
"fmul    v4.4s,  v4.4s,  v5.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v10.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_c0]] \r\n"
"ld1    {v9.4s}, [%[addr_c1]] \r\n"
"fmla    v0.4s,  v5.4s,  v10.s[0]       \r\n"
"fmla    v1.4s,  v6.4s,  v10.s[0]       \r\n"
"fmla    v2.4s,  v7.4s,  v10.s[0]       \r\n"
"fmla    v3.4s,  v8.4s,  v10.s[0]       \r\n"
"fmla    v4.4s,  v9.4s,  v10.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0+0),
[addr_c1] "r" (c+ldc*0+16)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_itm0]] \r\n"
"ld1    {v9.4s}, [%[addr_itm1]] \r\n"
:
: [addr_itm0] "r" (itm+17*0+0),
[addr_itm1] "r" (itm+17*0+16)
: "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_c0]] \r\n"
"ld1    {v9.4s}, [%[addr_c1]] \r\n"
:
: [addr_c0] "r" (c+ldc*0+0),
[addr_c1] "r" (c+ldc*0+16)
: "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"fadd     v0.4s, v5.4s,  v0.4s \r\n"
"fadd     v1.4s, v6.4s,  v1.4s \r\n"
"fadd     v2.4s, v7.4s,  v2.4s \r\n"
"fadd     v3.4s, v8.4s,  v3.4s \r\n"
"fadd     v4.4s, v9.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v5.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v5.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v5.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v5.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v5.s[0]       \r\n"
"fmul    v4.4s,  v4.4s,  v5.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_c0]] \r\n"
"ld1    {v9.4s}, [%[addr_c1]] \r\n"
:
: [addr_c0] "r" (c+ldc*0+0),
[addr_c1] "r" (c+ldc*0+16)
: "v5", "v6", "v7", "v8", "v9");
asm volatile(
"fadd     v0.4s, v5.4s,  v0.4s \r\n"
"fadd     v1.4s, v6.4s,  v1.4s \r\n"
"fadd     v2.4s, v7.4s,  v2.4s \r\n"
"fadd     v3.4s, v8.4s,  v3.4s \r\n"
"fadd     v4.4s, v9.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v10.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_c0]] \r\n"
"ld1    {v9.4s}, [%[addr_c1]] \r\n"
"fmla    v0.4s,  v5.4s,  v10.s[0]       \r\n"
"fmla    v1.4s,  v6.4s,  v10.s[0]       \r\n"
"fmla    v2.4s,  v7.4s,  v10.s[0]       \r\n"
"fmla    v3.4s,  v8.4s,  v10.s[0]       \r\n"
"fmla    v4.4s,  v9.4s,  v10.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0+0),
[addr_c1] "r" (c+ldc*0+16)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v5.4s}, [%[addr_bias]] \r\n"
"dup    v6.4s, v5.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v6.4s \r\n"
"fadd     v1.4s, v1.4s,  v6.4s \r\n"
"fadd     v2.4s, v2.4s,  v6.4s \r\n"
"fadd     v3.4s, v3.4s,  v6.4s \r\n"
"fadd     v4.4s, v4.4s,  v6.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5", "v5", "v6");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v5.4s, w9             \r\n"
"fmax    v0.4s, v5.4s,  v0.4s \r\n"
"fmax    v1.4s, v5.4s,  v1.4s \r\n"
"fmax    v2.4s, v5.4s,  v2.4s \r\n"
"fmax    v3.4s, v5.4s,  v3.4s \r\n"
"fmax    v4.4s, v5.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"str     q0, [%[addr_itm],   0] \r\n"
"str     q1, [%[addr_itm],   16] \r\n"
"str     q2, [%[addr_itm],   32] \r\n"
"str     q3, [%[addr_itm],   48] \r\n"
"str     s4, [%[addr_itm],   64] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"str     q0, [%[addr_c0],   0] \r\n"
"str     q1, [%[addr_c0],   16] \r\n"
"str     q2, [%[addr_c0],   32] \r\n"
"str     q3, [%[addr_c0],   48] \r\n"
"str     s4, [%[addr_c0],   64] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 16, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+16*(kk+0))
: "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+16*kk+0*16),
[addr_b1] "r" (b+16*kk+1*16)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+16*kk+0*16),
[addr_b1] "r" (b+16*kk+1*16),
[addr_b2] "r" (b+16*kk+2*16)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+16*kk+0*16),
[addr_b1] "r" (b+16*kk+1*16),
[addr_b2] "r" (b+16*kk+2*16),
[addr_b3] "r" (b+16*kk+3*16)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
else {
asm volatile(
"	fmla	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmla	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmla	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmla	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+16*(kk+0))
: "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+16*(kk+1))
: "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+16*(kk+2))
: "v13", "v14", "v15", "v16");
}
else {
asm volatile(
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v13", "v14", "v15", "v16");
}
asm volatile(
"	fmla	v0.4s,  v17.4s, v4.s[3]  \r\n"
"	fmla	v1.4s,  v18.4s, v4.s[3]  \r\n"
"	fmla	v2.4s,  v19.4s, v4.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v4.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+16*(kk+3))
: "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmla	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmla	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmla	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
asm volatile(
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v17.4s, v4.s[3]  \r\n"
"	fmla	v1.4s,  v18.4s, v4.s[3]  \r\n"
"	fmla	v2.4s,  v19.4s, v4.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v4.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s4, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+16*(kk+0))
: "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d4, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+16*kk+0*16),
[addr_b1] "r" (b+16*kk+1*16)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q4, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+16*kk+0*16),
[addr_b1] "r" (b+16*kk+1*16),
[addr_b2] "r" (b+16*kk+2*16)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3");
}
asm volatile(
"ldr    q4, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+16*kk+0*16),
[addr_b1] "r" (b+16*kk+1*16),
[addr_b2] "r" (b+16*kk+2*16),
[addr_b3] "r" (b+16*kk+3*16)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmla	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmla	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmla	v3.4s,  v8.4s, v4.s[0]  \r\n"
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
"	fmla	v0.4s,  v17.4s, v4.s[3]  \r\n"
"	fmla	v1.4s,  v18.4s, v4.s[3]  \r\n"
"	fmla	v2.4s,  v19.4s, v4.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v4.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v4.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v4.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v4.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v4.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v4.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v8.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v4.4s,  v8.s[0]       \r\n"
"fmla    v1.4s,  v5.4s,  v8.s[0]       \r\n"
"fmla    v2.4s,  v6.4s,  v8.s[0]       \r\n"
"fmla    v3.4s,  v7.4s,  v8.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_itm0]] \r\n"
:
: [addr_itm0] "r" (itm+16*0)
: "v4", "v5", "v6", "v7");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v4", "v5", "v6", "v7");
}
asm volatile(
"fadd     v0.4s, v4.4s,  v0.4s \r\n"
"fadd     v1.4s, v5.4s,  v1.4s \r\n"
"fadd     v2.4s, v6.4s,  v2.4s \r\n"
"fadd     v3.4s, v7.4s,  v3.4s \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v4.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v4.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v4.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v4.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v4.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v4", "v5", "v6", "v7");
asm volatile(
"fadd     v0.4s, v4.4s,  v0.4s \r\n"
"fadd     v1.4s, v5.4s,  v1.4s \r\n"
"fadd     v2.4s, v6.4s,  v2.4s \r\n"
"fadd     v3.4s, v7.4s,  v3.4s \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v8.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v4.4s,  v8.s[0]       \r\n"
"fmla    v1.4s,  v5.4s,  v8.s[0]       \r\n"
"fmla    v2.4s,  v6.4s,  v8.s[0]       \r\n"
"fmla    v3.4s,  v7.4s,  v8.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v4.4s}, [%[addr_bias]] \r\n"
"dup    v5.4s, v4.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v5.4s \r\n"
"fadd     v1.4s, v1.4s,  v5.4s \r\n"
"fadd     v2.4s, v2.4s,  v5.4s \r\n"
"fadd     v3.4s, v3.4s,  v5.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v4.4s, w9             \r\n"
"fmax    v0.4s, v4.4s,  v0.4s \r\n"
"fmax    v1.4s, v4.4s,  v1.4s \r\n"
"fmax    v2.4s, v4.4s,  v2.4s \r\n"
"fmax    v3.4s, v4.4s,  v3.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"st1    { v0.4s,  v1.4s,  v2.4s,  v3.4s}, [%[addr_itm0]] \r\n"
:
: [addr_itm0] "r" (itm+8*0)
: "memory");}
else {
asm volatile(
"st1    {v0.4s, v1.4s, v2.4s, v3.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 15, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+15*(kk+0))
: "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+15*kk+0*15),
[addr_b1] "r" (b+15*kk+1*15)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+15*kk+0*15),
[addr_b1] "r" (b+15*kk+1*15),
[addr_b2] "r" (b+15*kk+2*15)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+15*kk+0*15),
[addr_b1] "r" (b+15*kk+1*15),
[addr_b2] "r" (b+15*kk+2*15),
[addr_b3] "r" (b+15*kk+3*15)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
else {
asm volatile(
"	fmla	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmla	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmla	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmla	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+15*(kk+0))
: "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+15*(kk+1))
: "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+15*(kk+2))
: "v13", "v14", "v15", "v16");
}
else {
asm volatile(
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v13", "v14", "v15", "v16");
}
asm volatile(
"	fmla	v0.4s,  v17.4s, v4.s[3]  \r\n"
"	fmla	v1.4s,  v18.4s, v4.s[3]  \r\n"
"	fmla	v2.4s,  v19.4s, v4.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v4.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+15*(kk+3))
: "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmla	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmla	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmla	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
asm volatile(
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v17.4s, v4.s[3]  \r\n"
"	fmla	v1.4s,  v18.4s, v4.s[3]  \r\n"
"	fmla	v2.4s,  v19.4s, v4.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v4.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s4, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+15*(kk+0))
: "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d4, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+15*kk+0*15),
[addr_b1] "r" (b+15*kk+1*15)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q4, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+15*kk+0*15),
[addr_b1] "r" (b+15*kk+1*15),
[addr_b2] "r" (b+15*kk+2*15)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3");
}
asm volatile(
"ldr    q4, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+15*kk+0*15),
[addr_b1] "r" (b+15*kk+1*15),
[addr_b2] "r" (b+15*kk+2*15),
[addr_b3] "r" (b+15*kk+3*15)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmla	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmla	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmla	v3.4s,  v8.4s, v4.s[0]  \r\n"
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
"	fmla	v0.4s,  v17.4s, v4.s[3]  \r\n"
"	fmla	v1.4s,  v18.4s, v4.s[3]  \r\n"
"	fmla	v2.4s,  v19.4s, v4.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v4.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v4.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v4.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v4.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v4.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v4.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v8.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v4.4s,  v8.s[0]       \r\n"
"fmla    v1.4s,  v5.4s,  v8.s[0]       \r\n"
"fmla    v2.4s,  v6.4s,  v8.s[0]       \r\n"
"fmla    v3.4s,  v7.4s,  v8.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_itm0]] \r\n"
:
: [addr_itm0] "r" (itm+15*0)
: "v4", "v5", "v6", "v7");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v4", "v5", "v6", "v7");
}
asm volatile(
"fadd     v0.4s, v4.4s,  v0.4s \r\n"
"fadd     v1.4s, v5.4s,  v1.4s \r\n"
"fadd     v2.4s, v6.4s,  v2.4s \r\n"
"fadd     v3.4s, v7.4s,  v3.4s \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v4.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v4.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v4.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v4.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v4.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v4", "v5", "v6", "v7");
asm volatile(
"fadd     v0.4s, v4.4s,  v0.4s \r\n"
"fadd     v1.4s, v5.4s,  v1.4s \r\n"
"fadd     v2.4s, v6.4s,  v2.4s \r\n"
"fadd     v3.4s, v7.4s,  v3.4s \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v8.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v4.4s,  v8.s[0]       \r\n"
"fmla    v1.4s,  v5.4s,  v8.s[0]       \r\n"
"fmla    v2.4s,  v6.4s,  v8.s[0]       \r\n"
"fmla    v3.4s,  v7.4s,  v8.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v4.4s}, [%[addr_bias]] \r\n"
"dup    v5.4s, v4.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v5.4s \r\n"
"fadd     v1.4s, v1.4s,  v5.4s \r\n"
"fadd     v2.4s, v2.4s,  v5.4s \r\n"
"fadd     v3.4s, v3.4s,  v5.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v4.4s, w9             \r\n"
"fmax    v0.4s, v4.4s,  v0.4s \r\n"
"fmax    v1.4s, v4.4s,  v1.4s \r\n"
"fmax    v2.4s, v4.4s,  v2.4s \r\n"
"fmax    v3.4s, v4.4s,  v3.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"mov    s4,  v3.s[2]           \r\n"
"str     q0, [%[addr_itm],   0] \r\n"
"str     q1, [%[addr_itm],   16] \r\n"
"str     q2, [%[addr_itm],   32] \r\n"
"str     d3, [%[addr_itm],   48] \r\n"
"str     s4, [%[addr_itm],   56] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"mov    s4,  v3.s[2]           \r\n"
"str     q0, [%[addr_c0],   0] \r\n"
"str     q1, [%[addr_c0],   16] \r\n"
"str     q2, [%[addr_c0],   32] \r\n"
"str     d3, [%[addr_c0],   48] \r\n"
"str     s4, [%[addr_c0],   56] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 14, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+14*(kk+0))
: "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+14*kk+0*14),
[addr_b1] "r" (b+14*kk+1*14)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+14*kk+0*14),
[addr_b1] "r" (b+14*kk+1*14),
[addr_b2] "r" (b+14*kk+2*14)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+14*kk+0*14),
[addr_b1] "r" (b+14*kk+1*14),
[addr_b2] "r" (b+14*kk+2*14),
[addr_b3] "r" (b+14*kk+3*14)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
else {
asm volatile(
"	fmla	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmla	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmla	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmla	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+14*(kk+0))
: "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+14*(kk+1))
: "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+14*(kk+2))
: "v13", "v14", "v15", "v16");
}
else {
asm volatile(
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v13", "v14", "v15", "v16");
}
asm volatile(
"	fmla	v0.4s,  v17.4s, v4.s[3]  \r\n"
"	fmla	v1.4s,  v18.4s, v4.s[3]  \r\n"
"	fmla	v2.4s,  v19.4s, v4.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v4.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+14*(kk+3))
: "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmla	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmla	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmla	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
asm volatile(
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v17.4s, v4.s[3]  \r\n"
"	fmla	v1.4s,  v18.4s, v4.s[3]  \r\n"
"	fmla	v2.4s,  v19.4s, v4.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v4.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s4, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+14*(kk+0))
: "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d4, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+14*kk+0*14),
[addr_b1] "r" (b+14*kk+1*14)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q4, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+14*kk+0*14),
[addr_b1] "r" (b+14*kk+1*14),
[addr_b2] "r" (b+14*kk+2*14)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3");
}
asm volatile(
"ldr    q4, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+14*kk+0*14),
[addr_b1] "r" (b+14*kk+1*14),
[addr_b2] "r" (b+14*kk+2*14),
[addr_b3] "r" (b+14*kk+3*14)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmla	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmla	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmla	v3.4s,  v8.4s, v4.s[0]  \r\n"
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
"	fmla	v0.4s,  v17.4s, v4.s[3]  \r\n"
"	fmla	v1.4s,  v18.4s, v4.s[3]  \r\n"
"	fmla	v2.4s,  v19.4s, v4.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v4.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v4.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v4.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v4.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v4.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v4.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v8.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v4.4s,  v8.s[0]       \r\n"
"fmla    v1.4s,  v5.4s,  v8.s[0]       \r\n"
"fmla    v2.4s,  v6.4s,  v8.s[0]       \r\n"
"fmla    v3.4s,  v7.4s,  v8.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_itm0]] \r\n"
:
: [addr_itm0] "r" (itm+14*0)
: "v4", "v5", "v6", "v7");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v4", "v5", "v6", "v7");
}
asm volatile(
"fadd     v0.4s, v4.4s,  v0.4s \r\n"
"fadd     v1.4s, v5.4s,  v1.4s \r\n"
"fadd     v2.4s, v6.4s,  v2.4s \r\n"
"fadd     v3.4s, v7.4s,  v3.4s \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v4.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v4.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v4.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v4.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v4.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v4", "v5", "v6", "v7");
asm volatile(
"fadd     v0.4s, v4.4s,  v0.4s \r\n"
"fadd     v1.4s, v5.4s,  v1.4s \r\n"
"fadd     v2.4s, v6.4s,  v2.4s \r\n"
"fadd     v3.4s, v7.4s,  v3.4s \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v8.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v4.4s,  v8.s[0]       \r\n"
"fmla    v1.4s,  v5.4s,  v8.s[0]       \r\n"
"fmla    v2.4s,  v6.4s,  v8.s[0]       \r\n"
"fmla    v3.4s,  v7.4s,  v8.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v4.4s}, [%[addr_bias]] \r\n"
"dup    v5.4s, v4.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v5.4s \r\n"
"fadd     v1.4s, v1.4s,  v5.4s \r\n"
"fadd     v2.4s, v2.4s,  v5.4s \r\n"
"fadd     v3.4s, v3.4s,  v5.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v4.4s, w9             \r\n"
"fmax    v0.4s, v4.4s,  v0.4s \r\n"
"fmax    v1.4s, v4.4s,  v1.4s \r\n"
"fmax    v2.4s, v4.4s,  v2.4s \r\n"
"fmax    v3.4s, v4.4s,  v3.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"str     q0, [%[addr_itm],   0] \r\n"
"str     q1, [%[addr_itm],   16] \r\n"
"str     q2, [%[addr_itm],   32] \r\n"
"str     d3, [%[addr_itm],   48] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"str     q0, [%[addr_c0],   0] \r\n"
"str     q1, [%[addr_c0],   16] \r\n"
"str     q2, [%[addr_c0],   32] \r\n"
"str     d3, [%[addr_c0],   48] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 13, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+13*(kk+0))
: "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+13*kk+0*13),
[addr_b1] "r" (b+13*kk+1*13)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+13*kk+0*13),
[addr_b1] "r" (b+13*kk+1*13),
[addr_b2] "r" (b+13*kk+2*13)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+13*kk+0*13),
[addr_b1] "r" (b+13*kk+1*13),
[addr_b2] "r" (b+13*kk+2*13),
[addr_b3] "r" (b+13*kk+3*13)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
else {
asm volatile(
"	fmla	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmla	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmla	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmla	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+13*(kk+0))
: "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+13*(kk+1))
: "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+13*(kk+2))
: "v13", "v14", "v15", "v16");
}
else {
asm volatile(
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v13", "v14", "v15", "v16");
}
asm volatile(
"	fmla	v0.4s,  v17.4s, v4.s[3]  \r\n"
"	fmla	v1.4s,  v18.4s, v4.s[3]  \r\n"
"	fmla	v2.4s,  v19.4s, v4.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v4.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"ld1    {v4.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+13*(kk+3))
: "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmla	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmla	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmla	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
asm volatile(
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
asm volatile(
"	fmla	v0.4s,  v17.4s, v4.s[3]  \r\n"
"	fmla	v1.4s,  v18.4s, v4.s[3]  \r\n"
"	fmla	v2.4s,  v19.4s, v4.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v4.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s4, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+13*(kk+0))
: "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d4, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+13*kk+0*13),
[addr_b1] "r" (b+13*kk+1*13)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q4, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+13*kk+0*13),
[addr_b1] "r" (b+13*kk+1*13),
[addr_b2] "r" (b+13*kk+2*13)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
asm volatile(
"	fmul	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmul	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmul	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmul	v3.4s,  v8.4s, v4.s[0]  \r\n"
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3");
}
asm volatile(
"ldr    q4, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v4");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+13*kk+0*13),
[addr_b1] "r" (b+13*kk+1*13),
[addr_b2] "r" (b+13*kk+2*13),
[addr_b3] "r" (b+13*kk+3*13)
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_b0]] \r\n"
"ld1    {v9.4s, v10.4s, v11.4s, v12.4s}, [%[addr_b1]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s, v16.4s}, [%[addr_b2]] \r\n"
"ld1    {v17.4s, v18.4s, v19.4s, v20.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v4.s[0]  \r\n"
"	fmla	v1.4s,  v6.4s, v4.s[0]  \r\n"
"	fmla	v2.4s,  v7.4s, v4.s[0]  \r\n"
"	fmla	v3.4s,  v8.4s, v4.s[0]  \r\n"
"	fmla	v0.4s,  v9.4s, v4.s[1]  \r\n"
"	fmla	v1.4s,  v10.4s, v4.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v4.s[1]  \r\n"
"	fmla	v3.4s,  v12.4s, v4.s[1]  \r\n"
"	fmla	v0.4s,  v13.4s, v4.s[2]  \r\n"
"	fmla	v1.4s,  v14.4s, v4.s[2]  \r\n"
"	fmla	v2.4s,  v15.4s, v4.s[2]  \r\n"
"	fmla	v3.4s,  v16.4s, v4.s[2]  \r\n"
"	fmla	v0.4s,  v17.4s, v4.s[3]  \r\n"
"	fmla	v1.4s,  v18.4s, v4.s[3]  \r\n"
"	fmla	v2.4s,  v19.4s, v4.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v4.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v4.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v4.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v4.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v4.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v4.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v8.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v4.4s,  v8.s[0]       \r\n"
"fmla    v1.4s,  v5.4s,  v8.s[0]       \r\n"
"fmla    v2.4s,  v6.4s,  v8.s[0]       \r\n"
"fmla    v3.4s,  v7.4s,  v8.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_itm0]] \r\n"
:
: [addr_itm0] "r" (itm+13*0)
: "v4", "v5", "v6", "v7");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v4", "v5", "v6", "v7");
}
asm volatile(
"fadd     v0.4s, v4.4s,  v0.4s \r\n"
"fadd     v1.4s, v5.4s,  v1.4s \r\n"
"fadd     v2.4s, v6.4s,  v2.4s \r\n"
"fadd     v3.4s, v7.4s,  v3.4s \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v4.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v4.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v4.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v4.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v4.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v4", "v5", "v6", "v7");
asm volatile(
"fadd     v0.4s, v4.4s,  v0.4s \r\n"
"fadd     v1.4s, v5.4s,  v1.4s \r\n"
"fadd     v2.4s, v6.4s,  v2.4s \r\n"
"fadd     v3.4s, v7.4s,  v3.4s \r\n"
:
:
: "v0", "v1", "v2", "v3");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v8.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v4.4s, v5.4s, v6.4s, v7.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v4.4s,  v8.s[0]       \r\n"
"fmla    v1.4s,  v5.4s,  v8.s[0]       \r\n"
"fmla    v2.4s,  v6.4s,  v8.s[0]       \r\n"
"fmla    v3.4s,  v7.4s,  v8.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v4.4s}, [%[addr_bias]] \r\n"
"dup    v5.4s, v4.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v5.4s \r\n"
"fadd     v1.4s, v1.4s,  v5.4s \r\n"
"fadd     v2.4s, v2.4s,  v5.4s \r\n"
"fadd     v3.4s, v3.4s,  v5.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v4.4s, w9             \r\n"
"fmax    v0.4s, v4.4s,  v0.4s \r\n"
"fmax    v1.4s, v4.4s,  v1.4s \r\n"
"fmax    v2.4s, v4.4s,  v2.4s \r\n"
"fmax    v3.4s, v4.4s,  v3.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"str     q0, [%[addr_itm],   0] \r\n"
"str     q1, [%[addr_itm],   16] \r\n"
"str     q2, [%[addr_itm],   32] \r\n"
"str     s3, [%[addr_itm],   48] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"str     q0, [%[addr_c0],   0] \r\n"
"str     q1, [%[addr_c0],   16] \r\n"
"str     q2, [%[addr_c0],   32] \r\n"
"str     s3, [%[addr_c0],   48] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 12, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+12*(kk+0))
: "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v4", "v5", "v6");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+12*kk+0*12),
[addr_b1] "r" (b+12*kk+1*12)
: "v4", "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v4", "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+12*kk+0*12),
[addr_b1] "r" (b+12*kk+1*12),
[addr_b2] "r" (b+12*kk+2*12)
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
:
:
: "v0", "v1", "v2");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+12*kk+0*12),
[addr_b1] "r" (b+12*kk+1*12),
[addr_b2] "r" (b+12*kk+2*12),
[addr_b3] "r" (b+12*kk+3*12)
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
}
else {
asm volatile(
"	fmla	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmla	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmla	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+12*(kk+0))
: "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v4", "v5", "v6");
}
asm volatile(
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+12*(kk+1))
: "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v7", "v8", "v9");
}
asm volatile(
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
:
:
: "v0", "v1", "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+12*(kk+2))
: "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v10", "v11", "v12");
}
asm volatile(
"	fmla	v0.4s,  v13.4s, v3.s[3]  \r\n"
"	fmla	v1.4s,  v14.4s, v3.s[3]  \r\n"
"	fmla	v2.4s,  v15.4s, v3.s[3]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+12*(kk+3))
: "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v13", "v14", "v15");
}
asm volatile(
"	fmla	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmla	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmla	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
}
asm volatile(
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v13.4s, v3.s[3]  \r\n"
"	fmla	v1.4s,  v14.4s, v3.s[3]  \r\n"
"	fmla	v2.4s,  v15.4s, v3.s[3]  \r\n"
:
:
: "v0", "v1", "v2");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s3, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+12*(kk+0))
: "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v4", "v5", "v6");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d3, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+12*kk+0*12),
[addr_b1] "r" (b+12*kk+1*12)
: "v4", "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v4", "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q3, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+12*kk+0*12),
[addr_b1] "r" (b+12*kk+1*12),
[addr_b2] "r" (b+12*kk+2*12)
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
:
:
: "v0", "v1", "v2");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2");
}
asm volatile(
"ldr    q3, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+12*kk+0*12),
[addr_b1] "r" (b+12*kk+1*12),
[addr_b2] "r" (b+12*kk+2*12),
[addr_b3] "r" (b+12*kk+3*12)
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
asm volatile(
"	fmla	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmla	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmla	v2.4s,  v6.4s, v3.s[0]  \r\n"
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
"	fmla	v0.4s,  v13.4s, v3.s[3]  \r\n"
"	fmla	v1.4s,  v14.4s, v3.s[3]  \r\n"
"	fmla	v2.4s,  v15.4s, v3.s[3]  \r\n"
:
:
: "v0", "v1", "v2");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v3.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v3.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v3.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v3.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v6.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v3.4s,  v6.s[0]       \r\n"
"fmla    v1.4s,  v4.4s,  v6.s[0]       \r\n"
"fmla    v2.4s,  v5.4s,  v6.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_itm0]] \r\n"
:
: [addr_itm0] "r" (itm+12*0)
: "v3", "v4", "v5");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v3", "v4", "v5");
}
asm volatile(
"fadd     v0.4s, v3.4s,  v0.4s \r\n"
"fadd     v1.4s, v4.4s,  v1.4s \r\n"
"fadd     v2.4s, v5.4s,  v2.4s \r\n"
:
:
: "v0", "v1", "v2");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v3.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v3.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v3.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v3.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v3", "v4", "v5");
asm volatile(
"fadd     v0.4s, v3.4s,  v0.4s \r\n"
"fadd     v1.4s, v4.4s,  v1.4s \r\n"
"fadd     v2.4s, v5.4s,  v2.4s \r\n"
:
:
: "v0", "v1", "v2");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v6.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v3.4s,  v6.s[0]       \r\n"
"fmla    v1.4s,  v4.4s,  v6.s[0]       \r\n"
"fmla    v2.4s,  v5.4s,  v6.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v3.4s}, [%[addr_bias]] \r\n"
"dup    v4.4s, v3.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v4.4s \r\n"
"fadd     v1.4s, v1.4s,  v4.4s \r\n"
"fadd     v2.4s, v2.4s,  v4.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v3.4s, w9             \r\n"
"fmax    v0.4s, v3.4s,  v0.4s \r\n"
"fmax    v1.4s, v3.4s,  v1.4s \r\n"
"fmax    v2.4s, v3.4s,  v2.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"st1    { v0.4s,  v1.4s,  v2.4s}, [%[addr_itm0]] \r\n"
:
: [addr_itm0] "r" (itm+8*0)
: "memory");}
else {
asm volatile(
"st1    {v0.4s, v1.4s, v2.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 11, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+11*(kk+0))
: "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v4", "v5", "v6");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+11*kk+0*11),
[addr_b1] "r" (b+11*kk+1*11)
: "v4", "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v4", "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+11*kk+0*11),
[addr_b1] "r" (b+11*kk+1*11),
[addr_b2] "r" (b+11*kk+2*11)
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
:
:
: "v0", "v1", "v2");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+11*kk+0*11),
[addr_b1] "r" (b+11*kk+1*11),
[addr_b2] "r" (b+11*kk+2*11),
[addr_b3] "r" (b+11*kk+3*11)
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
}
else {
asm volatile(
"	fmla	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmla	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmla	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+11*(kk+0))
: "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v4", "v5", "v6");
}
asm volatile(
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+11*(kk+1))
: "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v7", "v8", "v9");
}
asm volatile(
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
:
:
: "v0", "v1", "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+11*(kk+2))
: "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v10", "v11", "v12");
}
asm volatile(
"	fmla	v0.4s,  v13.4s, v3.s[3]  \r\n"
"	fmla	v1.4s,  v14.4s, v3.s[3]  \r\n"
"	fmla	v2.4s,  v15.4s, v3.s[3]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+11*(kk+3))
: "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v13", "v14", "v15");
}
asm volatile(
"	fmla	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmla	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmla	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
}
asm volatile(
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v13.4s, v3.s[3]  \r\n"
"	fmla	v1.4s,  v14.4s, v3.s[3]  \r\n"
"	fmla	v2.4s,  v15.4s, v3.s[3]  \r\n"
:
:
: "v0", "v1", "v2");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s3, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+11*(kk+0))
: "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v4", "v5", "v6");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d3, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+11*kk+0*11),
[addr_b1] "r" (b+11*kk+1*11)
: "v4", "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v4", "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q3, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+11*kk+0*11),
[addr_b1] "r" (b+11*kk+1*11),
[addr_b2] "r" (b+11*kk+2*11)
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
:
:
: "v0", "v1", "v2");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2");
}
asm volatile(
"ldr    q3, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+11*kk+0*11),
[addr_b1] "r" (b+11*kk+1*11),
[addr_b2] "r" (b+11*kk+2*11),
[addr_b3] "r" (b+11*kk+3*11)
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
asm volatile(
"	fmla	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmla	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmla	v2.4s,  v6.4s, v3.s[0]  \r\n"
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
"	fmla	v0.4s,  v13.4s, v3.s[3]  \r\n"
"	fmla	v1.4s,  v14.4s, v3.s[3]  \r\n"
"	fmla	v2.4s,  v15.4s, v3.s[3]  \r\n"
:
:
: "v0", "v1", "v2");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v3.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v3.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v3.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v3.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v6.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v3.4s,  v6.s[0]       \r\n"
"fmla    v1.4s,  v4.4s,  v6.s[0]       \r\n"
"fmla    v2.4s,  v5.4s,  v6.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_itm0]] \r\n"
:
: [addr_itm0] "r" (itm+11*0)
: "v3", "v4", "v5");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v3", "v4", "v5");
}
asm volatile(
"fadd     v0.4s, v3.4s,  v0.4s \r\n"
"fadd     v1.4s, v4.4s,  v1.4s \r\n"
"fadd     v2.4s, v5.4s,  v2.4s \r\n"
:
:
: "v0", "v1", "v2");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v3.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v3.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v3.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v3.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v3", "v4", "v5");
asm volatile(
"fadd     v0.4s, v3.4s,  v0.4s \r\n"
"fadd     v1.4s, v4.4s,  v1.4s \r\n"
"fadd     v2.4s, v5.4s,  v2.4s \r\n"
:
:
: "v0", "v1", "v2");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v6.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v3.4s,  v6.s[0]       \r\n"
"fmla    v1.4s,  v4.4s,  v6.s[0]       \r\n"
"fmla    v2.4s,  v5.4s,  v6.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v3.4s}, [%[addr_bias]] \r\n"
"dup    v4.4s, v3.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v4.4s \r\n"
"fadd     v1.4s, v1.4s,  v4.4s \r\n"
"fadd     v2.4s, v2.4s,  v4.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v3.4s, w9             \r\n"
"fmax    v0.4s, v3.4s,  v0.4s \r\n"
"fmax    v1.4s, v3.4s,  v1.4s \r\n"
"fmax    v2.4s, v3.4s,  v2.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"mov    s3,  v2.s[2]           \r\n"
"str     q0, [%[addr_itm],   0] \r\n"
"str     q1, [%[addr_itm],   16] \r\n"
"str     d2, [%[addr_itm],   32] \r\n"
"str     s3, [%[addr_itm],   40] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"mov    s3,  v2.s[2]           \r\n"
"str     q0, [%[addr_c0],   0] \r\n"
"str     q1, [%[addr_c0],   16] \r\n"
"str     d2, [%[addr_c0],   32] \r\n"
"str     s3, [%[addr_c0],   40] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 10, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+10*(kk+0))
: "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v4", "v5", "v6");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+10*kk+0*10),
[addr_b1] "r" (b+10*kk+1*10)
: "v4", "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v4", "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+10*kk+0*10),
[addr_b1] "r" (b+10*kk+1*10),
[addr_b2] "r" (b+10*kk+2*10)
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
:
:
: "v0", "v1", "v2");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+10*kk+0*10),
[addr_b1] "r" (b+10*kk+1*10),
[addr_b2] "r" (b+10*kk+2*10),
[addr_b3] "r" (b+10*kk+3*10)
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
}
else {
asm volatile(
"	fmla	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmla	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmla	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+10*(kk+0))
: "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v4", "v5", "v6");
}
asm volatile(
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+10*(kk+1))
: "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v7", "v8", "v9");
}
asm volatile(
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
:
:
: "v0", "v1", "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+10*(kk+2))
: "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v10", "v11", "v12");
}
asm volatile(
"	fmla	v0.4s,  v13.4s, v3.s[3]  \r\n"
"	fmla	v1.4s,  v14.4s, v3.s[3]  \r\n"
"	fmla	v2.4s,  v15.4s, v3.s[3]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+10*(kk+3))
: "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v13", "v14", "v15");
}
asm volatile(
"	fmla	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmla	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmla	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
}
asm volatile(
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v13.4s, v3.s[3]  \r\n"
"	fmla	v1.4s,  v14.4s, v3.s[3]  \r\n"
"	fmla	v2.4s,  v15.4s, v3.s[3]  \r\n"
:
:
: "v0", "v1", "v2");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s3, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+10*(kk+0))
: "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v4", "v5", "v6");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d3, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+10*kk+0*10),
[addr_b1] "r" (b+10*kk+1*10)
: "v4", "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v4", "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q3, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+10*kk+0*10),
[addr_b1] "r" (b+10*kk+1*10),
[addr_b2] "r" (b+10*kk+2*10)
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
:
:
: "v0", "v1", "v2");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2");
}
asm volatile(
"ldr    q3, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+10*kk+0*10),
[addr_b1] "r" (b+10*kk+1*10),
[addr_b2] "r" (b+10*kk+2*10),
[addr_b3] "r" (b+10*kk+3*10)
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
asm volatile(
"	fmla	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmla	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmla	v2.4s,  v6.4s, v3.s[0]  \r\n"
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
"	fmla	v0.4s,  v13.4s, v3.s[3]  \r\n"
"	fmla	v1.4s,  v14.4s, v3.s[3]  \r\n"
"	fmla	v2.4s,  v15.4s, v3.s[3]  \r\n"
:
:
: "v0", "v1", "v2");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v3.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v3.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v3.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v3.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v6.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v3.4s,  v6.s[0]       \r\n"
"fmla    v1.4s,  v4.4s,  v6.s[0]       \r\n"
"fmla    v2.4s,  v5.4s,  v6.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_itm0]] \r\n"
:
: [addr_itm0] "r" (itm+10*0)
: "v3", "v4", "v5");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v3", "v4", "v5");
}
asm volatile(
"fadd     v0.4s, v3.4s,  v0.4s \r\n"
"fadd     v1.4s, v4.4s,  v1.4s \r\n"
"fadd     v2.4s, v5.4s,  v2.4s \r\n"
:
:
: "v0", "v1", "v2");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v3.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v3.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v3.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v3.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v3", "v4", "v5");
asm volatile(
"fadd     v0.4s, v3.4s,  v0.4s \r\n"
"fadd     v1.4s, v4.4s,  v1.4s \r\n"
"fadd     v2.4s, v5.4s,  v2.4s \r\n"
:
:
: "v0", "v1", "v2");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v6.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v3.4s,  v6.s[0]       \r\n"
"fmla    v1.4s,  v4.4s,  v6.s[0]       \r\n"
"fmla    v2.4s,  v5.4s,  v6.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v3.4s}, [%[addr_bias]] \r\n"
"dup    v4.4s, v3.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v4.4s \r\n"
"fadd     v1.4s, v1.4s,  v4.4s \r\n"
"fadd     v2.4s, v2.4s,  v4.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v3.4s, w9             \r\n"
"fmax    v0.4s, v3.4s,  v0.4s \r\n"
"fmax    v1.4s, v3.4s,  v1.4s \r\n"
"fmax    v2.4s, v3.4s,  v2.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"str     q0, [%[addr_itm],   0] \r\n"
"str     q1, [%[addr_itm],   16] \r\n"
"str     d2, [%[addr_itm],   32] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"str     q0, [%[addr_c0],   0] \r\n"
"str     q1, [%[addr_c0],   16] \r\n"
"str     d2, [%[addr_c0],   32] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 9, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+9*(kk+0))
: "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v4", "v5", "v6");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+9*kk+0*9),
[addr_b1] "r" (b+9*kk+1*9)
: "v4", "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v4", "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+9*kk+0*9),
[addr_b1] "r" (b+9*kk+1*9),
[addr_b2] "r" (b+9*kk+2*9)
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
:
:
: "v0", "v1", "v2");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+9*kk+0*9),
[addr_b1] "r" (b+9*kk+1*9),
[addr_b2] "r" (b+9*kk+2*9),
[addr_b3] "r" (b+9*kk+3*9)
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
}
else {
asm volatile(
"	fmla	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmla	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmla	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+9*(kk+0))
: "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v4", "v5", "v6");
}
asm volatile(
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+9*(kk+1))
: "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v7", "v8", "v9");
}
asm volatile(
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
:
:
: "v0", "v1", "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+9*(kk+2))
: "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v10", "v11", "v12");
}
asm volatile(
"	fmla	v0.4s,  v13.4s, v3.s[3]  \r\n"
"	fmla	v1.4s,  v14.4s, v3.s[3]  \r\n"
"	fmla	v2.4s,  v15.4s, v3.s[3]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"ld1    {v3.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+9*(kk+3))
: "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v13", "v14", "v15");
}
asm volatile(
"	fmla	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmla	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmla	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
}
asm volatile(
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
:
:
: "v0", "v1", "v2");
asm volatile(
"	fmla	v0.4s,  v13.4s, v3.s[3]  \r\n"
"	fmla	v1.4s,  v14.4s, v3.s[3]  \r\n"
"	fmla	v2.4s,  v15.4s, v3.s[3]  \r\n"
:
:
: "v0", "v1", "v2");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s3, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+9*(kk+0))
: "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v4", "v5", "v6");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
:
:
: "v0", "v1", "v2");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d3, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+9*kk+0*9),
[addr_b1] "r" (b+9*kk+1*9)
: "v4", "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v4", "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
:
:
: "v0", "v1", "v2");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q3, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+9*kk+0*9),
[addr_b1] "r" (b+9*kk+1*9),
[addr_b2] "r" (b+9*kk+2*9)
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmul	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmul	v2.4s,  v6.4s, v3.s[0]  \r\n"
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
:
:
: "v0", "v1", "v2");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2");
}
asm volatile(
"ldr    q3, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v3");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+9*kk+0*9),
[addr_b1] "r" (b+9*kk+1*9),
[addr_b2] "r" (b+9*kk+2*9),
[addr_b3] "r" (b+9*kk+3*9)
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
else {
asm volatile(
"ld1    {v4.4s, v5.4s, v6.4s}, [%[addr_b0]] \r\n"
"ld1    {v7.4s, v8.4s, v9.4s}, [%[addr_b1]] \r\n"
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s, v14.4s, v15.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15");
}
asm volatile(
"	fmla	v0.4s,  v4.4s, v3.s[0]  \r\n"
"	fmla	v1.4s,  v5.4s, v3.s[0]  \r\n"
"	fmla	v2.4s,  v6.4s, v3.s[0]  \r\n"
"	fmla	v0.4s,  v7.4s, v3.s[1]  \r\n"
"	fmla	v1.4s,  v8.4s, v3.s[1]  \r\n"
"	fmla	v2.4s,  v9.4s, v3.s[1]  \r\n"
"	fmla	v0.4s,  v10.4s, v3.s[2]  \r\n"
"	fmla	v1.4s,  v11.4s, v3.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v3.s[2]  \r\n"
"	fmla	v0.4s,  v13.4s, v3.s[3]  \r\n"
"	fmla	v1.4s,  v14.4s, v3.s[3]  \r\n"
"	fmla	v2.4s,  v15.4s, v3.s[3]  \r\n"
:
:
: "v0", "v1", "v2");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v3.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v3.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v3.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v3.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v6.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v3.4s,  v6.s[0]       \r\n"
"fmla    v1.4s,  v4.4s,  v6.s[0]       \r\n"
"fmla    v2.4s,  v5.4s,  v6.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_itm0]] \r\n"
:
: [addr_itm0] "r" (itm+9*0)
: "v3", "v4", "v5");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v3", "v4", "v5");
}
asm volatile(
"fadd     v0.4s, v3.4s,  v0.4s \r\n"
"fadd     v1.4s, v4.4s,  v1.4s \r\n"
"fadd     v2.4s, v5.4s,  v2.4s \r\n"
:
:
: "v0", "v1", "v2");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v3.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v3.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v3.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v3.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v3", "v4", "v5");
asm volatile(
"fadd     v0.4s, v3.4s,  v0.4s \r\n"
"fadd     v1.4s, v4.4s,  v1.4s \r\n"
"fadd     v2.4s, v5.4s,  v2.4s \r\n"
:
:
: "v0", "v1", "v2");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v6.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v3.4s, v4.4s, v5.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v3.4s,  v6.s[0]       \r\n"
"fmla    v1.4s,  v4.4s,  v6.s[0]       \r\n"
"fmla    v2.4s,  v5.4s,  v6.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v3.4s}, [%[addr_bias]] \r\n"
"dup    v4.4s, v3.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v4.4s \r\n"
"fadd     v1.4s, v1.4s,  v4.4s \r\n"
"fadd     v2.4s, v2.4s,  v4.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v3.4s, w9             \r\n"
"fmax    v0.4s, v3.4s,  v0.4s \r\n"
"fmax    v1.4s, v3.4s,  v1.4s \r\n"
"fmax    v2.4s, v3.4s,  v2.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"str     q0, [%[addr_itm],   0] \r\n"
"str     q1, [%[addr_itm],   16] \r\n"
"str     s2, [%[addr_itm],   32] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"str     q0, [%[addr_c0],   0] \r\n"
"str     q1, [%[addr_c0],   16] \r\n"
"str     s2, [%[addr_c0],   32] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 8, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+8*(kk+0))
: "v3", "v4");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v3", "v4");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+8*kk+0*8),
[addr_b1] "r" (b+8*kk+1*8)
: "v3", "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v3", "v4", "v5", "v6");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+8*kk+0*8),
[addr_b1] "r" (b+8*kk+1*8),
[addr_b2] "r" (b+8*kk+2*8)
: "v3", "v4", "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v3", "v4", "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
:
:
: "v0", "v1");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
"ld1    {v9.4s, v10.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+8*kk+0*8),
[addr_b1] "r" (b+8*kk+1*8),
[addr_b2] "r" (b+8*kk+2*8),
[addr_b3] "r" (b+8*kk+3*8)
: "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
"ld1    {v9.4s, v10.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
}
else {
asm volatile(
"	fmla	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmla	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+8*(kk+0))
: "v3", "v4");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v3", "v4");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+8*(kk+1))
: "v5", "v6");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v5", "v6");
}
asm volatile(
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
:
:
: "v0", "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+8*(kk+2))
: "v7", "v8");
}
else {
asm volatile(
"ld1    {v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v7", "v8");
}
asm volatile(
"	fmla	v0.4s,  v9.4s, v2.s[3]  \r\n"
"	fmla	v1.4s,  v10.4s, v2.s[3]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v9.4s, v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+8*(kk+3))
: "v9", "v10");
}
else {
asm volatile(
"ld1    {v9.4s, v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v9", "v10");
}
asm volatile(
"	fmla	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmla	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v9.4s, v2.s[3]  \r\n"
"	fmla	v1.4s,  v10.4s, v2.s[3]  \r\n"
:
:
: "v0", "v1");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s2, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+8*(kk+0))
: "v3", "v4");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v3", "v4");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d2, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+8*kk+0*8),
[addr_b1] "r" (b+8*kk+1*8)
: "v3", "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v3", "v4", "v5", "v6");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q2, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+8*kk+0*8),
[addr_b1] "r" (b+8*kk+1*8),
[addr_b2] "r" (b+8*kk+2*8)
: "v3", "v4", "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v3", "v4", "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
:
:
: "v0", "v1");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1");
}
asm volatile(
"ldr    q2, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
"ld1    {v9.4s, v10.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+8*kk+0*8),
[addr_b1] "r" (b+8*kk+1*8),
[addr_b2] "r" (b+8*kk+2*8),
[addr_b3] "r" (b+8*kk+3*8)
: "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
"ld1    {v9.4s, v10.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
asm volatile(
"	fmla	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmla	v1.4s,  v4.4s, v2.s[0]  \r\n"
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
"	fmla	v0.4s,  v9.4s, v2.s[3]  \r\n"
"	fmla	v1.4s,  v10.4s, v2.s[3]  \r\n"
:
:
: "v0", "v1");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v2.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v2.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v2.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v4.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v2.4s, v3.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v2.4s,  v4.s[0]       \r\n"
"fmla    v1.4s,  v3.4s,  v4.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v2.4s, v3.4s}, [%[addr_itm0]] \r\n"
:
: [addr_itm0] "r" (itm+8*0)
: "v2", "v3");
}
else {
asm volatile(
"ld1    {v2.4s, v3.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v2", "v3");
}
asm volatile(
"fadd     v0.4s, v2.4s,  v0.4s \r\n"
"fadd     v1.4s, v3.4s,  v1.4s \r\n"
:
:
: "v0", "v1");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v2.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v2.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v2.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v2.4s, v3.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v2", "v3");
asm volatile(
"fadd     v0.4s, v2.4s,  v0.4s \r\n"
"fadd     v1.4s, v3.4s,  v1.4s \r\n"
:
:
: "v0", "v1");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v4.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v2.4s, v3.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v2.4s,  v4.s[0]       \r\n"
"fmla    v1.4s,  v3.4s,  v4.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v2.4s}, [%[addr_bias]] \r\n"
"dup    v3.4s, v2.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v3.4s \r\n"
"fadd     v1.4s, v1.4s,  v3.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v2.4s, w9             \r\n"
"fmax    v0.4s, v2.4s,  v0.4s \r\n"
"fmax    v1.4s, v2.4s,  v1.4s \r\n"
:
:
: "v0", "v1", "v2", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"st1    { v0.4s,  v1.4s}, [%[addr_itm0]] \r\n"
:
: [addr_itm0] "r" (itm+8*0)
: "memory");}
else {
asm volatile(
"st1    {v0.4s, v1.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 7, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+7*(kk+0))
: "v3", "v4");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v3", "v4");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+7*kk+0*7),
[addr_b1] "r" (b+7*kk+1*7)
: "v3", "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v3", "v4", "v5", "v6");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+7*kk+0*7),
[addr_b1] "r" (b+7*kk+1*7),
[addr_b2] "r" (b+7*kk+2*7)
: "v3", "v4", "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v3", "v4", "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
:
:
: "v0", "v1");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
"ld1    {v9.4s, v10.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+7*kk+0*7),
[addr_b1] "r" (b+7*kk+1*7),
[addr_b2] "r" (b+7*kk+2*7),
[addr_b3] "r" (b+7*kk+3*7)
: "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
"ld1    {v9.4s, v10.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
}
else {
asm volatile(
"	fmla	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmla	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+7*(kk+0))
: "v3", "v4");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v3", "v4");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+7*(kk+1))
: "v5", "v6");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v5", "v6");
}
asm volatile(
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
:
:
: "v0", "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+7*(kk+2))
: "v7", "v8");
}
else {
asm volatile(
"ld1    {v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v7", "v8");
}
asm volatile(
"	fmla	v0.4s,  v9.4s, v2.s[3]  \r\n"
"	fmla	v1.4s,  v10.4s, v2.s[3]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v9.4s, v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+7*(kk+3))
: "v9", "v10");
}
else {
asm volatile(
"ld1    {v9.4s, v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v9", "v10");
}
asm volatile(
"	fmla	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmla	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v9.4s, v2.s[3]  \r\n"
"	fmla	v1.4s,  v10.4s, v2.s[3]  \r\n"
:
:
: "v0", "v1");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s2, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+7*(kk+0))
: "v3", "v4");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v3", "v4");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d2, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+7*kk+0*7),
[addr_b1] "r" (b+7*kk+1*7)
: "v3", "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v3", "v4", "v5", "v6");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q2, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+7*kk+0*7),
[addr_b1] "r" (b+7*kk+1*7),
[addr_b2] "r" (b+7*kk+2*7)
: "v3", "v4", "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v3", "v4", "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
:
:
: "v0", "v1");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1");
}
asm volatile(
"ldr    q2, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
"ld1    {v9.4s, v10.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+7*kk+0*7),
[addr_b1] "r" (b+7*kk+1*7),
[addr_b2] "r" (b+7*kk+2*7),
[addr_b3] "r" (b+7*kk+3*7)
: "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
"ld1    {v9.4s, v10.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
asm volatile(
"	fmla	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmla	v1.4s,  v4.4s, v2.s[0]  \r\n"
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
"	fmla	v0.4s,  v9.4s, v2.s[3]  \r\n"
"	fmla	v1.4s,  v10.4s, v2.s[3]  \r\n"
:
:
: "v0", "v1");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v2.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v2.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v2.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v4.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v2.4s, v3.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v2.4s,  v4.s[0]       \r\n"
"fmla    v1.4s,  v3.4s,  v4.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v2.4s, v3.4s}, [%[addr_itm0]] \r\n"
:
: [addr_itm0] "r" (itm+7*0)
: "v2", "v3");
}
else {
asm volatile(
"ld1    {v2.4s, v3.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v2", "v3");
}
asm volatile(
"fadd     v0.4s, v2.4s,  v0.4s \r\n"
"fadd     v1.4s, v3.4s,  v1.4s \r\n"
:
:
: "v0", "v1");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v2.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v2.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v2.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v2.4s, v3.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v2", "v3");
asm volatile(
"fadd     v0.4s, v2.4s,  v0.4s \r\n"
"fadd     v1.4s, v3.4s,  v1.4s \r\n"
:
:
: "v0", "v1");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v4.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v2.4s, v3.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v2.4s,  v4.s[0]       \r\n"
"fmla    v1.4s,  v3.4s,  v4.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v2.4s}, [%[addr_bias]] \r\n"
"dup    v3.4s, v2.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v3.4s \r\n"
"fadd     v1.4s, v1.4s,  v3.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v2.4s, w9             \r\n"
"fmax    v0.4s, v2.4s,  v0.4s \r\n"
"fmax    v1.4s, v2.4s,  v1.4s \r\n"
:
:
: "v0", "v1", "v2", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"mov    s2,  v1.s[2]           \r\n"
"str     q0, [%[addr_itm],   0] \r\n"
"str     d1, [%[addr_itm],   16] \r\n"
"str     s2, [%[addr_itm],   24] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"mov    s2,  v1.s[2]           \r\n"
"str     q0, [%[addr_c0],   0] \r\n"
"str     d1, [%[addr_c0],   16] \r\n"
"str     s2, [%[addr_c0],   24] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 6, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+6*(kk+0))
: "v3", "v4");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v3", "v4");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+6*kk+0*6),
[addr_b1] "r" (b+6*kk+1*6)
: "v3", "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v3", "v4", "v5", "v6");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+6*kk+0*6),
[addr_b1] "r" (b+6*kk+1*6),
[addr_b2] "r" (b+6*kk+2*6)
: "v3", "v4", "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v3", "v4", "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
:
:
: "v0", "v1");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
"ld1    {v9.4s, v10.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+6*kk+0*6),
[addr_b1] "r" (b+6*kk+1*6),
[addr_b2] "r" (b+6*kk+2*6),
[addr_b3] "r" (b+6*kk+3*6)
: "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
"ld1    {v9.4s, v10.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
}
else {
asm volatile(
"	fmla	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmla	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+6*(kk+0))
: "v3", "v4");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v3", "v4");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+6*(kk+1))
: "v5", "v6");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v5", "v6");
}
asm volatile(
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
:
:
: "v0", "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+6*(kk+2))
: "v7", "v8");
}
else {
asm volatile(
"ld1    {v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v7", "v8");
}
asm volatile(
"	fmla	v0.4s,  v9.4s, v2.s[3]  \r\n"
"	fmla	v1.4s,  v10.4s, v2.s[3]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v9.4s, v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+6*(kk+3))
: "v9", "v10");
}
else {
asm volatile(
"ld1    {v9.4s, v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v9", "v10");
}
asm volatile(
"	fmla	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmla	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v9.4s, v2.s[3]  \r\n"
"	fmla	v1.4s,  v10.4s, v2.s[3]  \r\n"
:
:
: "v0", "v1");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s2, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+6*(kk+0))
: "v3", "v4");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v3", "v4");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d2, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+6*kk+0*6),
[addr_b1] "r" (b+6*kk+1*6)
: "v3", "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v3", "v4", "v5", "v6");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q2, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+6*kk+0*6),
[addr_b1] "r" (b+6*kk+1*6),
[addr_b2] "r" (b+6*kk+2*6)
: "v3", "v4", "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v3", "v4", "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
:
:
: "v0", "v1");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1");
}
asm volatile(
"ldr    q2, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
"ld1    {v9.4s, v10.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+6*kk+0*6),
[addr_b1] "r" (b+6*kk+1*6),
[addr_b2] "r" (b+6*kk+2*6),
[addr_b3] "r" (b+6*kk+3*6)
: "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
"ld1    {v9.4s, v10.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
asm volatile(
"	fmla	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmla	v1.4s,  v4.4s, v2.s[0]  \r\n"
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
"	fmla	v0.4s,  v9.4s, v2.s[3]  \r\n"
"	fmla	v1.4s,  v10.4s, v2.s[3]  \r\n"
:
:
: "v0", "v1");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v2.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v2.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v2.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v4.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v2.4s, v3.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v2.4s,  v4.s[0]       \r\n"
"fmla    v1.4s,  v3.4s,  v4.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v2.4s, v3.4s}, [%[addr_itm0]] \r\n"
:
: [addr_itm0] "r" (itm+6*0)
: "v2", "v3");
}
else {
asm volatile(
"ld1    {v2.4s, v3.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v2", "v3");
}
asm volatile(
"fadd     v0.4s, v2.4s,  v0.4s \r\n"
"fadd     v1.4s, v3.4s,  v1.4s \r\n"
:
:
: "v0", "v1");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v2.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v2.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v2.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v2.4s, v3.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v2", "v3");
asm volatile(
"fadd     v0.4s, v2.4s,  v0.4s \r\n"
"fadd     v1.4s, v3.4s,  v1.4s \r\n"
:
:
: "v0", "v1");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v4.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v2.4s, v3.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v2.4s,  v4.s[0]       \r\n"
"fmla    v1.4s,  v3.4s,  v4.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v2.4s}, [%[addr_bias]] \r\n"
"dup    v3.4s, v2.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v3.4s \r\n"
"fadd     v1.4s, v1.4s,  v3.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v2.4s, w9             \r\n"
"fmax    v0.4s, v2.4s,  v0.4s \r\n"
"fmax    v1.4s, v2.4s,  v1.4s \r\n"
:
:
: "v0", "v1", "v2", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"str     q0, [%[addr_itm],   0] \r\n"
"str     d1, [%[addr_itm],   16] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"str     q0, [%[addr_c0],   0] \r\n"
"str     d1, [%[addr_c0],   16] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 5, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+5*(kk+0))
: "v3", "v4");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v3", "v4");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+5*kk+0*5),
[addr_b1] "r" (b+5*kk+1*5)
: "v3", "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v3", "v4", "v5", "v6");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+5*kk+0*5),
[addr_b1] "r" (b+5*kk+1*5),
[addr_b2] "r" (b+5*kk+2*5)
: "v3", "v4", "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v3", "v4", "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
:
:
: "v0", "v1");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
"ld1    {v9.4s, v10.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+5*kk+0*5),
[addr_b1] "r" (b+5*kk+1*5),
[addr_b2] "r" (b+5*kk+2*5),
[addr_b3] "r" (b+5*kk+3*5)
: "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
"ld1    {v9.4s, v10.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
}
else {
asm volatile(
"	fmla	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmla	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+5*(kk+0))
: "v3", "v4");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v3", "v4");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+5*(kk+1))
: "v5", "v6");
}
else {
asm volatile(
"ld1    {v5.4s, v6.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v5", "v6");
}
asm volatile(
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
:
:
: "v0", "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+5*(kk+2))
: "v7", "v8");
}
else {
asm volatile(
"ld1    {v7.4s, v8.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v7", "v8");
}
asm volatile(
"	fmla	v0.4s,  v9.4s, v2.s[3]  \r\n"
"	fmla	v1.4s,  v10.4s, v2.s[3]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"ld1    {v2.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v9.4s, v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+5*(kk+3))
: "v9", "v10");
}
else {
asm volatile(
"ld1    {v9.4s, v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v9", "v10");
}
asm volatile(
"	fmla	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmla	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
:
:
: "v0", "v1");
asm volatile(
"	fmla	v0.4s,  v9.4s, v2.s[3]  \r\n"
"	fmla	v1.4s,  v10.4s, v2.s[3]  \r\n"
:
:
: "v0", "v1");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s2, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+5*(kk+0))
: "v3", "v4");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v3", "v4");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
:
:
: "v0", "v1");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d2, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+5*kk+0*5),
[addr_b1] "r" (b+5*kk+1*5)
: "v3", "v4", "v5", "v6");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v3", "v4", "v5", "v6");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
:
:
: "v0", "v1");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q2, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+5*kk+0*5),
[addr_b1] "r" (b+5*kk+1*5),
[addr_b2] "r" (b+5*kk+2*5)
: "v3", "v4", "v5", "v6", "v7", "v8");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v3", "v4", "v5", "v6", "v7", "v8");
}
asm volatile(
"	fmul	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmul	v1.4s,  v4.4s, v2.s[0]  \r\n"
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
:
:
: "v0", "v1");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1");
}
asm volatile(
"ldr    q2, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v2");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
"ld1    {v9.4s, v10.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+5*kk+0*5),
[addr_b1] "r" (b+5*kk+1*5),
[addr_b2] "r" (b+5*kk+2*5),
[addr_b3] "r" (b+5*kk+3*5)
: "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
else {
asm volatile(
"ld1    {v3.4s, v4.4s}, [%[addr_b0]] \r\n"
"ld1    {v5.4s, v6.4s}, [%[addr_b1]] \r\n"
"ld1    {v7.4s, v8.4s}, [%[addr_b2]] \r\n"
"ld1    {v9.4s, v10.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10");
}
asm volatile(
"	fmla	v0.4s,  v3.4s, v2.s[0]  \r\n"
"	fmla	v1.4s,  v4.4s, v2.s[0]  \r\n"
"	fmla	v0.4s,  v5.4s, v2.s[1]  \r\n"
"	fmla	v1.4s,  v6.4s, v2.s[1]  \r\n"
"	fmla	v0.4s,  v7.4s, v2.s[2]  \r\n"
"	fmla	v1.4s,  v8.4s, v2.s[2]  \r\n"
"	fmla	v0.4s,  v9.4s, v2.s[3]  \r\n"
"	fmla	v1.4s,  v10.4s, v2.s[3]  \r\n"
:
:
: "v0", "v1");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v2.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v2.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v2.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v4.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v2.4s, v3.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v2.4s,  v4.s[0]       \r\n"
"fmla    v1.4s,  v3.4s,  v4.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v2.4s, v3.4s}, [%[addr_itm0]] \r\n"
:
: [addr_itm0] "r" (itm+5*0)
: "v2", "v3");
}
else {
asm volatile(
"ld1    {v2.4s, v3.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v2", "v3");
}
asm volatile(
"fadd     v0.4s, v2.4s,  v0.4s \r\n"
"fadd     v1.4s, v3.4s,  v1.4s \r\n"
:
:
: "v0", "v1");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v2.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v2.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v2.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v2.4s, v3.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v2", "v3");
asm volatile(
"fadd     v0.4s, v2.4s,  v0.4s \r\n"
"fadd     v1.4s, v3.4s,  v1.4s \r\n"
:
:
: "v0", "v1");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v4.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v2.4s, v3.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v2.4s,  v4.s[0]       \r\n"
"fmla    v1.4s,  v3.4s,  v4.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v2.4s}, [%[addr_bias]] \r\n"
"dup    v3.4s, v2.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v3.4s \r\n"
"fadd     v1.4s, v1.4s,  v3.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v2.4s, w9             \r\n"
"fmax    v0.4s, v2.4s,  v0.4s \r\n"
"fmax    v1.4s, v2.4s,  v1.4s \r\n"
:
:
: "v0", "v1", "v2", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"str     q0, [%[addr_itm],   0] \r\n"
"str     s1, [%[addr_itm],   16] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"str     q0, [%[addr_c0],   0] \r\n"
"str     s1, [%[addr_c0],   16] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 4, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+4*(kk+0))
: "v2");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v2");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+4*kk+0*4),
[addr_b1] "r" (b+4*kk+1*4)
: "v2", "v3");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v2", "v3");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+4*kk+0*4),
[addr_b1] "r" (b+4*kk+1*4),
[addr_b2] "r" (b+4*kk+2*4)
: "v2", "v3", "v4");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v2", "v3", "v4");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
:
:
: "v0");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
"ld1    {v5.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+4*kk+0*4),
[addr_b1] "r" (b+4*kk+1*4),
[addr_b2] "r" (b+4*kk+2*4),
[addr_b3] "r" (b+4*kk+3*4)
: "v2", "v3", "v4", "v5");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
"ld1    {v5.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v2", "v3", "v4", "v5");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
}
else {
asm volatile(
"	fmla	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+4*(kk+0))
: "v2");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v2");
}
asm volatile(
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+4*(kk+1))
: "v3");
}
else {
asm volatile(
"ld1    {v3.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v3");
}
asm volatile(
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
:
:
: "v0");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+4*(kk+2))
: "v4");
}
else {
asm volatile(
"ld1    {v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v4");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v1.s[3]  \r\n"
:
:
: "v0");
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+4*(kk+3))
: "v5");
}
else {
asm volatile(
"ld1    {v5.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v5");
}
asm volatile(
"	fmla	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
}
asm volatile(
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v5.4s, v1.s[3]  \r\n"
:
:
: "v0");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s1, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+4*(kk+0))
: "v2");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v2");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d1, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+4*kk+0*4),
[addr_b1] "r" (b+4*kk+1*4)
: "v2", "v3");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v2", "v3");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q1, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+4*kk+0*4),
[addr_b1] "r" (b+4*kk+1*4),
[addr_b2] "r" (b+4*kk+2*4)
: "v2", "v3", "v4");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v2", "v3", "v4");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
:
:
: "v0");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0");
}
asm volatile(
"ldr    q1, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
"ld1    {v5.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+4*kk+0*4),
[addr_b1] "r" (b+4*kk+1*4),
[addr_b2] "r" (b+4*kk+2*4),
[addr_b3] "r" (b+4*kk+3*4)
: "v2", "v3", "v4", "v5");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
"ld1    {v5.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v2", "v3", "v4", "v5");
}
asm volatile(
"	fmla	v0.4s,  v2.4s, v1.s[0]  \r\n"
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
"	fmla	v0.4s,  v5.4s, v1.s[3]  \r\n"
:
:
: "v0");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v1.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v1.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v2.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v1.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v1.4s,  v2.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v1.4s}, [%[addr_itm0]] \r\n"
:
: [addr_itm0] "r" (itm+4*0)
: "v1");
}
else {
asm volatile(
"ld1    {v1.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v1");
}
asm volatile(
"fadd     v0.4s, v1.4s,  v0.4s \r\n"
:
:
: "v0");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v1.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v1.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v1.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v1");
asm volatile(
"fadd     v0.4s, v1.4s,  v0.4s \r\n"
:
:
: "v0");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v2.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v1.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v1.4s,  v2.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v1.4s}, [%[addr_bias]] \r\n"
"dup    v2.4s, v1.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v2.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v1.4s, w9             \r\n"
"fmax    v0.4s, v1.4s,  v0.4s \r\n"
:
:
: "v0", "v1", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"str     q0, [%[addr_itm],   0] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"str     q0, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 3, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+3*(kk+0))
: "v2");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v2");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+3*kk+0*3),
[addr_b1] "r" (b+3*kk+1*3)
: "v2", "v3");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v2", "v3");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+3*kk+0*3),
[addr_b1] "r" (b+3*kk+1*3),
[addr_b2] "r" (b+3*kk+2*3)
: "v2", "v3", "v4");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v2", "v3", "v4");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
:
:
: "v0");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
"ld1    {v5.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+3*kk+0*3),
[addr_b1] "r" (b+3*kk+1*3),
[addr_b2] "r" (b+3*kk+2*3),
[addr_b3] "r" (b+3*kk+3*3)
: "v2", "v3", "v4", "v5");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
"ld1    {v5.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v2", "v3", "v4", "v5");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
}
else {
asm volatile(
"	fmla	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+3*(kk+0))
: "v2");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v2");
}
asm volatile(
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+3*(kk+1))
: "v3");
}
else {
asm volatile(
"ld1    {v3.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v3");
}
asm volatile(
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
:
:
: "v0");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+3*(kk+2))
: "v4");
}
else {
asm volatile(
"ld1    {v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v4");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v1.s[3]  \r\n"
:
:
: "v0");
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+3*(kk+3))
: "v5");
}
else {
asm volatile(
"ld1    {v5.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v5");
}
asm volatile(
"	fmla	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
}
asm volatile(
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v5.4s, v1.s[3]  \r\n"
:
:
: "v0");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s1, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+3*(kk+0))
: "v2");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v2");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d1, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+3*kk+0*3),
[addr_b1] "r" (b+3*kk+1*3)
: "v2", "v3");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v2", "v3");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q1, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+3*kk+0*3),
[addr_b1] "r" (b+3*kk+1*3),
[addr_b2] "r" (b+3*kk+2*3)
: "v2", "v3", "v4");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v2", "v3", "v4");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
:
:
: "v0");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0");
}
asm volatile(
"ldr    q1, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
"ld1    {v5.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+3*kk+0*3),
[addr_b1] "r" (b+3*kk+1*3),
[addr_b2] "r" (b+3*kk+2*3),
[addr_b3] "r" (b+3*kk+3*3)
: "v2", "v3", "v4", "v5");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
"ld1    {v5.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v2", "v3", "v4", "v5");
}
asm volatile(
"	fmla	v0.4s,  v2.4s, v1.s[0]  \r\n"
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
"	fmla	v0.4s,  v5.4s, v1.s[3]  \r\n"
:
:
: "v0");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v1.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v1.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v2.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v1.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v1.4s,  v2.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v1.4s}, [%[addr_itm0]] \r\n"
:
: [addr_itm0] "r" (itm+3*0)
: "v1");
}
else {
asm volatile(
"ld1    {v1.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v1");
}
asm volatile(
"fadd     v0.4s, v1.4s,  v0.4s \r\n"
:
:
: "v0");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v1.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v1.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v1.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v1");
asm volatile(
"fadd     v0.4s, v1.4s,  v0.4s \r\n"
:
:
: "v0");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v2.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v1.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v1.4s,  v2.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v1.4s}, [%[addr_bias]] \r\n"
"dup    v2.4s, v1.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v2.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v1.4s, w9             \r\n"
"fmax    v0.4s, v1.4s,  v0.4s \r\n"
:
:
: "v0", "v1", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"mov    s1,  v0.s[2]           \r\n"
"str     d0, [%[addr_itm],   0] \r\n"
"str     s1, [%[addr_itm],   8] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"mov    s1,  v0.s[2]           \r\n"
"str     d0, [%[addr_c0],   0] \r\n"
"str     s1, [%[addr_c0],   8] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 2, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+2*(kk+0))
: "v2");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v2");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+2*kk+0*2),
[addr_b1] "r" (b+2*kk+1*2)
: "v2", "v3");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v2", "v3");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+2*kk+0*2),
[addr_b1] "r" (b+2*kk+1*2),
[addr_b2] "r" (b+2*kk+2*2)
: "v2", "v3", "v4");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v2", "v3", "v4");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
:
:
: "v0");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
"ld1    {v5.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+2*kk+0*2),
[addr_b1] "r" (b+2*kk+1*2),
[addr_b2] "r" (b+2*kk+2*2),
[addr_b3] "r" (b+2*kk+3*2)
: "v2", "v3", "v4", "v5");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
"ld1    {v5.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v2", "v3", "v4", "v5");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
}
else {
asm volatile(
"	fmla	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+2*(kk+0))
: "v2");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v2");
}
asm volatile(
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+2*(kk+1))
: "v3");
}
else {
asm volatile(
"ld1    {v3.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v3");
}
asm volatile(
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
:
:
: "v0");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+2*(kk+2))
: "v4");
}
else {
asm volatile(
"ld1    {v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v4");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v1.s[3]  \r\n"
:
:
: "v0");
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+2*(kk+3))
: "v5");
}
else {
asm volatile(
"ld1    {v5.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v5");
}
asm volatile(
"	fmla	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
}
asm volatile(
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v5.4s, v1.s[3]  \r\n"
:
:
: "v0");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s1, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+2*(kk+0))
: "v2");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v2");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d1, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+2*kk+0*2),
[addr_b1] "r" (b+2*kk+1*2)
: "v2", "v3");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v2", "v3");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q1, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+2*kk+0*2),
[addr_b1] "r" (b+2*kk+1*2),
[addr_b2] "r" (b+2*kk+2*2)
: "v2", "v3", "v4");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v2", "v3", "v4");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
:
:
: "v0");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0");
}
asm volatile(
"ldr    q1, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
"ld1    {v5.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+2*kk+0*2),
[addr_b1] "r" (b+2*kk+1*2),
[addr_b2] "r" (b+2*kk+2*2),
[addr_b3] "r" (b+2*kk+3*2)
: "v2", "v3", "v4", "v5");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
"ld1    {v5.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v2", "v3", "v4", "v5");
}
asm volatile(
"	fmla	v0.4s,  v2.4s, v1.s[0]  \r\n"
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
"	fmla	v0.4s,  v5.4s, v1.s[3]  \r\n"
:
:
: "v0");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v1.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v1.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v2.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v1.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v1.4s,  v2.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v1.4s}, [%[addr_itm0]] \r\n"
:
: [addr_itm0] "r" (itm+2*0)
: "v1");
}
else {
asm volatile(
"ld1    {v1.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v1");
}
asm volatile(
"fadd     v0.4s, v1.4s,  v0.4s \r\n"
:
:
: "v0");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v1.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v1.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v1.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v1");
asm volatile(
"fadd     v0.4s, v1.4s,  v0.4s \r\n"
:
:
: "v0");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v2.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v1.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v1.4s,  v2.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v1.4s}, [%[addr_bias]] \r\n"
"dup    v2.4s, v1.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v2.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v1.4s, w9             \r\n"
"fmax    v0.4s, v1.4s,  v0.4s \r\n"
:
:
: "v0", "v1", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"str     d0, [%[addr_itm],   0] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"str     d0, [%[addr_c0],   0] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 1, 1, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+1*(kk+0))
: "v2");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v2");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+1*kk+0*1),
[addr_b1] "r" (b+1*kk+1*1)
: "v2", "v3");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v2", "v3");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+1*kk+0*1),
[addr_b1] "r" (b+1*kk+1*1),
[addr_b2] "r" (b+1*kk+2*1)
: "v2", "v3", "v4");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v2", "v3", "v4");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
:
:
: "v0");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*(kk+0))
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
"ld1    {v5.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+1*kk+0*1),
[addr_b1] "r" (b+1*kk+1*1),
[addr_b2] "r" (b+1*kk+2*1),
[addr_b3] "r" (b+1*kk+3*1)
: "v2", "v3", "v4", "v5");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
"ld1    {v5.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v2", "v3", "v4", "v5");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
}
else {
asm volatile(
"	fmla	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
}
kk+=4;
for(; kk<k; kk+=4) {
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+1*(kk+0))
: "v2");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v2");
}
asm volatile(
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
if constexpr(ReB) {
asm volatile(
"ld1    {v3.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+1*(kk+1))
: "v3");
}
else {
asm volatile(
"ld1    {v3.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v3");
}
asm volatile(
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
:
:
: "v0");
if constexpr(ReB) {
asm volatile(
"ld1    {v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+1*(kk+2))
: "v4");
}
else {
asm volatile(
"ld1    {v4.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v4");
}
asm volatile(
"	fmla	v0.4s,  v5.4s, v1.s[3]  \r\n"
:
:
: "v0");
asm volatile(
"ld1    {v1.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+1*kk+0*4)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v5.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+1*(kk+3))
: "v5");
}
else {
asm volatile(
"ld1    {v5.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v5");
}
asm volatile(
"	fmla	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
}
asm volatile(
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
:
:
: "v0");
asm volatile(
"	fmla	v0.4s,  v5.4s, v1.s[3]  \r\n"
:
:
: "v0");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s1, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+1*(kk+0))
: "v2");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v2");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
:
:
: "v0");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d1, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+1*kk+0*1),
[addr_b1] "r" (b+1*kk+1*1)
: "v2", "v3");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v2", "v3");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
:
:
: "v0");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q1, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+1*kk+0*1),
[addr_b1] "r" (b+1*kk+1*1),
[addr_b2] "r" (b+1*kk+2*1)
: "v2", "v3", "v4");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v2", "v3", "v4");
}
asm volatile(
"	fmul	v0.4s,  v2.4s, v1.s[0]  \r\n"
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
:
:
: "v0");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0");
}
asm volatile(
"ldr    q1, [%[addr_a0]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk)
: "v1");
if constexpr(ReB) {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
"ld1    {v5.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+1*kk+0*1),
[addr_b1] "r" (b+1*kk+1*1),
[addr_b2] "r" (b+1*kk+2*1),
[addr_b3] "r" (b+1*kk+3*1)
: "v2", "v3", "v4", "v5");
}
else {
asm volatile(
"ld1    {v2.4s}, [%[addr_b0]] \r\n"
"ld1    {v3.4s}, [%[addr_b1]] \r\n"
"ld1    {v4.4s}, [%[addr_b2]] \r\n"
"ld1    {v5.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v2", "v3", "v4", "v5");
}
asm volatile(
"	fmla	v0.4s,  v2.4s, v1.s[0]  \r\n"
"	fmla	v0.4s,  v3.4s, v1.s[1]  \r\n"
"	fmla	v0.4s,  v4.4s, v1.s[2]  \r\n"
"	fmla	v0.4s,  v5.4s, v1.s[3]  \r\n"
:
:
: "v0");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v1.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v1.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v2.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v1.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v1.4s,  v2.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v1.4s}, [%[addr_itm0]] \r\n"
:
: [addr_itm0] "r" (itm+1*0)
: "v1");
}
else {
asm volatile(
"ld1    {v1.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v1");
}
asm volatile(
"fadd     v0.4s, v1.4s,  v0.4s \r\n"
:
:
: "v0");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v1.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v1.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v1.4s}, [%[addr_c0]] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "v1");
asm volatile(
"fadd     v0.4s, v1.4s,  v0.4s \r\n"
:
:
: "v0");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v2.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v1.4s}, [%[addr_c0]] \r\n"
"fmla    v0.4s,  v1.4s,  v2.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0)
: "v0", "v1", "v2");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v1.4s}, [%[addr_bias]] \r\n"
"dup    v2.4s, v1.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v2.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v1.4s, w9             \r\n"
"fmax    v0.4s, v1.4s,  v0.4s \r\n"
:
:
: "v0", "v1", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"str     s0, [%[addr_itm],   0] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"str     s0, [%[addr_c0],   0] \r\n"
:
: [addr_c0] "r" (c+ldc*0)
: "memory");}
}
};


#endif  // __aarch64

#endif  // GEMM_ROWMAJOR_NOTRANS_KERNELS_1X20_HPP_
