#ifndef GEMM_ROWMAJOR_NOTRANS_KERNELS_8X12_HPP_
#define GEMM_ROWMAJOR_NOTRANS_KERNELS_8X12_HPP_

#include "kernel.hpp"

#ifdef C_MODEL
#include <cmath>
#endif

#ifdef __aarch64__

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool Load,
    bool Itm2Res, bool Blend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernelv2<Lhs, Rhs, Res, Itm, float, 8, 12, CortexA53, true, true, false, Load, Itm2Res, Blend, false, false, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {

  constexpr bool RScale = false;
  constexpr bool RScaleBlend = false;
#ifndef C_MODEL
  // k MUST be not 0.
  int kodd = k & 1;
  int kloop = ((k + 1) >> 1) - 1;

  if constexpr (ReLU) {
    asm volatile (
      "movi   v5.4s, #0                               \r\n"
      :
      :
      : "v5"
    );
  }

  constexpr bool AddRes = Load && !(FstIter && RScaleBlend);

  if constexpr (RBias) {
    asm volatile (
      "ldr    q6, [%[bias_ptr]]                       \r\n"
      "ldr    q7, [%[bias_ptr], #16]                  \r\n"
      "ldr    q0, [%[a_ptr]]                          \r\n"
      "ldr    q2, [%[b_ptr]]                          \r\n"
      "ldr    q1, [%[a_ptr], #16]                     \r\n"
      "dup    v8.4s, v6.s[0]                          \r\n"
      "ldr    d3, [%[b_ptr], #16]                     \r\n"
      "dup    v9.4s, v6.s[1]                          \r\n"
      "ldr    x28, [%[b_ptr], #24]                    \r\n"
      "dup    v10.4s, v6.s[2]                         \r\n"
      "dup    v11.4s, v6.s[3]                         \r\n"
      "dup    v12.4s, v7.s[0]                         \r\n"
      "dup    v13.4s, v7.s[1]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #64]              \r\n"
      "dup    v14.4s, v7.s[2]                         \r\n"
      "dup    v15.4s, v7.s[3]                         \r\n"
      "prfm   pldl1keep, [%[a_ptr], #64]              \r\n"
      "dup    v16.4s, v6.s[0]                         \r\n"
      "dup    v17.4s, v6.s[1]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #128]             \r\n"
      "dup    v18.4s, v6.s[2]                         \r\n"
      "dup    v19.4s, v6.s[3]                         \r\n"
      "prfm   pldl1keep, [%[a_ptr], #128]             \r\n"
      "dup    v20.4s, v7.s[0]                         \r\n"
      "dup    v21.4s, v7.s[1]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #192]             \r\n"
      "dup    v22.4s, v7.s[2]                         \r\n"
      "dup    v23.4s, v7.s[3]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #256]             \r\n"
      "dup    v24.4s, v6.s[0]                         \r\n"
      "dup    v25.4s, v6.s[1]                         \r\n"
      "prfm   pldl1keep, [%[a_ptr], #192]             \r\n"
      "dup    v26.4s, v6.s[2]                         \r\n"
      "dup    v27.4s, v6.s[3]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #320]             \r\n"
      "dup    v28.4s, v7.s[0]                         \r\n"
      "dup    v29.4s, v7.s[1]                         \r\n"
      "prfm   pldl1keep, [%[a_ptr], #256]             \r\n"
      "dup    v30.4s, v7.s[2]                         \r\n"
      "dup    v31.4s, v7.s[3]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #384]             \r\n"
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b)
      : [bias_ptr] "r" (rbias)
      : "v0", "v1", "v2", "v3", "v6", "v7",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31"
    );
  } else {
    asm volatile (
      "movi   v8.4s, #0x0                               \r\n"
      "ldr    d0, [%[a_ptr]]                            \r\n"
      "movi   v9.4s, #0x0                               \r\n"
      "ldr    x27, [%[a_ptr], #8]                       \r\n"
      "movi   v10.4s, #0x0                              \r\n"
      "ldr    d2, [%[b_ptr]]                            \r\n"
      "movi   v11.4s, #0x0                              \r\n"
      "ldr    x28, [%[b_ptr], #8]                       \r\n"
      "movi   v12.4s, #0x0                              \r\n"
      "ldr    d1, [%[a_ptr], #16]                       \r\n"
      "movi   v13.4s, #0x0                              \r\n"
      "movi   v14.4s, #0x0                              \r\n"
      "movi   v15.4s, #0x0                              \r\n"
      "mov    v0.d[1], x27                              \r\n"
      "movi   v16.4s, #0x0                              \r\n"
      "ldr    x27, [%[a_ptr], #24]                      \r\n"
      "movi   v17.4s, #0x0                              \r\n"
      "ldr    d3, [%[b_ptr], #16]                       \r\n"
      "movi   v18.4s, #0x0                              \r\n"
      "mov    v2.d[1], x28                              \r\n"
      "movi   v19.4s, #0x0                              \r\n"
      "ldr    x28, [%[b_ptr], #24]                      \r\n"
      "movi   v20.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #64]                \r\n"
      "movi   v21.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[a_ptr], #64]                \r\n"
      "movi   v22.4s, #0x0                              \r\n"
      "mov    v1.d[1], x27                              \r\n"
      "movi   v23.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #128]               \r\n"
      "movi   v24.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[a_ptr], #128]               \r\n"
      "movi   v25.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #192]               \r\n"
      "movi   v26.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #256]               \r\n"
      "movi   v27.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[a_ptr], #192]               \r\n"
      "movi   v28.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #320]               \r\n"
      "movi   v29.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[a_ptr], #256]               \r\n"
      "movi   v30.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #384]               \r\n"
      "movi   v31.4s, #0x0                              \r\n"
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b)
      :
      : "x27", "x28", "v0", "v1", "v2", "v3",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31"
    );
  }

  if (kloop) {
    asm volatile (
      "1:                                             \r\n"
      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla   v8.4s, v2.4s, v0.s[0]                   \r\n"
      "ldr    x27, [%[b_ptr], #40]                    \r\n"
      "fmla   v9.4s, v2.4s, v0.s[1]                   \r\n"
      "fmla   v10.4s, v2.4s, v0.s[2]                  \r\n"

      "ldr	  d6, [%[a_ptr], #32]                     \r\n"
      "fmla   v11.4s, v2.4s, v0.s[3]                  \r\n"
      "ldr    x28, [%[a_ptr], #40]                    \r\n"
      "fmla   v12.4s, v2.4s, v1.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"
      
      "prfm   pldl1keep, [%[a_ptr], #320]             \r\n"
      "mov    v4.d[1], x27                            \r\n"
      "fmla   v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla   v15.4s, v2.4s, v1.s[3]                  \r\n"
      "fmla   v16.4s, v3.4s, v0.s[0]                  \r\n"

      "ldr    d2, [%[b_ptr], #48]                     \r\n"
      "mov    v6.d[1], x28                            \r\n"
      "fmla   v17.4s, v3.4s, v0.s[1]                  \r\n"
      "ldr    x27, [%[b_ptr], #56]                    \r\n"
      "fmla   v18.4s, v3.4s, v0.s[2]                  \r\n"
      "fmla   v19.4s, v3.4s, v0.s[3]                  \r\n"

      "ldr	  d7, [%[a_ptr], #48]                     \r\n"
      "fmla   v20.4s, v3.4s, v1.s[0]                  \r\n"
      "ldr    x28, [%[a_ptr], #56]                    \r\n"
      "fmla   v21.4s, v3.4s, v1.s[1]                  \r\n"
      "fmla   v22.4s, v3.4s, v1.s[2]                  \r\n"

      "prfm   pldl1keep, [%[b_ptr], #448]             \r\n"
      "mov    v2.d[1], x27                            \r\n"
      "fmla   v23.4s, v3.4s, v1.s[3]                  \r\n"
      "fmla   v24.4s, v4.4s, v0.s[0]                  \r\n"
      "fmla   v25.4s, v4.4s, v0.s[1]                  \r\n"

      "ldr    d3, [%[b_ptr], #64]                     \r\n"
      "fmla   v26.4s, v4.4s, v0.s[2]                  \r\n"
      "ldr    x27, [%[b_ptr], #72]                    \r\n"
      "fmla   v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla   v28.4s, v4.4s, v1.s[0]                  \r\n"

      "mov    v7.d[1], x28                            \r\n"
      "fmla   v29.4s, v4.4s, v1.s[1]                  \r\n"
      "fmla   v30.4s, v4.4s, v1.s[2]                  \r\n"
      "fmla   v31.4s, v4.4s, v1.s[3]                  \r\n"
      
      "ldr    d4, [%[b_ptr], #80]                     \r\n"
      "mov    v3.d[1], x27                            \r\n"
      "fmla   v8.4s, v2.4s, v6.s[0]                   \r\n"
      "ldr    x28, [%[b_ptr], #88]                    \r\n"
      "fmla   v9.4s, v2.4s, v6.s[1]                   \r\n"
      "fmla   v10.4s, v2.4s, v6.s[2]                  \r\n"

      "ldr    d0, [%[a_ptr], #64]                     \r\n"
      "fmla   v11.4s, v2.4s, v6.s[3]                  \r\n"
      "ldr    x27, [%[a_ptr], #72]                    \r\n"
      "fmla   v12.4s, v2.4s, v7.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v7.s[1]                  \r\n"

      "prfm   pldl1keep, [%[b_ptr], #512]             \r\n"
      "mov    v4.d[1], x28                            \r\n"
      "fmla   v14.4s, v2.4s, v7.s[2]                  \r\n"
      "fmla   v15.4s, v2.4s, v7.s[3]                  \r\n"
      "fmla   v16.4s, v3.4s, v6.s[0]                  \r\n"

      "ldr    d2, [%[b_ptr], #96]                     \r\n"
      "mov    v0.d[1], x27                            \r\n"
      "fmla   v17.4s, v3.4s, v6.s[1]                  \r\n"
      "ldr    x28, [%[b_ptr], #104]                   \r\n"
      "fmla   v18.4s, v3.4s, v6.s[2]                  \r\n"
      "fmla   v19.4s, v3.4s, v6.s[3]                  \r\n"

      "ldr	  d1, [%[a_ptr], #80]                     \r\n"
      "fmla   v20.4s, v3.4s, v7.s[0]                  \r\n"
      "ldr    x27, [%[a_ptr], #88]                    \r\n"
      "fmla   v21.4s, v3.4s, v7.s[1]                  \r\n"
      "fmla   v22.4s, v3.4s, v7.s[2]                  \r\n"

      "mov    v2.d[1], x28                            \r\n"
      "add    %[a_ptr], %[a_ptr], #64                 \r\n"
      "fmla   v23.4s, v3.4s, v7.s[3]                  \r\n"
      "fmla   v24.4s, v4.4s, v6.s[0]                  \r\n"
      "fmla   v25.4s, v4.4s, v6.s[1]                  \r\n"

      "ldr    d3, [%[b_ptr], #112]                    \r\n"
      "subs   %x[kloop], %x[kloop], #1                \r\n"
      "fmla   v26.4s, v4.4s, v6.s[2]                  \r\n"
      "ldr    x28, [%[b_ptr], #120]                   \r\n"
      "fmla   v27.4s, v4.4s, v6.s[3]                  \r\n"
      "fmla   v28.4s, v4.4s, v7.s[0]                  \r\n"
      
      "mov    v1.d[1], x27                            \r\n"
      "add    %[b_ptr], %[b_ptr], #96                 \r\n"
      "fmla   v29.4s, v4.4s, v7.s[1]                  \r\n"
      "fmla   v30.4s, v4.4s, v7.s[2]                  \r\n"
      "fmla   v31.4s, v4.4s, v7.s[3]                  \r\n"

      "bne    1b                                      \r\n"
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b),
        [kloop] "+r" (kloop)
      :
      : "x27", "x28", "v0", "v1", "v2", "v3", "v4", "v6", "v7",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31",
        "cc"
    );
  }

  // if constexpr (RBias && AddRes) {
  if constexpr (AddRes) {
    asm volatile (
      "cbnz   %x[kodd], 2f                            \r\n"

      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla 	v8.4s, v2.4s, v0.s[0]                   \r\n"
      "ldr    x27, [%[b_ptr], #40]                    \r\n"
      "fmla   v9.4s, v2.4s, v0.s[1]                   \r\n"
      "fmla	  v10.4s, v2.4s, v0.s[2]                  \r\n"

      "ldr	  d6, [%[a_ptr], #32]                     \r\n"
      "fmla	  v11.4s, v2.4s, v0.s[3]                  \r\n"
      "ldr    x28, [%[a_ptr], #40]                    \r\n"
      "fmla 	v12.4s, v2.4s, v1.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr0]]                  \r\n"
      "mov    v4.d[1], x27                            \r\n"
      "fmla	  v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla	  v15.4s, v2.4s, v1.s[3]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr1]]                  \r\n"
      "fmla	  v16.4s, v3.4s, v0.s[0]                  \r\n"

      "ldr	  d2, [%[b_ptr], #48]                     \r\n"
      "mov    v6.d[1], x28                            \r\n"
      "fmla	  v17.4s, v3.4s, v0.s[1]                  \r\n"
      "ldr    x27, [%[b_ptr], #56]                    \r\n"
      "fmla	  v18.4s, v3.4s, v0.s[2]                  \r\n"
      "fmla	  v19.4s, v3.4s, v0.s[3]                  \r\n"

      "ldr	  d7, [%[a_ptr], #48]                     \r\n"
      "fmla	  v20.4s, v3.4s, v1.s[0]                  \r\n"
      "ldr    x28, [%[a_ptr], #56]                    \r\n"
      "fmla	  v21.4s, v3.4s, v1.s[1]                  \r\n"
      "fmla	  v22.4s, v3.4s, v1.s[2]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr2]]                  \r\n"
      "mov    v2.d[1], x27                            \r\n"
      "fmla	  v23.4s, v3.4s, v1.s[3]                  \r\n"
      "fmla	  v24.4s, v4.4s, v0.s[0]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr3]]                  \r\n"
      "fmla	  v25.4s, v4.4s, v0.s[1]                  \r\n"
      
      "ldr	  d3, [%[b_ptr], #64]                     \r\n"
      "fmla	  v26.4s, v4.4s, v0.s[2]                  \r\n"
      "ldr    x27, [%[b_ptr], #72]                    \r\n"
      "fmla	  v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v1.s[0]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr4]]                  \r\n"
      "mov    v7.d[1], x28                            \r\n"
      "fmla	  v29.4s, v4.4s, v1.s[1]                  \r\n"
      "fmla	  v30.4s, v4.4s, v1.s[2]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr5]]                  \r\n"
      "fmla	  v31.4s, v4.4s, v1.s[3]                  \r\n"

      "ldr	  d4, [%[b_ptr], #80]                     \r\n"
      "mov    v3.d[1], x27                            \r\n"
      "fmla 	v8.4s , v2.4s, v6.s[0]                  \r\n"
      "ldr    x28, [%[b_ptr], #88]                    \r\n"
      "fmla   v9.4s , v2.4s, v6.s[1]                  \r\n"
      "fmla	  v10.4s, v2.4s, v6.s[2]                  \r\n"

      "ldr    d5, [%[c_ptr0], #0]                     \r\n"
      "fmla	  v11.4s, v2.4s, v6.s[3]                  \r\n"
      "ldr    x27, [%[c_ptr0], #8]                    \r\n"
      "fmla 	v12.4s, v2.4s, v7.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v7.s[1]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr6]]                  \r\n"
      "mov    v4.d[1], x28                            \r\n"
      "fmla	  v16.4s, v3.4s, v6.s[0]                  \r\n"
      "fmla	  v17.4s, v3.4s, v6.s[1]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr7]]                  \r\n"
      "fmla	  v18.4s, v3.4s, v6.s[2]                  \r\n"

      "ldr    d0, [%[c_ptr0], #16]                    \r\n"
      "mov    v5.d[1], x27                            \r\n"
      "fmla	  v19.4s, v3.4s, v6.s[3]                  \r\n"
      "ldr    x28, [%[c_ptr0], #24]                   \r\n"
      "fmla	  v20.4s, v3.4s, v7.s[0]                  \r\n"
      "fmla	  v21.4s, v3.4s, v7.s[1]                  \r\n"

      "ldr    d1, [%[c_ptr0], #32]                    \r\n"
      "fmla	  v24.4s, v4.4s, v6.s[0]                  \r\n"
      "ldr    x27, [%[c_ptr0], #40]                   \r\n"
      "fmla	  v25.4s, v4.4s, v6.s[1]                  \r\n"
      "fmla	  v26.4s, v4.4s, v6.s[2]                  \r\n"

      "fadd   v8.4s, v8.4s, v5.4s                     \r\n"
      "mov    v0.d[1], x28                            \r\n"
      "fmla	  v27.4s, v4.4s, v6.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v7.s[0]                  \r\n"
      "fmla	  v29.4s, v4.4s, v7.s[1]                  \r\n"

      "mov    v1.d[1], x27                            \r\n"
      "fmla	  v14.4s, v2.4s, v7.s[2]                  \r\n"
      "fmla	  v22.4s, v3.4s, v7.s[2]                  \r\n"
      "fmla	  v30.4s, v4.4s, v7.s[2]                  \r\n"

      "fadd   v16.4s, v16.4s, v0.4s                   \r\n"
      "fmla	  v15.4s, v2.4s, v7.s[3]                  \r\n"
      "fmla	  v23.4s, v3.4s, v7.s[3]                  \r\n"
      "fmla	  v31.4s, v4.4s, v7.s[3]                  \r\n"

      "fadd   v24.4s, v24.4s, v1.4s                   \r\n"

      "b      3f                                      \r\n"

      "2:                                             \r\n"
      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla 	v8.4s , v2.4s, v0.s[0]                  \r\n"
      "ldr    x27, [%[b_ptr], #40]                    \r\n"
      "fmla   v9.4s , v2.4s, v0.s[1]                  \r\n"
      "fmla	  v10.4s, v2.4s, v0.s[2]                  \r\n"

      "ldr    d5, [%[c_ptr0], #0]                     \r\n"
      "fmla	  v11.4s, v2.4s, v0.s[3]                  \r\n"
      "ldr    x28, [%[c_ptr0], #8]                    \r\n"
      "fmla 	v12.4s, v2.4s, v1.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr1]]                  \r\n"
      "mov    v4.d[1], x27                            \r\n"
      "fmla	  v16.4s, v3.4s, v0.s[0]                  \r\n"
      "fmla	  v17.4s, v3.4s, v0.s[1]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr2]]                  \r\n"
      "fmla	  v18.4s, v3.4s, v0.s[2]                  \r\n"

      "ldr    d6, [%[c_ptr0], #16]                    \r\n"
      "mov    v5.d[1], x28                            \r\n"
      "fmla	  v19.4s, v3.4s, v0.s[3]                  \r\n"
      "ldr    x27, [%[c_ptr0], #24]                   \r\n"
      "fmla	  v20.4s, v3.4s, v1.s[0]                  \r\n"
      "fmla	  v21.4s, v3.4s, v1.s[1]                  \r\n"

      "ldr    d7, [%[c_ptr0], #32]                    \r\n"
      "fmla	  v24.4s, v4.4s, v0.s[0]                  \r\n"
      "ldr    x28, [%[c_ptr0], #40]                   \r\n"
      "fmla	  v25.4s, v4.4s, v0.s[1]                  \r\n"
      "fmla	  v26.4s, v4.4s, v0.s[2]                  \r\n"
      
      "fadd   v8.4s, v8.4s, v5.4s                     \r\n"
      "mov    v6.d[1], x27                            \r\n"
      "fmla	  v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v1.s[0]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr3]]                  \r\n"
      "fmla	  v29.4s, v4.4s, v1.s[1]                  \r\n"
      
      "prfm   pldl1keep, [%[c_ptr4]]                  \r\n"
      "mov    v7.d[1], x28                            \r\n"
      "fmla	  v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla	  v22.4s, v3.4s, v1.s[2]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr5]]                  \r\n"
      "fmla	  v30.4s, v4.4s, v1.s[2]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr6]]                  \r\n"
      "fadd   v16.4s, v16.4s, v6.4s                   \r\n"
      "fmla	  v15.4s, v2.4s, v1.s[3]                  \r\n"
      "fmla	  v23.4s, v3.4s, v1.s[3]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr7]]                  \r\n"
      "fmla	  v31.4s, v4.4s, v1.s[3]                  \r\n"

      "fadd   v24.4s, v24.4s, v7.4s                   \r\n"

      "3:                                             \r\n"
      "ldr    q5, [%[c_ptr1], #0]                     \r\n"
      "ldr    q0, [%[c_ptr1], #16]                    \r\n"
      "ldr    q1, [%[c_ptr1], #32]                    \r\n"

      "ldr    q2, [%[c_ptr2], #0]                     \r\n"
      "ldr    q3, [%[c_ptr2], #16]                    \r\n"
      "ldr    q4, [%[c_ptr2], #32]                    \r\n"
      
      "fadd   v9.4s, v9.4s, v5.4s                     \r\n"
      "fadd   v17.4s, v17.4s, v0.4s                   \r\n"
      "fadd   v25.4s, v25.4s, v1.4s                   \r\n"

      "ldr    q5, [%[c_ptr3], #0]                     \r\n"
      "ldr    q0, [%[c_ptr3], #16]                    \r\n"
      "ldr    q1, [%[c_ptr3], #32]                    \r\n"
      
      "fadd   v10.4s, v10.4s, v2.4s                   \r\n"
      "fadd   v18.4s, v18.4s, v3.4s                   \r\n"
      "fadd   v26.4s, v26.4s, v4.4s                   \r\n"
      
      "ldr    q2, [%[c_ptr4], #0]                     \r\n"
      "ldr    q3, [%[c_ptr4], #16]                    \r\n"
      "ldr    q4, [%[c_ptr4], #32]                    \r\n"

      "fadd   v11.4s, v11.4s, v5.4s                   \r\n"
      "fadd   v19.4s, v19.4s, v0.4s                   \r\n"
      "fadd   v27.4s, v27.4s, v1.4s                   \r\n"
      
      "ldr    q5, [%[c_ptr5], #0]                     \r\n"
      "ldr    q0, [%[c_ptr5], #16]                    \r\n"
      "ldr    q1, [%[c_ptr5], #32]                    \r\n"

      "fadd   v12.4s, v12.4s, v2.4s                   \r\n"
      "fadd   v20.4s, v20.4s, v3.4s                   \r\n"
      "fadd   v28.4s, v28.4s, v4.4s                   \r\n"
      
      "ldr    q2, [%[c_ptr6], #0]                     \r\n"
      "ldr    q3, [%[c_ptr6], #16]                    \r\n"
      "ldr    q4, [%[c_ptr6], #32]                    \r\n"

      "fadd   v13.4s, v13.4s, v5.4s                   \r\n"
      "fadd   v21.4s, v21.4s, v0.4s                   \r\n"
      "fadd   v29.4s, v29.4s, v1.4s                   \r\n"

      "ldr    q5, [%[c_ptr7], #0]                     \r\n"
      "ldr    q0, [%[c_ptr7], #16]                    \r\n"
      "ldr    q1, [%[c_ptr7], #32]                    \r\n"

      "fadd   v14.4s, v14.4s, v2.4s                   \r\n"
      "fadd   v22.4s, v22.4s, v3.4s                   \r\n"
      "fadd   v30.4s, v30.4s, v4.4s                   \r\n"
      "fadd   v15.4s, v15.4s, v5.4s                   \r\n"
      "fadd   v23.4s, v23.4s, v0.4s                   \r\n"
      "fadd   v31.4s, v31.4s, v1.4s                   \r\n"   
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b)
        // [c_ptr] "+r" (c)
      : [kodd] "r" (kodd),
        // [ldc] "r" (ldc)
        [c_ptr0] "r" (c),
        [c_ptr1] "r" (c + ldc),
        [c_ptr2] "r" (c + ldc * 2),
        [c_ptr3] "r" (c + ldc * 3),
        [c_ptr4] "r" (c + ldc * 4),
        [c_ptr5] "r" (c + ldc * 5),
        [c_ptr6] "r" (c + ldc * 6),
        [c_ptr7] "r" (c + ldc * 7)
      : "x27", "x28", "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31",
        "cc"
    );
  } else {
    asm volatile (
      "cbnz   %x[kodd], 2f                            \r\n"

      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla 	v8.4s, v2.4s, v0.s[0]                   \r\n"
      "ldr    x27, [%[b_ptr], #40]                    \r\n"
      "fmla   v9.4s, v2.4s, v0.s[1]                   \r\n"
      "fmla	  v10.4s, v2.4s, v0.s[2]                  \r\n"

      "ldr	  d6, [%[a_ptr], #32]                     \r\n"
      "fmla	  v11.4s, v2.4s, v0.s[3]                  \r\n"
      "ldr    x28, [%[a_ptr], #40]                    \r\n"
      "fmla 	v12.4s, v2.4s, v1.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"

      "prfm   pstl1keep, [%[c_ptr0]]                  \r\n"
      "mov    v4.d[1], x27                            \r\n"
      "fmla	  v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla	  v15.4s, v2.4s, v1.s[3]                  \r\n"
      "fmla	  v16.4s, v3.4s, v0.s[0]                  \r\n"

      "ldr	  d2, [%[b_ptr], #48]                     \r\n"
      "mov    v6.d[1], x28                            \r\n"
      "fmla	  v17.4s, v3.4s, v0.s[1]                  \r\n"
      "ldr    x27, [%[b_ptr], #56]                    \r\n"
      "fmla	  v18.4s, v3.4s, v0.s[2]                  \r\n"
      "fmla	  v19.4s, v3.4s, v0.s[3]                  \r\n"

      "ldr	  d7, [%[a_ptr], #48]                     \r\n"
      "fmla	  v20.4s, v3.4s, v1.s[0]                  \r\n"
      "ldr    x28, [%[a_ptr], #56]                    \r\n"
      "fmla	  v21.4s, v3.4s, v1.s[1]                  \r\n"
      "fmla	  v22.4s, v3.4s, v1.s[2]                  \r\n"

      "prfm   pstl1keep, [%[c_ptr1]]                  \r\n"
      "mov    v2.d[1], x27                            \r\n"
      "fmla	  v23.4s, v3.4s, v1.s[3]                  \r\n"
      "fmla	  v24.4s, v4.4s, v0.s[0]                  \r\n"
      "fmla	  v25.4s, v4.4s, v0.s[1]                  \r\n"
      
      "ldr	  d3, [%[b_ptr], #64]                     \r\n"
      "fmla	  v26.4s, v4.4s, v0.s[2]                  \r\n"
      "ldr    x27, [%[b_ptr], #72]                    \r\n"
      "fmla	  v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v1.s[0]                  \r\n"

      "prfm   pstl1keep, [%[c_ptr2]]                  \r\n"
      "mov    v7.d[1], x28                            \r\n"
      "fmla	  v29.4s, v4.4s, v1.s[1]                  \r\n"
      "fmla	  v30.4s, v4.4s, v1.s[2]                  \r\n"
      "fmla	  v31.4s, v4.4s, v1.s[3]                  \r\n"

      "ldr	  d4, [%[b_ptr], #80]                     \r\n"
      "mov    v3.d[1], x27                            \r\n"
      "fmla 	v8.4s , v2.4s, v6.s[0]                  \r\n"
      "ldr    x28, [%[b_ptr], #88]                    \r\n"
      "fmla   v9.4s , v2.4s, v6.s[1]                  \r\n"
      "fmla	  v10.4s, v2.4s, v6.s[2]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr3]]                  \r\n"
      "fmla	  v11.4s, v2.4s, v6.s[3]                  \r\n"
      "fmla 	v12.4s, v2.4s, v7.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr4]]                  \r\n"
      "mov    v4.d[1], x28                            \r\n"
      "fmla   v13.4s, v2.4s, v7.s[1]                  \r\n"
      "fmla	  v16.4s, v3.4s, v6.s[0]                  \r\n"
      "fmla	  v17.4s, v3.4s, v6.s[1]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr5]]                  \r\n"
      "fmla	  v18.4s, v3.4s, v6.s[2]                  \r\n"
      "fmla	  v19.4s, v3.4s, v6.s[3]                  \r\n"
      "fmla	  v20.4s, v3.4s, v7.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr6]]                  \r\n"
      "fmla	  v21.4s, v3.4s, v7.s[1]                  \r\n"
      "fmla	  v24.4s, v4.4s, v6.s[0]                  \r\n"
      "fmla	  v25.4s, v4.4s, v6.s[1]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr7]]                  \r\n"
      "fmla	  v26.4s, v4.4s, v6.s[2]                  \r\n"
      "fmla	  v27.4s, v4.4s, v6.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v7.s[0]                  \r\n"
      "fmla	  v29.4s, v4.4s, v7.s[1]                  \r\n"
      "fmla	  v14.4s, v2.4s, v7.s[2]                  \r\n"
      "fmla	  v22.4s, v3.4s, v7.s[2]                  \r\n"
      "fmla	  v30.4s, v4.4s, v7.s[2]                  \r\n"
      "fmla	  v15.4s, v2.4s, v7.s[3]                  \r\n"
      "fmla	  v23.4s, v3.4s, v7.s[3]                  \r\n"
      "fmla	  v31.4s, v4.4s, v7.s[3]                  \r\n"

      "b      3f                                      \r\n"

      "2:                                             \r\n"
      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla 	v8.4s , v2.4s, v0.s[0]                  \r\n"
      "ldr    x27, [%[b_ptr], #40]                    \r\n"
      "fmla   v9.4s , v2.4s, v0.s[1]                  \r\n"
      "fmla	  v10.4s, v2.4s, v0.s[2]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr0]]                  \r\n"
      "fmla	  v11.4s, v2.4s, v0.s[3]                  \r\n"
      "fmla 	v12.4s, v2.4s, v1.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr1]]                  \r\n"
      "mov    v4.d[1], x27                            \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"
      "fmla	  v16.4s, v3.4s, v0.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr2]]                  \r\n"
      "fmla	  v17.4s, v3.4s, v0.s[1]                  \r\n"
      "fmla	  v18.4s, v3.4s, v0.s[2]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr3]]                  \r\n"
      "fmla	  v19.4s, v3.4s, v0.s[3]                  \r\n"
      "fmla	  v20.4s, v3.4s, v1.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr4]]                  \r\n"
      "fmla	  v21.4s, v3.4s, v1.s[1]                  \r\n"
      "fmla	  v24.4s, v4.4s, v0.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr5]]                  \r\n"
      "fmla	  v25.4s, v4.4s, v0.s[1]                  \r\n"
      "fmla	  v26.4s, v4.4s, v0.s[2]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr6]]                  \r\n"
      "fmla	  v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v1.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr7]]                  \r\n"
      "fmla	  v29.4s, v4.4s, v1.s[1]                  \r\n"
      "fmla	  v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla	  v22.4s, v3.4s, v1.s[2]                  \r\n"
      "fmla	  v30.4s, v4.4s, v1.s[2]                  \r\n"
      "fmla	  v15.4s, v2.4s, v1.s[3]                  \r\n"
      "fmla	  v23.4s, v3.4s, v1.s[3]                  \r\n"
      "fmla	  v31.4s, v4.4s, v1.s[3]                  \r\n"

      "3:                                             \r\n"
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b)
        // [c_ptr] "+r" (c)
      : [kodd] "r" (kodd),
        // [ldc] "r" (ldc)
        [c_ptr0] "r" (c),
        [c_ptr1] "r" (c + ldc),
        [c_ptr2] "r" (c + ldc * 2),
        [c_ptr3] "r" (c + ldc * 3),
        [c_ptr4] "r" (c + ldc * 4),
        [c_ptr5] "r" (c + ldc * 5),
        [c_ptr6] "r" (c + ldc * 6),
        [c_ptr7] "r" (c + ldc * 7)
      : "x27", "x28", "v0", "v1", "v2", "v3", "v4", "v6", "v7",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31",
        "cc"
    );
  }

  if constexpr (ReLU) {
    if constexpr (AddRes) {
      asm volatile (
        "movi   v5.4s, #0                               \r\n"
        :
        :
        : "v5"
      );
    }

    asm volatile (
      "fmax   v8.4s, v8.4s, v5.4s                     \r\n"
      "fmax   v16.4s, v16.4s, v5.4s                   \r\n"
      "fmax   v24.4s, v24.4s, v5.4s                   \r\n"
      "fmax   v9.4s, v9.4s, v5.4s                     \r\n"
      "fmax   v17.4s, v17.4s, v5.4s                   \r\n"
      "fmax   v25.4s, v25.4s, v5.4s                   \r\n"
      "fmax   v10.4s, v10.4s, v5.4s                   \r\n"
      "fmax   v18.4s, v18.4s, v5.4s                   \r\n"
      "fmax   v26.4s, v26.4s, v5.4s                   \r\n"
      "fmax   v11.4s, v11.4s, v5.4s                   \r\n"
      "fmax   v19.4s, v19.4s, v5.4s                   \r\n"
      "fmax   v27.4s, v27.4s, v5.4s                   \r\n"
      "fmax   v12.4s, v12.4s, v5.4s                   \r\n"
      "fmax   v20.4s, v20.4s, v5.4s                   \r\n"
      "fmax   v28.4s, v28.4s, v5.4s                   \r\n"
      "fmax   v13.4s, v13.4s, v5.4s                   \r\n"
      "fmax   v21.4s, v21.4s, v5.4s                   \r\n"
      "fmax   v29.4s, v29.4s, v5.4s                   \r\n"
      "fmax   v14.4s, v14.4s, v5.4s                   \r\n"
      "fmax   v22.4s, v22.4s, v5.4s                   \r\n"
      "fmax   v30.4s, v30.4s, v5.4s                   \r\n"
      "fmax   v15.4s, v15.4s, v5.4s                   \r\n"
      "fmax   v23.4s, v23.4s, v5.4s                   \r\n"
      "fmax   v31.4s, v31.4s, v5.4s                   \r\n"
      : 
      : 
      : "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31"
    );      
  }

  asm volatile (
    "str	  q8, [%[c_ptr0], #0]                     \r\n"
    "str	  q16, [%[c_ptr0], #16]                   \r\n"
    "str	  q24, [%[c_ptr0], #32]                   \r\n"
    "str	  q9, [%[c_ptr1], #0]                     \r\n"
    "str	  q17, [%[c_ptr1], #16]                   \r\n"
    "str	  q25, [%[c_ptr1], #32]                   \r\n"
    "str	  q10, [%[c_ptr2], #0]                    \r\n"
    "str	  q18, [%[c_ptr2], #16]                   \r\n"
    "str	  q26, [%[c_ptr2], #32]                   \r\n"
    "str	  q11, [%[c_ptr3], #0]                    \r\n"
    "str	  q19, [%[c_ptr3], #16]                   \r\n"
    "str	  q27, [%[c_ptr3], #32]                   \r\n"
    "str	  q12, [%[c_ptr4], #0]                    \r\n"
    "str	  q20, [%[c_ptr4], #16]                   \r\n"
    "str	  q28, [%[c_ptr4], #32]                   \r\n"
    "str	  q13, [%[c_ptr5], #0]                    \r\n"
    "str	  q21, [%[c_ptr5], #16]                   \r\n"
    "str	  q29, [%[c_ptr5], #32]                   \r\n"
    "str	  q14, [%[c_ptr6], #0]                    \r\n"
    "str	  q22, [%[c_ptr6], #16]                   \r\n"
    "str	  q30, [%[c_ptr6], #32]                   \r\n"
    "str	  q15, [%[c_ptr7], #0]                    \r\n"
    "str	  q23, [%[c_ptr7], #16]                   \r\n"
    "str	  q31, [%[c_ptr7], #32]                   \r\n"
    : 
    : [c_ptr0] "r" (c),
      [c_ptr1] "r" (c + ldc),
      [c_ptr2] "r" (c + ldc * 2),
      [c_ptr3] "r" (c + ldc * 3),
      [c_ptr4] "r" (c + ldc * 4),
      [c_ptr5] "r" (c + ldc * 5),
      [c_ptr6] "r" (c + ldc * 6),
      [c_ptr7] "r" (c + ldc * 7)
    : "memory"
  );

#else

  const int m = 8;
  const int n = 12;
  for(int i=0; i<m; i++) {
    for(int j=0; j<n; j++) {
      float val=0.0f;
      for(int l=0; l<k; l++) {
        Lhs aval, bval;
        aval = a[l*lda+i];
        // bval = b[ldb*l+j];
        bval = b[l*ldb+j];    // ReB & PackB

        // val+=a[lda*i+l]*b[ldb*l+j];
        val += aval * bval;
      }
      if (RScale && (RScaleBlend || Blend)) {
        val*=rscale[i];
      }
      if (Load) {
        if (FstIter && RScaleBlend) {
            val+=c[ldc*i+j]*rscale_blend[i];
        } else {
            val+=c[ldc*i+j];
        }
      }
      if (RScale && !(RScaleBlend || Blend)) {
          val*=rscale[i];
      }

      if(RBias) {
        val+=rbias[i];
      }
      if(ReLU) {
        val=std::max(0.0f, val);
      }
      c[ldc*i+j]=val;
    }
  }
#endif
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool Load,
    bool Itm2Res, bool Blend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernelv2<Lhs, Rhs, Res, Itm, float, 8, 11, CortexA53, true, true, false, Load, Itm2Res, Blend, false, false, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {

  constexpr bool RScale = false;
  constexpr bool RScaleBlend = false;
#ifndef C_MODEL
  // k MUST be not 0.
  int kodd = k & 1;
  int kloop = ((k + 1) >> 1) - 1;

  if constexpr (ReLU) {
    asm volatile (
      "movi   v5.4s, #0                               \r\n"
      :
      :
      : "v5"
    );
  }

  constexpr bool AddRes = Load && !(FstIter && RScaleBlend);

  if constexpr (RBias) {
    asm volatile (
      "ldr    q6, [%[bias_ptr]]                       \r\n"
      "ldr    q7, [%[bias_ptr], #16]                  \r\n"
      "ldr    q0, [%[a_ptr]]                          \r\n"
      "ldr    q2, [%[b_ptr]]                          \r\n"
      "ldr    q1, [%[a_ptr], #16]                     \r\n"
      "dup    v8.4s, v6.s[0]                          \r\n"
      "ldr    d3, [%[b_ptr], #16]                     \r\n"
      "dup    v9.4s, v6.s[1]                          \r\n"
      "ldr    x28, [%[b_ptr], #24]                    \r\n"
      "dup    v10.4s, v6.s[2]                         \r\n"
      "dup    v11.4s, v6.s[3]                         \r\n"
      "dup    v12.4s, v7.s[0]                         \r\n"
      "dup    v13.4s, v7.s[1]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #64]              \r\n"
      "dup    v14.4s, v7.s[2]                         \r\n"
      "dup    v15.4s, v7.s[3]                         \r\n"
      "prfm   pldl1keep, [%[a_ptr], #64]              \r\n"
      "dup    v16.4s, v6.s[0]                         \r\n"
      "dup    v17.4s, v6.s[1]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #128]             \r\n"
      "dup    v18.4s, v6.s[2]                         \r\n"
      "dup    v19.4s, v6.s[3]                         \r\n"
      "prfm   pldl1keep, [%[a_ptr], #128]             \r\n"
      "dup    v20.4s, v7.s[0]                         \r\n"
      "dup    v21.4s, v7.s[1]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #192]             \r\n"
      "dup    v22.4s, v7.s[2]                         \r\n"
      "dup    v23.4s, v7.s[3]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #256]             \r\n"
      "dup    v24.4s, v6.s[0]                         \r\n"
      "dup    v25.4s, v6.s[1]                         \r\n"
      "prfm   pldl1keep, [%[a_ptr], #192]             \r\n"
      "dup    v26.4s, v6.s[2]                         \r\n"
      "dup    v27.4s, v6.s[3]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #320]             \r\n"
      "dup    v28.4s, v7.s[0]                         \r\n"
      "dup    v29.4s, v7.s[1]                         \r\n"
      "prfm   pldl1keep, [%[a_ptr], #256]             \r\n"
      "dup    v30.4s, v7.s[2]                         \r\n"
      "dup    v31.4s, v7.s[3]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #384]             \r\n"
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b)
      : [bias_ptr] "r" (rbias)
      : "v0", "v1", "v2", "v3", "v6", "v7",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31"
    );
  } else {
    asm volatile (
      "movi   v8.4s, #0x0                               \r\n"
      "ldr    d0, [%[a_ptr]]                            \r\n"
      "movi   v9.4s, #0x0                               \r\n"
      "ldr    x27, [%[a_ptr], #8]                       \r\n"
      "movi   v10.4s, #0x0                              \r\n"
      "ldr    d2, [%[b_ptr]]                            \r\n"
      "movi   v11.4s, #0x0                              \r\n"
      "ldr    x28, [%[b_ptr], #8]                       \r\n"
      "movi   v12.4s, #0x0                              \r\n"
      "ldr    d1, [%[a_ptr], #16]                       \r\n"
      "movi   v13.4s, #0x0                              \r\n"
      "movi   v14.4s, #0x0                              \r\n"
      "movi   v15.4s, #0x0                              \r\n"
      "mov    v0.d[1], x27                              \r\n"
      "movi   v16.4s, #0x0                              \r\n"
      "ldr    x27, [%[a_ptr], #24]                      \r\n"
      "movi   v17.4s, #0x0                              \r\n"
      "ldr    d3, [%[b_ptr], #16]                       \r\n"
      "movi   v18.4s, #0x0                              \r\n"
      "mov    v2.d[1], x28                              \r\n"
      "movi   v19.4s, #0x0                              \r\n"
      "ldr    x28, [%[b_ptr], #24]                      \r\n"
      "movi   v20.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #64]                \r\n"
      "movi   v21.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[a_ptr], #64]                \r\n"
      "movi   v22.4s, #0x0                              \r\n"
      "mov    v1.d[1], x27                              \r\n"
      "movi   v23.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #128]               \r\n"
      "movi   v24.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[a_ptr], #128]               \r\n"
      "movi   v25.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #192]               \r\n"
      "movi   v26.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #256]               \r\n"
      "movi   v27.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[a_ptr], #192]               \r\n"
      "movi   v28.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #320]               \r\n"
      "movi   v29.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[a_ptr], #256]               \r\n"
      "movi   v30.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #384]               \r\n"
      "movi   v31.4s, #0x0                              \r\n"
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b)
      :
      : "x27", "x28", "v0", "v1", "v2", "v3",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31"
    );
  }

  if (kloop) {
    asm volatile (
      "1:                                             \r\n"
      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla   v8.4s, v2.4s, v0.s[0]                   \r\n"
      "ldr    x27, [%[b_ptr], #40]                    \r\n"
      "fmla   v9.4s, v2.4s, v0.s[1]                   \r\n"
      "fmla   v10.4s, v2.4s, v0.s[2]                  \r\n"

      "ldr	  d6, [%[a_ptr], #32]                     \r\n"
      "fmla   v11.4s, v2.4s, v0.s[3]                  \r\n"
      "ldr    x28, [%[a_ptr], #40]                    \r\n"
      "fmla   v12.4s, v2.4s, v1.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"
      
      "prfm   pldl1keep, [%[a_ptr], #320]             \r\n"
      "mov    v4.d[1], x27                            \r\n"
      "fmla   v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla   v15.4s, v2.4s, v1.s[3]                  \r\n"
      "fmla   v16.4s, v3.4s, v0.s[0]                  \r\n"

      "ldr    d2, [%[b_ptr], #48]                     \r\n"
      "mov    v6.d[1], x28                            \r\n"
      "fmla   v17.4s, v3.4s, v0.s[1]                  \r\n"
      "ldr    x27, [%[b_ptr], #56]                    \r\n"
      "fmla   v18.4s, v3.4s, v0.s[2]                  \r\n"
      "fmla   v19.4s, v3.4s, v0.s[3]                  \r\n"

      "ldr	  d7, [%[a_ptr], #48]                     \r\n"
      "fmla   v20.4s, v3.4s, v1.s[0]                  \r\n"
      "ldr    x28, [%[a_ptr], #56]                    \r\n"
      "fmla   v21.4s, v3.4s, v1.s[1]                  \r\n"
      "fmla   v22.4s, v3.4s, v1.s[2]                  \r\n"

      "prfm   pldl1keep, [%[b_ptr], #448]             \r\n"
      "mov    v2.d[1], x27                            \r\n"
      "fmla   v23.4s, v3.4s, v1.s[3]                  \r\n"
      "fmla   v24.4s, v4.4s, v0.s[0]                  \r\n"
      "fmla   v25.4s, v4.4s, v0.s[1]                  \r\n"

      "ldr    d3, [%[b_ptr], #64]                     \r\n"
      "fmla   v26.4s, v4.4s, v0.s[2]                  \r\n"
      "ldr    x27, [%[b_ptr], #72]                    \r\n"
      "fmla   v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla   v28.4s, v4.4s, v1.s[0]                  \r\n"

      "mov    v7.d[1], x28                            \r\n"
      "fmla   v29.4s, v4.4s, v1.s[1]                  \r\n"
      "fmla   v30.4s, v4.4s, v1.s[2]                  \r\n"
      "fmla   v31.4s, v4.4s, v1.s[3]                  \r\n"
      
      "ldr    d4, [%[b_ptr], #80]                     \r\n"
      "mov    v3.d[1], x27                            \r\n"
      "fmla   v8.4s, v2.4s, v6.s[0]                   \r\n"
      "ldr    x28, [%[b_ptr], #88]                    \r\n"
      "fmla   v9.4s, v2.4s, v6.s[1]                   \r\n"
      "fmla   v10.4s, v2.4s, v6.s[2]                  \r\n"

      "ldr    d0, [%[a_ptr], #64]                     \r\n"
      "fmla   v11.4s, v2.4s, v6.s[3]                  \r\n"
      "ldr    x27, [%[a_ptr], #72]                    \r\n"
      "fmla   v12.4s, v2.4s, v7.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v7.s[1]                  \r\n"

      "prfm   pldl1keep, [%[b_ptr], #512]             \r\n"
      "mov    v4.d[1], x28                            \r\n"
      "fmla   v14.4s, v2.4s, v7.s[2]                  \r\n"
      "fmla   v15.4s, v2.4s, v7.s[3]                  \r\n"
      "fmla   v16.4s, v3.4s, v6.s[0]                  \r\n"

      "ldr    d2, [%[b_ptr], #96]                     \r\n"
      "mov    v0.d[1], x27                            \r\n"
      "fmla   v17.4s, v3.4s, v6.s[1]                  \r\n"
      "ldr    x28, [%[b_ptr], #104]                   \r\n"
      "fmla   v18.4s, v3.4s, v6.s[2]                  \r\n"
      "fmla   v19.4s, v3.4s, v6.s[3]                  \r\n"

      "ldr	  d1, [%[a_ptr], #80]                     \r\n"
      "fmla   v20.4s, v3.4s, v7.s[0]                  \r\n"
      "ldr    x27, [%[a_ptr], #88]                    \r\n"
      "fmla   v21.4s, v3.4s, v7.s[1]                  \r\n"
      "fmla   v22.4s, v3.4s, v7.s[2]                  \r\n"

      "mov    v2.d[1], x28                            \r\n"
      "add    %[a_ptr], %[a_ptr], #64                 \r\n"
      "fmla   v23.4s, v3.4s, v7.s[3]                  \r\n"
      "fmla   v24.4s, v4.4s, v6.s[0]                  \r\n"
      "fmla   v25.4s, v4.4s, v6.s[1]                  \r\n"

      "ldr    d3, [%[b_ptr], #112]                    \r\n"
      "subs   %x[kloop], %x[kloop], #1                \r\n"
      "fmla   v26.4s, v4.4s, v6.s[2]                  \r\n"
      "ldr    x28, [%[b_ptr], #120]                   \r\n"
      "fmla   v27.4s, v4.4s, v6.s[3]                  \r\n"
      "fmla   v28.4s, v4.4s, v7.s[0]                  \r\n"
      
      "mov    v1.d[1], x27                            \r\n"
      "add    %[b_ptr], %[b_ptr], #96                 \r\n"
      "fmla   v29.4s, v4.4s, v7.s[1]                  \r\n"
      "fmla   v30.4s, v4.4s, v7.s[2]                  \r\n"
      "fmla   v31.4s, v4.4s, v7.s[3]                  \r\n"

      "bne    1b                                      \r\n"
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b),
        [kloop] "+r" (kloop)
      :
      : "x27", "x28", "v0", "v1", "v2", "v3", "v4", "v6", "v7",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31",
        "cc"
    );
  }

  // if constexpr (RBias && AddRes) {
  if constexpr (AddRes) {
    asm volatile (
      "cbnz   %x[kodd], 2f                            \r\n"

      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla 	v8.4s, v2.4s, v0.s[0]                   \r\n"
      "ldr    x27, [%[b_ptr], #40]                    \r\n"
      "fmla   v9.4s, v2.4s, v0.s[1]                   \r\n"
      "fmla	  v10.4s, v2.4s, v0.s[2]                  \r\n"

      "ldr	  d6, [%[a_ptr], #32]                     \r\n"
      "fmla	  v11.4s, v2.4s, v0.s[3]                  \r\n"
      "ldr    x28, [%[a_ptr], #40]                    \r\n"
      "fmla 	v12.4s, v2.4s, v1.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr0]]                  \r\n"
      "mov    v4.d[1], x27                            \r\n"
      "fmla	  v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla	  v15.4s, v2.4s, v1.s[3]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr1]]                  \r\n"
      "fmla	  v16.4s, v3.4s, v0.s[0]                  \r\n"

      "ldr	  d2, [%[b_ptr], #48]                     \r\n"
      "mov    v6.d[1], x28                            \r\n"
      "fmla	  v17.4s, v3.4s, v0.s[1]                  \r\n"
      "ldr    x27, [%[b_ptr], #56]                    \r\n"
      "fmla	  v18.4s, v3.4s, v0.s[2]                  \r\n"
      "fmla	  v19.4s, v3.4s, v0.s[3]                  \r\n"

      "ldr	  d7, [%[a_ptr], #48]                     \r\n"
      "fmla	  v20.4s, v3.4s, v1.s[0]                  \r\n"
      "ldr    x28, [%[a_ptr], #56]                    \r\n"
      "fmla	  v21.4s, v3.4s, v1.s[1]                  \r\n"
      "fmla	  v22.4s, v3.4s, v1.s[2]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr2]]                  \r\n"
      "mov    v2.d[1], x27                            \r\n"
      "fmla	  v23.4s, v3.4s, v1.s[3]                  \r\n"
      "fmla	  v24.4s, v4.4s, v0.s[0]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr3]]                  \r\n"
      "fmla	  v25.4s, v4.4s, v0.s[1]                  \r\n"
      
      "ldr	  d3, [%[b_ptr], #64]                     \r\n"
      "fmla	  v26.4s, v4.4s, v0.s[2]                  \r\n"
      "ldr    x27, [%[b_ptr], #72]                    \r\n"
      "fmla	  v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v1.s[0]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr4]]                  \r\n"
      "mov    v7.d[1], x28                            \r\n"
      "fmla	  v29.4s, v4.4s, v1.s[1]                  \r\n"
      "fmla	  v30.4s, v4.4s, v1.s[2]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr5]]                  \r\n"
      "fmla	  v31.4s, v4.4s, v1.s[3]                  \r\n"

      "ldr	  d4, [%[b_ptr], #80]                     \r\n"
      "mov    v3.d[1], x27                            \r\n"
      "fmla 	v8.4s , v2.4s, v6.s[0]                  \r\n"
      "ldr    x28, [%[b_ptr], #88]                    \r\n"
      "fmla   v9.4s , v2.4s, v6.s[1]                  \r\n"
      "fmla	  v10.4s, v2.4s, v6.s[2]                  \r\n"

      "ldr    d5, [%[c_ptr0], #0]                     \r\n"
      "fmla	  v11.4s, v2.4s, v6.s[3]                  \r\n"
      "ldr    x27, [%[c_ptr0], #8]                    \r\n"
      "fmla 	v12.4s, v2.4s, v7.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v7.s[1]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr6]]                  \r\n"
      "mov    v4.d[1], x28                            \r\n"
      "fmla	  v16.4s, v3.4s, v6.s[0]                  \r\n"
      "fmla	  v17.4s, v3.4s, v6.s[1]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr7]]                  \r\n"
      "fmla	  v18.4s, v3.4s, v6.s[2]                  \r\n"

      "ldr    d0, [%[c_ptr0], #16]                    \r\n"
      "mov    v5.d[1], x27                            \r\n"
      "fmla	  v19.4s, v3.4s, v6.s[3]                  \r\n"
      "ldr    x28, [%[c_ptr0], #24]                   \r\n"
      "fmla	  v20.4s, v3.4s, v7.s[0]                  \r\n"
      "fmla	  v21.4s, v3.4s, v7.s[1]                  \r\n"

      "ldr    d1, [%[c_ptr0], #32]                    \r\n"
      "fmla	  v24.4s, v4.4s, v6.s[0]                  \r\n"
      "ldr    x27, [%[c_ptr0], #40]                   \r\n"
      "fmla	  v25.4s, v4.4s, v6.s[1]                  \r\n"
      "fmla	  v26.4s, v4.4s, v6.s[2]                  \r\n"

      "fadd   v8.4s, v8.4s, v5.4s                     \r\n"
      "mov    v0.d[1], x28                            \r\n"
      "fmla	  v27.4s, v4.4s, v6.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v7.s[0]                  \r\n"
      "fmla	  v29.4s, v4.4s, v7.s[1]                  \r\n"

      "mov    v1.d[1], x27                            \r\n"
      "fmla	  v14.4s, v2.4s, v7.s[2]                  \r\n"
      "fmla	  v22.4s, v3.4s, v7.s[2]                  \r\n"
      "fmla	  v30.4s, v4.4s, v7.s[2]                  \r\n"

      "fadd   v16.4s, v16.4s, v0.4s                   \r\n"
      "fmla	  v15.4s, v2.4s, v7.s[3]                  \r\n"
      "fmla	  v23.4s, v3.4s, v7.s[3]                  \r\n"
      "fmla	  v31.4s, v4.4s, v7.s[3]                  \r\n"

      "fadd   v24.4s, v24.4s, v1.4s                   \r\n"

      "b      3f                                      \r\n"

      "2:                                             \r\n"
      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla 	v8.4s , v2.4s, v0.s[0]                  \r\n"
      "ldr    x27, [%[b_ptr], #40]                    \r\n"
      "fmla   v9.4s , v2.4s, v0.s[1]                  \r\n"
      "fmla	  v10.4s, v2.4s, v0.s[2]                  \r\n"

      "ldr    d5, [%[c_ptr0], #0]                     \r\n"
      "fmla	  v11.4s, v2.4s, v0.s[3]                  \r\n"
      "ldr    x28, [%[c_ptr0], #8]                    \r\n"
      "fmla 	v12.4s, v2.4s, v1.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr1]]                  \r\n"
      "mov    v4.d[1], x27                            \r\n"
      "fmla	  v16.4s, v3.4s, v0.s[0]                  \r\n"
      "fmla	  v17.4s, v3.4s, v0.s[1]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr2]]                  \r\n"
      "fmla	  v18.4s, v3.4s, v0.s[2]                  \r\n"

      "ldr    d6, [%[c_ptr0], #16]                    \r\n"
      "mov    v5.d[1], x28                            \r\n"
      "fmla	  v19.4s, v3.4s, v0.s[3]                  \r\n"
      "ldr    x27, [%[c_ptr0], #24]                   \r\n"
      "fmla	  v20.4s, v3.4s, v1.s[0]                  \r\n"
      "fmla	  v21.4s, v3.4s, v1.s[1]                  \r\n"

      "ldr    d7, [%[c_ptr0], #32]                    \r\n"
      "fmla	  v24.4s, v4.4s, v0.s[0]                  \r\n"
      "ldr    x28, [%[c_ptr0], #40]                   \r\n"
      "fmla	  v25.4s, v4.4s, v0.s[1]                  \r\n"
      "fmla	  v26.4s, v4.4s, v0.s[2]                  \r\n"
      
      "fadd   v8.4s, v8.4s, v5.4s                     \r\n"
      "mov    v6.d[1], x27                            \r\n"
      "fmla	  v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v1.s[0]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr3]]                  \r\n"
      "fmla	  v29.4s, v4.4s, v1.s[1]                  \r\n"
      
      "prfm   pldl1keep, [%[c_ptr4]]                  \r\n"
      "mov    v7.d[1], x28                            \r\n"
      "fmla	  v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla	  v22.4s, v3.4s, v1.s[2]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr5]]                  \r\n"
      "fmla	  v30.4s, v4.4s, v1.s[2]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr6]]                  \r\n"
      "fadd   v16.4s, v16.4s, v6.4s                   \r\n"
      "fmla	  v15.4s, v2.4s, v1.s[3]                  \r\n"
      "fmla	  v23.4s, v3.4s, v1.s[3]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr7]]                  \r\n"
      "fmla	  v31.4s, v4.4s, v1.s[3]                  \r\n"

      "fadd   v24.4s, v24.4s, v7.4s                   \r\n"

      "3:                                             \r\n"
      "ldr    q5, [%[c_ptr1], #0]                     \r\n"
      "ldr    q0, [%[c_ptr1], #16]                    \r\n"
      "ldr    q1, [%[c_ptr1], #32]                    \r\n"

      "ldr    q2, [%[c_ptr2], #0]                     \r\n"
      "ldr    q3, [%[c_ptr2], #16]                    \r\n"
      "ldr    q4, [%[c_ptr2], #32]                    \r\n"
      
      "fadd   v9.4s, v9.4s, v5.4s                     \r\n"
      "fadd   v17.4s, v17.4s, v0.4s                   \r\n"
      "fadd   v25.4s, v25.4s, v1.4s                   \r\n"

      "ldr    q5, [%[c_ptr3], #0]                     \r\n"
      "ldr    q0, [%[c_ptr3], #16]                    \r\n"
      "ldr    q1, [%[c_ptr3], #32]                    \r\n"
      
      "fadd   v10.4s, v10.4s, v2.4s                   \r\n"
      "fadd   v18.4s, v18.4s, v3.4s                   \r\n"
      "fadd   v26.4s, v26.4s, v4.4s                   \r\n"
      
      "ldr    q2, [%[c_ptr4], #0]                     \r\n"
      "ldr    q3, [%[c_ptr4], #16]                    \r\n"
      "ldr    q4, [%[c_ptr4], #32]                    \r\n"

      "fadd   v11.4s, v11.4s, v5.4s                   \r\n"
      "fadd   v19.4s, v19.4s, v0.4s                   \r\n"
      "fadd   v27.4s, v27.4s, v1.4s                   \r\n"
      
      "ldr    q5, [%[c_ptr5], #0]                     \r\n"
      "ldr    q0, [%[c_ptr5], #16]                    \r\n"
      "ldr    q1, [%[c_ptr5], #32]                    \r\n"

      "fadd   v12.4s, v12.4s, v2.4s                   \r\n"
      "fadd   v20.4s, v20.4s, v3.4s                   \r\n"
      "fadd   v28.4s, v28.4s, v4.4s                   \r\n"
      
      "ldr    q2, [%[c_ptr6], #0]                     \r\n"
      "ldr    q3, [%[c_ptr6], #16]                    \r\n"
      "ldr    q4, [%[c_ptr6], #32]                    \r\n"

      "fadd   v13.4s, v13.4s, v5.4s                   \r\n"
      "fadd   v21.4s, v21.4s, v0.4s                   \r\n"
      "fadd   v29.4s, v29.4s, v1.4s                   \r\n"

      "ldr    q5, [%[c_ptr7], #0]                     \r\n"
      "ldr    q0, [%[c_ptr7], #16]                    \r\n"
      "ldr    q1, [%[c_ptr7], #32]                    \r\n"

      "fadd   v14.4s, v14.4s, v2.4s                   \r\n"
      "fadd   v22.4s, v22.4s, v3.4s                   \r\n"
      "fadd   v30.4s, v30.4s, v4.4s                   \r\n"
      "fadd   v15.4s, v15.4s, v5.4s                   \r\n"
      "fadd   v23.4s, v23.4s, v0.4s                   \r\n"
      "fadd   v31.4s, v31.4s, v1.4s                   \r\n"   
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b)
        // [c_ptr] "+r" (c)
      : [kodd] "r" (kodd),
        // [ldc] "r" (ldc)
        [c_ptr0] "r" (c),
        [c_ptr1] "r" (c + ldc),
        [c_ptr2] "r" (c + ldc * 2),
        [c_ptr3] "r" (c + ldc * 3),
        [c_ptr4] "r" (c + ldc * 4),
        [c_ptr5] "r" (c + ldc * 5),
        [c_ptr6] "r" (c + ldc * 6),
        [c_ptr7] "r" (c + ldc * 7)
      : "x27", "x28", "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31",
        "cc"
    );
  } else {
    asm volatile (
      "cbnz   %x[kodd], 2f                            \r\n"

      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla 	v8.4s, v2.4s, v0.s[0]                   \r\n"
      "ldr    x27, [%[b_ptr], #40]                    \r\n"
      "fmla   v9.4s, v2.4s, v0.s[1]                   \r\n"
      "fmla	  v10.4s, v2.4s, v0.s[2]                  \r\n"

      "ldr	  d6, [%[a_ptr], #32]                     \r\n"
      "fmla	  v11.4s, v2.4s, v0.s[3]                  \r\n"
      "ldr    x28, [%[a_ptr], #40]                    \r\n"
      "fmla 	v12.4s, v2.4s, v1.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"

      "prfm   pstl1keep, [%[c_ptr0]]                  \r\n"
      "mov    v4.d[1], x27                            \r\n"
      "fmla	  v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla	  v15.4s, v2.4s, v1.s[3]                  \r\n"
      "fmla	  v16.4s, v3.4s, v0.s[0]                  \r\n"

      "ldr	  d2, [%[b_ptr], #48]                     \r\n"
      "mov    v6.d[1], x28                            \r\n"
      "fmla	  v17.4s, v3.4s, v0.s[1]                  \r\n"
      "ldr    x27, [%[b_ptr], #56]                    \r\n"
      "fmla	  v18.4s, v3.4s, v0.s[2]                  \r\n"
      "fmla	  v19.4s, v3.4s, v0.s[3]                  \r\n"

      "ldr	  d7, [%[a_ptr], #48]                     \r\n"
      "fmla	  v20.4s, v3.4s, v1.s[0]                  \r\n"
      "ldr    x28, [%[a_ptr], #56]                    \r\n"
      "fmla	  v21.4s, v3.4s, v1.s[1]                  \r\n"
      "fmla	  v22.4s, v3.4s, v1.s[2]                  \r\n"

      "prfm   pstl1keep, [%[c_ptr1]]                  \r\n"
      "mov    v2.d[1], x27                            \r\n"
      "fmla	  v23.4s, v3.4s, v1.s[3]                  \r\n"
      "fmla	  v24.4s, v4.4s, v0.s[0]                  \r\n"
      "fmla	  v25.4s, v4.4s, v0.s[1]                  \r\n"
      
      "ldr	  d3, [%[b_ptr], #64]                     \r\n"
      "fmla	  v26.4s, v4.4s, v0.s[2]                  \r\n"
      "ldr    x27, [%[b_ptr], #72]                    \r\n"
      "fmla	  v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v1.s[0]                  \r\n"

      "prfm   pstl1keep, [%[c_ptr2]]                  \r\n"
      "mov    v7.d[1], x28                            \r\n"
      "fmla	  v29.4s, v4.4s, v1.s[1]                  \r\n"
      "fmla	  v30.4s, v4.4s, v1.s[2]                  \r\n"
      "fmla	  v31.4s, v4.4s, v1.s[3]                  \r\n"

      "ldr	  d4, [%[b_ptr], #80]                     \r\n"
      "mov    v3.d[1], x27                            \r\n"
      "fmla 	v8.4s , v2.4s, v6.s[0]                  \r\n"
      "ldr    x28, [%[b_ptr], #88]                    \r\n"
      "fmla   v9.4s , v2.4s, v6.s[1]                  \r\n"
      "fmla	  v10.4s, v2.4s, v6.s[2]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr3]]                  \r\n"
      "fmla	  v11.4s, v2.4s, v6.s[3]                  \r\n"
      "fmla 	v12.4s, v2.4s, v7.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr4]]                  \r\n"
      "mov    v4.d[1], x28                            \r\n"
      "fmla   v13.4s, v2.4s, v7.s[1]                  \r\n"
      "fmla	  v16.4s, v3.4s, v6.s[0]                  \r\n"
      "fmla	  v17.4s, v3.4s, v6.s[1]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr5]]                  \r\n"
      "fmla	  v18.4s, v3.4s, v6.s[2]                  \r\n"
      "fmla	  v19.4s, v3.4s, v6.s[3]                  \r\n"
      "fmla	  v20.4s, v3.4s, v7.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr6]]                  \r\n"
      "fmla	  v21.4s, v3.4s, v7.s[1]                  \r\n"
      "fmla	  v24.4s, v4.4s, v6.s[0]                  \r\n"
      "fmla	  v25.4s, v4.4s, v6.s[1]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr7]]                  \r\n"
      "fmla	  v26.4s, v4.4s, v6.s[2]                  \r\n"
      "fmla	  v27.4s, v4.4s, v6.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v7.s[0]                  \r\n"
      "fmla	  v29.4s, v4.4s, v7.s[1]                  \r\n"
      "fmla	  v14.4s, v2.4s, v7.s[2]                  \r\n"
      "fmla	  v22.4s, v3.4s, v7.s[2]                  \r\n"
      "fmla	  v30.4s, v4.4s, v7.s[2]                  \r\n"
      "fmla	  v15.4s, v2.4s, v7.s[3]                  \r\n"
      "fmla	  v23.4s, v3.4s, v7.s[3]                  \r\n"
      "fmla	  v31.4s, v4.4s, v7.s[3]                  \r\n"

      "b      3f                                      \r\n"

      "2:                                             \r\n"
      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla 	v8.4s , v2.4s, v0.s[0]                  \r\n"
      "ldr    x27, [%[b_ptr], #40]                    \r\n"
      "fmla   v9.4s , v2.4s, v0.s[1]                  \r\n"
      "fmla	  v10.4s, v2.4s, v0.s[2]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr0]]                  \r\n"
      "fmla	  v11.4s, v2.4s, v0.s[3]                  \r\n"
      "fmla 	v12.4s, v2.4s, v1.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr1]]                  \r\n"
      "mov    v4.d[1], x27                            \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"
      "fmla	  v16.4s, v3.4s, v0.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr2]]                  \r\n"
      "fmla	  v17.4s, v3.4s, v0.s[1]                  \r\n"
      "fmla	  v18.4s, v3.4s, v0.s[2]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr3]]                  \r\n"
      "fmla	  v19.4s, v3.4s, v0.s[3]                  \r\n"
      "fmla	  v20.4s, v3.4s, v1.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr4]]                  \r\n"
      "fmla	  v21.4s, v3.4s, v1.s[1]                  \r\n"
      "fmla	  v24.4s, v4.4s, v0.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr5]]                  \r\n"
      "fmla	  v25.4s, v4.4s, v0.s[1]                  \r\n"
      "fmla	  v26.4s, v4.4s, v0.s[2]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr6]]                  \r\n"
      "fmla	  v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v1.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr7]]                  \r\n"
      "fmla	  v29.4s, v4.4s, v1.s[1]                  \r\n"
      "fmla	  v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla	  v22.4s, v3.4s, v1.s[2]                  \r\n"
      "fmla	  v30.4s, v4.4s, v1.s[2]                  \r\n"
      "fmla	  v15.4s, v2.4s, v1.s[3]                  \r\n"
      "fmla	  v23.4s, v3.4s, v1.s[3]                  \r\n"
      "fmla	  v31.4s, v4.4s, v1.s[3]                  \r\n"

      "3:                                             \r\n"
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b)
        // [c_ptr] "+r" (c)
      : [kodd] "r" (kodd),
        // [ldc] "r" (ldc)
        [c_ptr0] "r" (c),
        [c_ptr1] "r" (c + ldc),
        [c_ptr2] "r" (c + ldc * 2),
        [c_ptr3] "r" (c + ldc * 3),
        [c_ptr4] "r" (c + ldc * 4),
        [c_ptr5] "r" (c + ldc * 5),
        [c_ptr6] "r" (c + ldc * 6),
        [c_ptr7] "r" (c + ldc * 7)
      : "x27", "x28", "v0", "v1", "v2", "v3", "v4", "v6", "v7",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31",
        "cc"
    );
  }

  if constexpr (ReLU) {
    if constexpr (AddRes) {
      asm volatile (
        "movi   v5.4s, #0                               \r\n"
        :
        :
        : "v5"
      );
    }

    asm volatile (
      "fmax   v8.4s, v8.4s, v5.4s                     \r\n"
      "fmax   v16.4s, v16.4s, v5.4s                   \r\n"
      "fmax   v24.4s, v24.4s, v5.4s                   \r\n"
      "fmax   v9.4s, v9.4s, v5.4s                     \r\n"
      "fmax   v17.4s, v17.4s, v5.4s                   \r\n"
      "fmax   v25.4s, v25.4s, v5.4s                   \r\n"
      "fmax   v10.4s, v10.4s, v5.4s                   \r\n"
      "fmax   v18.4s, v18.4s, v5.4s                   \r\n"
      "fmax   v26.4s, v26.4s, v5.4s                   \r\n"
      "fmax   v11.4s, v11.4s, v5.4s                   \r\n"
      "fmax   v19.4s, v19.4s, v5.4s                   \r\n"
      "fmax   v27.4s, v27.4s, v5.4s                   \r\n"
      "fmax   v12.4s, v12.4s, v5.4s                   \r\n"
      "fmax   v20.4s, v20.4s, v5.4s                   \r\n"
      "fmax   v28.4s, v28.4s, v5.4s                   \r\n"
      "fmax   v13.4s, v13.4s, v5.4s                   \r\n"
      "fmax   v21.4s, v21.4s, v5.4s                   \r\n"
      "fmax   v29.4s, v29.4s, v5.4s                   \r\n"
      "fmax   v14.4s, v14.4s, v5.4s                   \r\n"
      "fmax   v22.4s, v22.4s, v5.4s                   \r\n"
      "fmax   v30.4s, v30.4s, v5.4s                   \r\n"
      "fmax   v15.4s, v15.4s, v5.4s                   \r\n"
      "fmax   v23.4s, v23.4s, v5.4s                   \r\n"
      "fmax   v31.4s, v31.4s, v5.4s                   \r\n"
      : 
      : 
      : "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31"
    );      
  }

  asm volatile (
    "mov    s0, v24.s[2]                            \r\n"
    "mov    s1, v25.s[2]                            \r\n"
    "mov    s2, v26.s[2]                            \r\n"
    "mov    s3, v27.s[2]                            \r\n"
    "mov    s4, v28.s[2]                            \r\n"
    "mov    s5, v29.s[2]                            \r\n"
    "mov    s6, v30.s[2]                            \r\n"
    "mov    s7, v31.s[2]                            \r\n"
    "str	  q8, [%[c_ptr0], #0]                     \r\n"
    "str	  q16, [%[c_ptr0], #16]                   \r\n"
    "str	  d24, [%[c_ptr0], #32]                   \r\n"
    "str	  s0, [%[c_ptr0], #40]                    \r\n"
    "str	  q9, [%[c_ptr1], #0]                     \r\n"
    "str	  q17, [%[c_ptr1], #16]                   \r\n"
    "str	  d25, [%[c_ptr1], #32]                   \r\n"
    "str	  s1, [%[c_ptr1], #40]                    \r\n"
    "str	  q10, [%[c_ptr2], #0]                    \r\n"
    "str	  q18, [%[c_ptr2], #16]                   \r\n"
    "str	  d26, [%[c_ptr2], #32]                   \r\n"
    "str	  s2, [%[c_ptr2], #40]                    \r\n"
    "str	  q11, [%[c_ptr3], #0]                    \r\n"
    "str	  q19, [%[c_ptr3], #16]                   \r\n"
    "str	  d27, [%[c_ptr3], #32]                   \r\n"
    "str	  s3, [%[c_ptr3], #40]                    \r\n"
    "str	  q12, [%[c_ptr4], #0]                    \r\n"
    "str	  q20, [%[c_ptr4], #16]                   \r\n"
    "str	  d28, [%[c_ptr4], #32]                   \r\n"
    "str	  s4, [%[c_ptr4], #40]                    \r\n"
    "str	  q13, [%[c_ptr5], #0]                    \r\n"
    "str	  q21, [%[c_ptr5], #16]                   \r\n"
    "str	  d29, [%[c_ptr5], #32]                   \r\n"
    "str	  s5, [%[c_ptr5], #40]                    \r\n"
    "str	  q14, [%[c_ptr6], #0]                    \r\n"
    "str	  q22, [%[c_ptr6], #16]                   \r\n"
    "str	  d30, [%[c_ptr6], #32]                   \r\n"
    "str	  s6, [%[c_ptr6], #40]                    \r\n"
    "str	  q15, [%[c_ptr7], #0]                    \r\n"
    "str	  q23, [%[c_ptr7], #16]                   \r\n"
    "str	  d31, [%[c_ptr7], #32]                   \r\n"
    "str	  s7, [%[c_ptr7], #40]                    \r\n"
    : 
    : [c_ptr0] "r" (c),
      [c_ptr1] "r" (c + ldc),
      [c_ptr2] "r" (c + ldc * 2),
      [c_ptr3] "r" (c + ldc * 3),
      [c_ptr4] "r" (c + ldc * 4),
      [c_ptr5] "r" (c + ldc * 5),
      [c_ptr6] "r" (c + ldc * 6),
      [c_ptr7] "r" (c + ldc * 7)
    : "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", 
      "memory"
  );

#else

  const int m = 8;
  const int n = 12;
  for(int i=0; i<m; i++) {
    for(int j=0; j<n; j++) {
      float val=0.0f;
      for(int l=0; l<k; l++) {
        Lhs aval, bval;
        aval = a[l*lda+i];
        // bval = b[ldb*l+j];
        bval = b[l*ldb+j];    // ReB & PackB

        // val+=a[lda*i+l]*b[ldb*l+j];
        val += aval * bval;
      }
      if (RScale && (RScaleBlend || Blend)) {
        val*=rscale[i];
      }
      if (Load) {
        if (FstIter && RScaleBlend) {
            val+=c[ldc*i+j]*rscale_blend[i];
        } else {
            val+=c[ldc*i+j];
        }
      }
      if (RScale && !(RScaleBlend || Blend)) {
          val*=rscale[i];
      }

      if(RBias) {
        val+=rbias[i];
      }
      if(ReLU) {
        val=std::max(0.0f, val);
      }
      c[ldc*i+j]=val;
    }
  }
#endif
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool Load,
    bool Itm2Res, bool Blend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernelv2<Lhs, Rhs, Res, Itm, float, 8, 10, CortexA53, true, true, false, Load, Itm2Res, Blend, false, false, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {

  constexpr bool RScale = false;
  constexpr bool RScaleBlend = false;
#ifndef C_MODEL
  // k MUST be not 0.
  int kodd = k & 1;
  int kloop = ((k + 1) >> 1) - 1;

  if constexpr (ReLU) {
    asm volatile (
      "movi   v5.4s, #0                               \r\n"
      :
      :
      : "v5"
    );
  }

  constexpr bool AddRes = Load && !(FstIter && RScaleBlend);

  if constexpr (RBias) {
    asm volatile (
      "ldr    q6, [%[bias_ptr]]                       \r\n"
      "ldr    q7, [%[bias_ptr], #16]                  \r\n"
      "ldr    q0, [%[a_ptr]]                          \r\n"
      "ldr    q2, [%[b_ptr]]                          \r\n"
      "ldr    q1, [%[a_ptr], #16]                     \r\n"
      "dup    v8.4s, v6.s[0]                          \r\n"
      "ldr    d3, [%[b_ptr], #16]                     \r\n"
      "dup    v9.4s, v6.s[1]                          \r\n"
      "ldr    x28, [%[b_ptr], #24]                    \r\n"
      "dup    v10.4s, v6.s[2]                         \r\n"
      "dup    v11.4s, v6.s[3]                         \r\n"
      "dup    v12.4s, v7.s[0]                         \r\n"
      "dup    v13.4s, v7.s[1]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #64]              \r\n"
      "dup    v14.4s, v7.s[2]                         \r\n"
      "dup    v15.4s, v7.s[3]                         \r\n"
      "prfm   pldl1keep, [%[a_ptr], #64]              \r\n"
      "dup    v16.4s, v6.s[0]                         \r\n"
      "dup    v17.4s, v6.s[1]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #128]             \r\n"
      "dup    v18.4s, v6.s[2]                         \r\n"
      "dup    v19.4s, v6.s[3]                         \r\n"
      "prfm   pldl1keep, [%[a_ptr], #128]             \r\n"
      "dup    v20.4s, v7.s[0]                         \r\n"
      "dup    v21.4s, v7.s[1]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #192]             \r\n"
      "dup    v22.4s, v7.s[2]                         \r\n"
      "dup    v23.4s, v7.s[3]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #256]             \r\n"
      "dup    v24.4s, v6.s[0]                         \r\n"
      "dup    v25.4s, v6.s[1]                         \r\n"
      "prfm   pldl1keep, [%[a_ptr], #192]             \r\n"
      "dup    v26.4s, v6.s[2]                         \r\n"
      "dup    v27.4s, v6.s[3]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #320]             \r\n"
      "dup    v28.4s, v7.s[0]                         \r\n"
      "dup    v29.4s, v7.s[1]                         \r\n"
      "prfm   pldl1keep, [%[a_ptr], #256]             \r\n"
      "dup    v30.4s, v7.s[2]                         \r\n"
      "dup    v31.4s, v7.s[3]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #384]             \r\n"
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b)
      : [bias_ptr] "r" (rbias)
      : "v0", "v1", "v2", "v3", "v6", "v7",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31"
    );
  } else {
    asm volatile (
      "movi   v8.4s, #0x0                               \r\n"
      "ldr    d0, [%[a_ptr]]                            \r\n"
      "movi   v9.4s, #0x0                               \r\n"
      "ldr    x27, [%[a_ptr], #8]                       \r\n"
      "movi   v10.4s, #0x0                              \r\n"
      "ldr    d2, [%[b_ptr]]                            \r\n"
      "movi   v11.4s, #0x0                              \r\n"
      "ldr    x28, [%[b_ptr], #8]                       \r\n"
      "movi   v12.4s, #0x0                              \r\n"
      "ldr    d1, [%[a_ptr], #16]                       \r\n"
      "movi   v13.4s, #0x0                              \r\n"
      "movi   v14.4s, #0x0                              \r\n"
      "movi   v15.4s, #0x0                              \r\n"
      "mov    v0.d[1], x27                              \r\n"
      "movi   v16.4s, #0x0                              \r\n"
      "ldr    x27, [%[a_ptr], #24]                      \r\n"
      "movi   v17.4s, #0x0                              \r\n"
      "ldr    d3, [%[b_ptr], #16]                       \r\n"
      "movi   v18.4s, #0x0                              \r\n"
      "mov    v2.d[1], x28                              \r\n"
      "movi   v19.4s, #0x0                              \r\n"
      "ldr    x28, [%[b_ptr], #24]                      \r\n"
      "movi   v20.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #64]                \r\n"
      "movi   v21.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[a_ptr], #64]                \r\n"
      "movi   v22.4s, #0x0                              \r\n"
      "mov    v1.d[1], x27                              \r\n"
      "movi   v23.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #128]               \r\n"
      "movi   v24.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[a_ptr], #128]               \r\n"
      "movi   v25.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #192]               \r\n"
      "movi   v26.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #256]               \r\n"
      "movi   v27.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[a_ptr], #192]               \r\n"
      "movi   v28.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #320]               \r\n"
      "movi   v29.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[a_ptr], #256]               \r\n"
      "movi   v30.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #384]               \r\n"
      "movi   v31.4s, #0x0                              \r\n"
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b)
      :
      : "x27", "x28", "v0", "v1", "v2", "v3",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31"
    );
  }

  if (kloop) {
    asm volatile (
      "1:                                             \r\n"
      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla   v8.4s, v2.4s, v0.s[0]                   \r\n"
      "fmla   v9.4s, v2.4s, v0.s[1]                   \r\n"
      "fmla   v10.4s, v2.4s, v0.s[2]                  \r\n"

      "ldr	  d6, [%[a_ptr], #32]                     \r\n"
      "fmla   v11.4s, v2.4s, v0.s[3]                  \r\n"
      "ldr    x28, [%[a_ptr], #40]                    \r\n"
      "fmla   v12.4s, v2.4s, v1.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"
      
      "prfm   pldl1keep, [%[a_ptr], #320]             \r\n"
      "mov    v4.d[1], xzr                            \r\n"
      "fmla   v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla   v15.4s, v2.4s, v1.s[3]                  \r\n"
      "fmla   v16.4s, v3.4s, v0.s[0]                  \r\n"

      "ldr    d2, [%[b_ptr], #48]                     \r\n"
      "mov    v6.d[1], x28                            \r\n"
      "fmla   v17.4s, v3.4s, v0.s[1]                  \r\n"
      "ldr    x27, [%[b_ptr], #56]                    \r\n"
      "fmla   v18.4s, v3.4s, v0.s[2]                  \r\n"
      "fmla   v19.4s, v3.4s, v0.s[3]                  \r\n"

      "ldr	  d7, [%[a_ptr], #48]                     \r\n"
      "fmla   v20.4s, v3.4s, v1.s[0]                  \r\n"
      "ldr    x28, [%[a_ptr], #56]                    \r\n"
      "fmla   v21.4s, v3.4s, v1.s[1]                  \r\n"
      "fmla   v22.4s, v3.4s, v1.s[2]                  \r\n"

      "prfm   pldl1keep, [%[b_ptr], #448]             \r\n"
      "mov    v2.d[1], x27                            \r\n"
      "fmla   v23.4s, v3.4s, v1.s[3]                  \r\n"
      "fmla   v24.4s, v4.4s, v0.s[0]                  \r\n"
      "fmla   v25.4s, v4.4s, v0.s[1]                  \r\n"

      "ldr    d3, [%[b_ptr], #64]                     \r\n"
      "fmla   v26.4s, v4.4s, v0.s[2]                  \r\n"
      "ldr    x27, [%[b_ptr], #72]                    \r\n"
      "fmla   v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla   v28.4s, v4.4s, v1.s[0]                  \r\n"

      "mov    v7.d[1], x28                            \r\n"
      "fmla   v29.4s, v4.4s, v1.s[1]                  \r\n"
      "fmla   v30.4s, v4.4s, v1.s[2]                  \r\n"
      "fmla   v31.4s, v4.4s, v1.s[3]                  \r\n"
      
      "ldr    d4, [%[b_ptr], #80]                     \r\n"
      "mov    v3.d[1], x27                            \r\n"
      "fmla   v8.4s, v2.4s, v6.s[0]                   \r\n"
      "fmla   v9.4s, v2.4s, v6.s[1]                   \r\n"
      "fmla   v10.4s, v2.4s, v6.s[2]                  \r\n"

      "ldr    d0, [%[a_ptr], #64]                     \r\n"
      "fmla   v11.4s, v2.4s, v6.s[3]                  \r\n"
      "ldr    x27, [%[a_ptr], #72]                    \r\n"
      "fmla   v12.4s, v2.4s, v7.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v7.s[1]                  \r\n"

      "prfm   pldl1keep, [%[b_ptr], #512]             \r\n"
      "mov    v4.d[1], xzr                            \r\n"
      "fmla   v14.4s, v2.4s, v7.s[2]                  \r\n"
      "fmla   v15.4s, v2.4s, v7.s[3]                  \r\n"
      "fmla   v16.4s, v3.4s, v6.s[0]                  \r\n"

      "ldr    d2, [%[b_ptr], #96]                     \r\n"
      "mov    v0.d[1], x27                            \r\n"
      "fmla   v17.4s, v3.4s, v6.s[1]                  \r\n"
      "ldr    x28, [%[b_ptr], #104]                   \r\n"
      "fmla   v18.4s, v3.4s, v6.s[2]                  \r\n"
      "fmla   v19.4s, v3.4s, v6.s[3]                  \r\n"

      "ldr	  d1, [%[a_ptr], #80]                     \r\n"
      "fmla   v20.4s, v3.4s, v7.s[0]                  \r\n"
      "ldr    x27, [%[a_ptr], #88]                    \r\n"
      "fmla   v21.4s, v3.4s, v7.s[1]                  \r\n"
      "fmla   v22.4s, v3.4s, v7.s[2]                  \r\n"

      "mov    v2.d[1], x28                            \r\n"
      "add    %[a_ptr], %[a_ptr], #64                 \r\n"
      "fmla   v23.4s, v3.4s, v7.s[3]                  \r\n"
      "fmla   v24.4s, v4.4s, v6.s[0]                  \r\n"
      "fmla   v25.4s, v4.4s, v6.s[1]                  \r\n"

      "ldr    d3, [%[b_ptr], #112]                    \r\n"
      "subs   %x[kloop], %x[kloop], #1                \r\n"
      "fmla   v26.4s, v4.4s, v6.s[2]                  \r\n"
      "ldr    x28, [%[b_ptr], #120]                   \r\n"
      "fmla   v27.4s, v4.4s, v6.s[3]                  \r\n"
      "fmla   v28.4s, v4.4s, v7.s[0]                  \r\n"
      
      "mov    v1.d[1], x27                            \r\n"
      "add    %[b_ptr], %[b_ptr], #96                 \r\n"
      "fmla   v29.4s, v4.4s, v7.s[1]                  \r\n"
      "fmla   v30.4s, v4.4s, v7.s[2]                  \r\n"
      "fmla   v31.4s, v4.4s, v7.s[3]                  \r\n"

      "bne    1b                                      \r\n"
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b),
        [kloop] "+r" (kloop)
      :
      : "x27", "x28", "v0", "v1", "v2", "v3", "v4", "v6", "v7",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31",
        "cc"
    );
  }

  // if constexpr (RBias && AddRes) {
  if constexpr (AddRes) {
    asm volatile (
      "cbnz   %x[kodd], 2f                            \r\n"

      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla 	v8.4s, v2.4s, v0.s[0]                   \r\n"
      "fmla   v9.4s, v2.4s, v0.s[1]                   \r\n"
      "fmla	  v10.4s, v2.4s, v0.s[2]                  \r\n"

      "ldr	  d6, [%[a_ptr], #32]                     \r\n"
      "fmla	  v11.4s, v2.4s, v0.s[3]                  \r\n"
      "ldr    x28, [%[a_ptr], #40]                    \r\n"
      "fmla 	v12.4s, v2.4s, v1.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr0]]                  \r\n"
      "mov    v4.d[1], xzr                            \r\n"
      "fmla	  v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla	  v15.4s, v2.4s, v1.s[3]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr1]]                  \r\n"
      "fmla	  v16.4s, v3.4s, v0.s[0]                  \r\n"

      "ldr	  d2, [%[b_ptr], #48]                     \r\n"
      "mov    v6.d[1], x28                            \r\n"
      "fmla	  v17.4s, v3.4s, v0.s[1]                  \r\n"
      "ldr    x27, [%[b_ptr], #56]                    \r\n"
      "fmla	  v18.4s, v3.4s, v0.s[2]                  \r\n"
      "fmla	  v19.4s, v3.4s, v0.s[3]                  \r\n"

      "ldr	  d7, [%[a_ptr], #48]                     \r\n"
      "fmla	  v20.4s, v3.4s, v1.s[0]                  \r\n"
      "ldr    x28, [%[a_ptr], #56]                    \r\n"
      "fmla	  v21.4s, v3.4s, v1.s[1]                  \r\n"
      "fmla	  v22.4s, v3.4s, v1.s[2]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr2]]                  \r\n"
      "mov    v2.d[1], x27                            \r\n"
      "fmla	  v23.4s, v3.4s, v1.s[3]                  \r\n"
      "fmla	  v24.4s, v4.4s, v0.s[0]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr3]]                  \r\n"
      "fmla	  v25.4s, v4.4s, v0.s[1]                  \r\n"
      
      "ldr	  d3, [%[b_ptr], #64]                     \r\n"
      "fmla	  v26.4s, v4.4s, v0.s[2]                  \r\n"
      "ldr    x27, [%[b_ptr], #72]                    \r\n"
      "fmla	  v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v1.s[0]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr4]]                  \r\n"
      "mov    v7.d[1], x28                            \r\n"
      "fmla	  v29.4s, v4.4s, v1.s[1]                  \r\n"
      "fmla	  v30.4s, v4.4s, v1.s[2]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr5]]                  \r\n"
      "fmla	  v31.4s, v4.4s, v1.s[3]                  \r\n"

      "ldr	  d4, [%[b_ptr], #80]                     \r\n"
      "mov    v3.d[1], x27                            \r\n"
      "fmla 	v8.4s , v2.4s, v6.s[0]                  \r\n"
      "fmla   v9.4s , v2.4s, v6.s[1]                  \r\n"
      "fmla	  v10.4s, v2.4s, v6.s[2]                  \r\n"

      "ldr    d5, [%[c_ptr0], #0]                     \r\n"
      "fmla	  v11.4s, v2.4s, v6.s[3]                  \r\n"
      "ldr    x27, [%[c_ptr0], #8]                    \r\n"
      "fmla 	v12.4s, v2.4s, v7.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v7.s[1]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr6]]                  \r\n"
      "mov    v4.d[1], xzr                            \r\n"
      "fmla	  v16.4s, v3.4s, v6.s[0]                  \r\n"
      "fmla	  v17.4s, v3.4s, v6.s[1]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr7]]                  \r\n"
      "fmla	  v18.4s, v3.4s, v6.s[2]                  \r\n"

      "ldr    d0, [%[c_ptr0], #16]                    \r\n"
      "mov    v5.d[1], x27                            \r\n"
      "fmla	  v19.4s, v3.4s, v6.s[3]                  \r\n"
      "ldr    x28, [%[c_ptr0], #24]                   \r\n"
      "fmla	  v20.4s, v3.4s, v7.s[0]                  \r\n"
      "fmla	  v21.4s, v3.4s, v7.s[1]                  \r\n"

      "ldr    d1, [%[c_ptr0], #32]                    \r\n"
      "fmla	  v24.4s, v4.4s, v6.s[0]                  \r\n"
      "fmla	  v25.4s, v4.4s, v6.s[1]                  \r\n"
      "fmla	  v26.4s, v4.4s, v6.s[2]                  \r\n"

      "fadd   v8.4s, v8.4s, v5.4s                     \r\n"
      "mov    v0.d[1], x28                            \r\n"
      "fmla	  v27.4s, v4.4s, v6.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v7.s[0]                  \r\n"
      "fmla	  v29.4s, v4.4s, v7.s[1]                  \r\n"

      "mov    v1.d[1], xzr                            \r\n"
      "fmla	  v14.4s, v2.4s, v7.s[2]                  \r\n"
      "fmla	  v22.4s, v3.4s, v7.s[2]                  \r\n"
      "fmla	  v30.4s, v4.4s, v7.s[2]                  \r\n"

      "fadd   v16.4s, v16.4s, v0.4s                   \r\n"
      "fmla	  v15.4s, v2.4s, v7.s[3]                  \r\n"
      "fmla	  v23.4s, v3.4s, v7.s[3]                  \r\n"
      "fmla	  v31.4s, v4.4s, v7.s[3]                  \r\n"

      "fadd   v24.4s, v24.4s, v1.4s                   \r\n"

      "b      3f                                      \r\n"

      "2:                                             \r\n"
      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla 	v8.4s , v2.4s, v0.s[0]                  \r\n"
      "fmla   v9.4s , v2.4s, v0.s[1]                  \r\n"
      "fmla	  v10.4s, v2.4s, v0.s[2]                  \r\n"

      "ldr    d5, [%[c_ptr0], #0]                     \r\n"
      "fmla	  v11.4s, v2.4s, v0.s[3]                  \r\n"
      "ldr    x28, [%[c_ptr0], #8]                    \r\n"
      "fmla 	v12.4s, v2.4s, v1.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr1]]                  \r\n"
      "mov    v4.d[1], xzr                            \r\n"
      "fmla	  v16.4s, v3.4s, v0.s[0]                  \r\n"
      "fmla	  v17.4s, v3.4s, v0.s[1]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr2]]                  \r\n"
      "fmla	  v18.4s, v3.4s, v0.s[2]                  \r\n"

      "ldr    d6, [%[c_ptr0], #16]                    \r\n"
      "mov    v5.d[1], x28                            \r\n"
      "fmla	  v19.4s, v3.4s, v0.s[3]                  \r\n"
      "ldr    x27, [%[c_ptr0], #24]                   \r\n"
      "fmla	  v20.4s, v3.4s, v1.s[0]                  \r\n"
      "fmla	  v21.4s, v3.4s, v1.s[1]                  \r\n"

      "ldr    d7, [%[c_ptr0], #32]                    \r\n"
      "fmla	  v24.4s, v4.4s, v0.s[0]                  \r\n"
      "fmla	  v25.4s, v4.4s, v0.s[1]                  \r\n"
      "fmla	  v26.4s, v4.4s, v0.s[2]                  \r\n"
      
      "fadd   v8.4s, v8.4s, v5.4s                     \r\n"
      "mov    v6.d[1], x27                            \r\n"
      "fmla	  v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v1.s[0]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr3]]                  \r\n"
      "fmla	  v29.4s, v4.4s, v1.s[1]                  \r\n"
      
      "prfm   pldl1keep, [%[c_ptr4]]                  \r\n"
      "mov    v7.d[1], xzr                            \r\n"
      "fmla	  v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla	  v22.4s, v3.4s, v1.s[2]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr5]]                  \r\n"
      "fmla	  v30.4s, v4.4s, v1.s[2]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr6]]                  \r\n"
      "fadd   v16.4s, v16.4s, v6.4s                   \r\n"
      "fmla	  v15.4s, v2.4s, v1.s[3]                  \r\n"
      "fmla	  v23.4s, v3.4s, v1.s[3]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr7]]                  \r\n"
      "fmla	  v31.4s, v4.4s, v1.s[3]                  \r\n"

      "fadd   v24.4s, v24.4s, v7.4s                   \r\n"

      "3:                                             \r\n"
      "ldr    q5, [%[c_ptr1], #0]                     \r\n"
      "ldr    q0, [%[c_ptr1], #16]                    \r\n"
      "ldr    d1, [%[c_ptr1], #32]                    \r\n"

      "ldr    q2, [%[c_ptr2], #0]                     \r\n"
      "ldr    q3, [%[c_ptr2], #16]                    \r\n"
      "ldr    d4, [%[c_ptr2], #32]                    \r\n"
      
      "fadd   v9.4s, v9.4s, v5.4s                     \r\n"
      "fadd   v17.4s, v17.4s, v0.4s                   \r\n"
      "fadd   v25.4s, v25.4s, v1.4s                   \r\n"

      "ldr    q5, [%[c_ptr3], #0]                     \r\n"
      "ldr    q0, [%[c_ptr3], #16]                    \r\n"
      "ldr    d1, [%[c_ptr3], #32]                    \r\n"
      
      "fadd   v10.4s, v10.4s, v2.4s                   \r\n"
      "fadd   v18.4s, v18.4s, v3.4s                   \r\n"
      "fadd   v26.4s, v26.4s, v4.4s                   \r\n"
      
      "ldr    q2, [%[c_ptr4], #0]                     \r\n"
      "ldr    q3, [%[c_ptr4], #16]                    \r\n"
      "ldr    d4, [%[c_ptr4], #32]                    \r\n"

      "fadd   v11.4s, v11.4s, v5.4s                   \r\n"
      "fadd   v19.4s, v19.4s, v0.4s                   \r\n"
      "fadd   v27.4s, v27.4s, v1.4s                   \r\n"
      
      "ldr    q5, [%[c_ptr5], #0]                     \r\n"
      "ldr    q0, [%[c_ptr5], #16]                    \r\n"
      "ldr    d1, [%[c_ptr5], #32]                    \r\n"

      "fadd   v12.4s, v12.4s, v2.4s                   \r\n"
      "fadd   v20.4s, v20.4s, v3.4s                   \r\n"
      "fadd   v28.4s, v28.4s, v4.4s                   \r\n"
      
      "ldr    q2, [%[c_ptr6], #0]                     \r\n"
      "ldr    q3, [%[c_ptr6], #16]                    \r\n"
      "ldr    d4, [%[c_ptr6], #32]                    \r\n"

      "fadd   v13.4s, v13.4s, v5.4s                   \r\n"
      "fadd   v21.4s, v21.4s, v0.4s                   \r\n"
      "fadd   v29.4s, v29.4s, v1.4s                   \r\n"

      "ldr    q5, [%[c_ptr7], #0]                     \r\n"
      "ldr    q0, [%[c_ptr7], #16]                    \r\n"
      "ldr    d1, [%[c_ptr7], #32]                    \r\n"

      "fadd   v14.4s, v14.4s, v2.4s                   \r\n"
      "fadd   v22.4s, v22.4s, v3.4s                   \r\n"
      "fadd   v30.4s, v30.4s, v4.4s                   \r\n"
      "fadd   v15.4s, v15.4s, v5.4s                   \r\n"
      "fadd   v23.4s, v23.4s, v0.4s                   \r\n"
      "fadd   v31.4s, v31.4s, v1.4s                   \r\n"   
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b)
        // [c_ptr] "+r" (c)
      : [kodd] "r" (kodd),
        // [ldc] "r" (ldc)
        [c_ptr0] "r" (c),
        [c_ptr1] "r" (c + ldc),
        [c_ptr2] "r" (c + ldc * 2),
        [c_ptr3] "r" (c + ldc * 3),
        [c_ptr4] "r" (c + ldc * 4),
        [c_ptr5] "r" (c + ldc * 5),
        [c_ptr6] "r" (c + ldc * 6),
        [c_ptr7] "r" (c + ldc * 7)
      : "x27", "x28", "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31",
        "cc"
    );
  } else {
    asm volatile (
      "cbnz   %x[kodd], 2f                            \r\n"

      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla 	v8.4s, v2.4s, v0.s[0]                   \r\n"
      "fmla   v9.4s, v2.4s, v0.s[1]                   \r\n"
      "fmla	  v10.4s, v2.4s, v0.s[2]                  \r\n"

      "ldr	  d6, [%[a_ptr], #32]                     \r\n"
      "fmla	  v11.4s, v2.4s, v0.s[3]                  \r\n"
      "ldr    x28, [%[a_ptr], #40]                    \r\n"
      "fmla 	v12.4s, v2.4s, v1.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"

      "prfm   pstl1keep, [%[c_ptr0]]                  \r\n"
      "mov    v4.d[1], xzr                            \r\n"
      "fmla	  v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla	  v15.4s, v2.4s, v1.s[3]                  \r\n"
      "fmla	  v16.4s, v3.4s, v0.s[0]                  \r\n"

      "ldr	  d2, [%[b_ptr], #48]                     \r\n"
      "mov    v6.d[1], x28                            \r\n"
      "fmla	  v17.4s, v3.4s, v0.s[1]                  \r\n"
      "ldr    x27, [%[b_ptr], #56]                    \r\n"
      "fmla	  v18.4s, v3.4s, v0.s[2]                  \r\n"
      "fmla	  v19.4s, v3.4s, v0.s[3]                  \r\n"

      "ldr	  d7, [%[a_ptr], #48]                     \r\n"
      "fmla	  v20.4s, v3.4s, v1.s[0]                  \r\n"
      "ldr    x28, [%[a_ptr], #56]                    \r\n"
      "fmla	  v21.4s, v3.4s, v1.s[1]                  \r\n"
      "fmla	  v22.4s, v3.4s, v1.s[2]                  \r\n"

      "prfm   pstl1keep, [%[c_ptr1]]                  \r\n"
      "mov    v2.d[1], x27                            \r\n"
      "fmla	  v23.4s, v3.4s, v1.s[3]                  \r\n"
      "fmla	  v24.4s, v4.4s, v0.s[0]                  \r\n"
      "fmla	  v25.4s, v4.4s, v0.s[1]                  \r\n"
      
      "ldr	  d3, [%[b_ptr], #64]                     \r\n"
      "fmla	  v26.4s, v4.4s, v0.s[2]                  \r\n"
      "ldr    x27, [%[b_ptr], #72]                    \r\n"
      "fmla	  v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v1.s[0]                  \r\n"

      "prfm   pstl1keep, [%[c_ptr2]]                  \r\n"
      "mov    v7.d[1], x28                            \r\n"
      "fmla	  v29.4s, v4.4s, v1.s[1]                  \r\n"
      "fmla	  v30.4s, v4.4s, v1.s[2]                  \r\n"
      "fmla	  v31.4s, v4.4s, v1.s[3]                  \r\n"

      "ldr	  d4, [%[b_ptr], #80]                     \r\n"
      "mov    v3.d[1], x27                            \r\n"
      "fmla 	v8.4s , v2.4s, v6.s[0]                  \r\n"
      "fmla   v9.4s , v2.4s, v6.s[1]                  \r\n"
      "fmla	  v10.4s, v2.4s, v6.s[2]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr3]]                  \r\n"
      "fmla	  v11.4s, v2.4s, v6.s[3]                  \r\n"
      "fmla 	v12.4s, v2.4s, v7.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr4]]                  \r\n"
      "fmla   v13.4s, v2.4s, v7.s[1]                  \r\n"
      "fmla	  v16.4s, v3.4s, v6.s[0]                  \r\n"
      "fmla	  v17.4s, v3.4s, v6.s[1]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr5]]                  \r\n"
      "fmla	  v18.4s, v3.4s, v6.s[2]                  \r\n"
      "fmla	  v19.4s, v3.4s, v6.s[3]                  \r\n"
      "fmla	  v20.4s, v3.4s, v7.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr6]]                  \r\n"
      "fmla	  v21.4s, v3.4s, v7.s[1]                  \r\n"
      "fmla	  v24.4s, v4.4s, v6.s[0]                  \r\n"
      "fmla	  v25.4s, v4.4s, v6.s[1]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr7]]                  \r\n"
      "fmla	  v26.4s, v4.4s, v6.s[2]                  \r\n"
      "fmla	  v27.4s, v4.4s, v6.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v7.s[0]                  \r\n"
      "fmla	  v29.4s, v4.4s, v7.s[1]                  \r\n"
      "fmla	  v14.4s, v2.4s, v7.s[2]                  \r\n"
      "fmla	  v22.4s, v3.4s, v7.s[2]                  \r\n"
      "fmla	  v30.4s, v4.4s, v7.s[2]                  \r\n"
      "fmla	  v15.4s, v2.4s, v7.s[3]                  \r\n"
      "fmla	  v23.4s, v3.4s, v7.s[3]                  \r\n"
      "fmla	  v31.4s, v4.4s, v7.s[3]                  \r\n"

      "b      3f                                      \r\n"

      "2:                                             \r\n"
      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla 	v8.4s , v2.4s, v0.s[0]                  \r\n"
      "fmla   v9.4s , v2.4s, v0.s[1]                  \r\n"
      "fmla	  v10.4s, v2.4s, v0.s[2]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr0]]                  \r\n"
      "fmla	  v11.4s, v2.4s, v0.s[3]                  \r\n"
      "fmla 	v12.4s, v2.4s, v1.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr1]]                  \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"
      "fmla	  v16.4s, v3.4s, v0.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr2]]                  \r\n"
      "fmla	  v17.4s, v3.4s, v0.s[1]                  \r\n"
      "fmla	  v18.4s, v3.4s, v0.s[2]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr3]]                  \r\n"
      "fmla	  v19.4s, v3.4s, v0.s[3]                  \r\n"
      "fmla	  v20.4s, v3.4s, v1.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr4]]                  \r\n"
      "fmla	  v21.4s, v3.4s, v1.s[1]                  \r\n"
      "fmla	  v24.4s, v4.4s, v0.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr5]]                  \r\n"
      "fmla	  v25.4s, v4.4s, v0.s[1]                  \r\n"
      "fmla	  v26.4s, v4.4s, v0.s[2]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr6]]                  \r\n"
      "fmla	  v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v1.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr7]]                  \r\n"
      "fmla	  v29.4s, v4.4s, v1.s[1]                  \r\n"
      "fmla	  v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla	  v22.4s, v3.4s, v1.s[2]                  \r\n"
      "fmla	  v30.4s, v4.4s, v1.s[2]                  \r\n"
      "fmla	  v15.4s, v2.4s, v1.s[3]                  \r\n"
      "fmla	  v23.4s, v3.4s, v1.s[3]                  \r\n"
      "fmla	  v31.4s, v4.4s, v1.s[3]                  \r\n"

      "3:                                             \r\n"
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b)
        // [c_ptr] "+r" (c)
      : [kodd] "r" (kodd),
        // [ldc] "r" (ldc)
        [c_ptr0] "r" (c),
        [c_ptr1] "r" (c + ldc),
        [c_ptr2] "r" (c + ldc * 2),
        [c_ptr3] "r" (c + ldc * 3),
        [c_ptr4] "r" (c + ldc * 4),
        [c_ptr5] "r" (c + ldc * 5),
        [c_ptr6] "r" (c + ldc * 6),
        [c_ptr7] "r" (c + ldc * 7)
      : "x27", "x28", "v0", "v1", "v2", "v3", "v4", "v6", "v7",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31",
        "cc"
    );
  }

  if constexpr (ReLU) {
    if constexpr (AddRes) {
      asm volatile (
        "movi   v5.4s, #0                               \r\n"
        :
        :
        : "v5"
      );
    }

    asm volatile (
      "fmax   v8.4s, v8.4s, v5.4s                     \r\n"
      "fmax   v16.4s, v16.4s, v5.4s                   \r\n"
      "fmax   v24.4s, v24.4s, v5.4s                   \r\n"
      "fmax   v9.4s, v9.4s, v5.4s                     \r\n"
      "fmax   v17.4s, v17.4s, v5.4s                   \r\n"
      "fmax   v25.4s, v25.4s, v5.4s                   \r\n"
      "fmax   v10.4s, v10.4s, v5.4s                   \r\n"
      "fmax   v18.4s, v18.4s, v5.4s                   \r\n"
      "fmax   v26.4s, v26.4s, v5.4s                   \r\n"
      "fmax   v11.4s, v11.4s, v5.4s                   \r\n"
      "fmax   v19.4s, v19.4s, v5.4s                   \r\n"
      "fmax   v27.4s, v27.4s, v5.4s                   \r\n"
      "fmax   v12.4s, v12.4s, v5.4s                   \r\n"
      "fmax   v20.4s, v20.4s, v5.4s                   \r\n"
      "fmax   v28.4s, v28.4s, v5.4s                   \r\n"
      "fmax   v13.4s, v13.4s, v5.4s                   \r\n"
      "fmax   v21.4s, v21.4s, v5.4s                   \r\n"
      "fmax   v29.4s, v29.4s, v5.4s                   \r\n"
      "fmax   v14.4s, v14.4s, v5.4s                   \r\n"
      "fmax   v22.4s, v22.4s, v5.4s                   \r\n"
      "fmax   v30.4s, v30.4s, v5.4s                   \r\n"
      "fmax   v15.4s, v15.4s, v5.4s                   \r\n"
      "fmax   v23.4s, v23.4s, v5.4s                   \r\n"
      "fmax   v31.4s, v31.4s, v5.4s                   \r\n"
      : 
      : 
      : "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31"
    );      
  }

  asm volatile (
    "str	  q8, [%[c_ptr0], #0]                     \r\n"
    "str	  q16, [%[c_ptr0], #16]                   \r\n"
    "str	  d24, [%[c_ptr0], #32]                   \r\n"
    "str	  q9, [%[c_ptr1], #0]                     \r\n"
    "str	  q17, [%[c_ptr1], #16]                   \r\n"
    "str	  d25, [%[c_ptr1], #32]                   \r\n"
    "str	  q10, [%[c_ptr2], #0]                    \r\n"
    "str	  q18, [%[c_ptr2], #16]                   \r\n"
    "str	  d26, [%[c_ptr2], #32]                   \r\n"
    "str	  q11, [%[c_ptr3], #0]                    \r\n"
    "str	  q19, [%[c_ptr3], #16]                   \r\n"
    "str	  d27, [%[c_ptr3], #32]                   \r\n"
    "str	  q12, [%[c_ptr4], #0]                    \r\n"
    "str	  q20, [%[c_ptr4], #16]                   \r\n"
    "str	  d28, [%[c_ptr4], #32]                   \r\n"
    "str	  q13, [%[c_ptr5], #0]                    \r\n"
    "str	  q21, [%[c_ptr5], #16]                   \r\n"
    "str	  d29, [%[c_ptr5], #32]                   \r\n"
    "str	  q14, [%[c_ptr6], #0]                    \r\n"
    "str	  q22, [%[c_ptr6], #16]                   \r\n"
    "str	  d30, [%[c_ptr6], #32]                   \r\n"
    "str	  q15, [%[c_ptr7], #0]                    \r\n"
    "str	  q23, [%[c_ptr7], #16]                   \r\n"
    "str	  d31, [%[c_ptr7], #32]                   \r\n"
    : 
    : [c_ptr0] "r" (c),
      [c_ptr1] "r" (c + ldc),
      [c_ptr2] "r" (c + ldc * 2),
      [c_ptr3] "r" (c + ldc * 3),
      [c_ptr4] "r" (c + ldc * 4),
      [c_ptr5] "r" (c + ldc * 5),
      [c_ptr6] "r" (c + ldc * 6),
      [c_ptr7] "r" (c + ldc * 7)
    : "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", 
      "memory"
  );

#else

  const int m = 8;
  const int n = 12;
  for(int i=0; i<m; i++) {
    for(int j=0; j<n; j++) {
      float val=0.0f;
      for(int l=0; l<k; l++) {
        Lhs aval, bval;
        aval = a[l*lda+i];
        // bval = b[ldb*l+j];
        bval = b[l*ldb+j];    // ReB & PackB

        // val+=a[lda*i+l]*b[ldb*l+j];
        val += aval * bval;
      }
      if (RScale && (RScaleBlend || Blend)) {
        val*=rscale[i];
      }
      if (Load) {
        if (FstIter && RScaleBlend) {
            val+=c[ldc*i+j]*rscale_blend[i];
        } else {
            val+=c[ldc*i+j];
        }
      }
      if (RScale && !(RScaleBlend || Blend)) {
          val*=rscale[i];
      }

      if(RBias) {
        val+=rbias[i];
      }
      if(ReLU) {
        val=std::max(0.0f, val);
      }
      c[ldc*i+j]=val;
    }
  }
#endif
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool Load,
    bool Itm2Res, bool Blend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernelv2<Lhs, Rhs, Res, Itm, float, 8, 9, CortexA53, true, true, false, Load, Itm2Res, Blend, false, false, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {

  constexpr bool RScale = false;
  constexpr bool RScaleBlend = false;
#ifndef C_MODEL
  // k MUST be not 0.
  int kodd = k & 1;
  int kloop = ((k + 1) >> 1) - 1;

  if constexpr (ReLU) {
    asm volatile (
      "movi   v5.4s, #0                               \r\n"
      :
      :
      : "v5"
    );
  }

  constexpr bool AddRes = Load && !(FstIter && RScaleBlend);

  if constexpr (RBias) {
    asm volatile (
      "ldr    q6, [%[bias_ptr]]                       \r\n"
      "ldr    q7, [%[bias_ptr], #16]                  \r\n"
      "ldr    q0, [%[a_ptr]]                          \r\n"
      "ldr    q2, [%[b_ptr]]                          \r\n"
      "ldr    q1, [%[a_ptr], #16]                     \r\n"
      "dup    v8.4s, v6.s[0]                          \r\n"
      "ldr    d3, [%[b_ptr], #16]                     \r\n"
      "dup    v9.4s, v6.s[1]                          \r\n"
      "ldr    x28, [%[b_ptr], #24]                    \r\n"
      "dup    v10.4s, v6.s[2]                         \r\n"
      "dup    v11.4s, v6.s[3]                         \r\n"
      "dup    v12.4s, v7.s[0]                         \r\n"
      "dup    v13.4s, v7.s[1]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #64]              \r\n"
      "dup    v14.4s, v7.s[2]                         \r\n"
      "dup    v15.4s, v7.s[3]                         \r\n"
      "prfm   pldl1keep, [%[a_ptr], #64]              \r\n"
      "dup    v16.4s, v6.s[0]                         \r\n"
      "dup    v17.4s, v6.s[1]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #128]             \r\n"
      "dup    v18.4s, v6.s[2]                         \r\n"
      "dup    v19.4s, v6.s[3]                         \r\n"
      "prfm   pldl1keep, [%[a_ptr], #128]             \r\n"
      "dup    v20.4s, v7.s[0]                         \r\n"
      "dup    v21.4s, v7.s[1]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #192]             \r\n"
      "dup    v22.4s, v7.s[2]                         \r\n"
      "dup    v23.4s, v7.s[3]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #256]             \r\n"
      "dup    v24.4s, v6.s[0]                         \r\n"
      "dup    v25.4s, v6.s[1]                         \r\n"
      "prfm   pldl1keep, [%[a_ptr], #192]             \r\n"
      "dup    v26.4s, v6.s[2]                         \r\n"
      "dup    v27.4s, v6.s[3]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #320]             \r\n"
      "dup    v28.4s, v7.s[0]                         \r\n"
      "dup    v29.4s, v7.s[1]                         \r\n"
      "prfm   pldl1keep, [%[a_ptr], #256]             \r\n"
      "dup    v30.4s, v7.s[2]                         \r\n"
      "dup    v31.4s, v7.s[3]                         \r\n"
      "prfm   pldl1keep, [%[b_ptr], #384]             \r\n"
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b)
      : [bias_ptr] "r" (rbias)
      : "v0", "v1", "v2", "v3", "v6", "v7",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31"
    );
  } else {
    asm volatile (
      "movi   v8.4s, #0x0                               \r\n"
      "ldr    d0, [%[a_ptr]]                            \r\n"
      "movi   v9.4s, #0x0                               \r\n"
      "ldr    x27, [%[a_ptr], #8]                       \r\n"
      "movi   v10.4s, #0x0                              \r\n"
      "ldr    d2, [%[b_ptr]]                            \r\n"
      "movi   v11.4s, #0x0                              \r\n"
      "ldr    x28, [%[b_ptr], #8]                       \r\n"
      "movi   v12.4s, #0x0                              \r\n"
      "ldr    d1, [%[a_ptr], #16]                       \r\n"
      "movi   v13.4s, #0x0                              \r\n"
      "movi   v14.4s, #0x0                              \r\n"
      "movi   v15.4s, #0x0                              \r\n"
      "mov    v0.d[1], x27                              \r\n"
      "movi   v16.4s, #0x0                              \r\n"
      "ldr    x27, [%[a_ptr], #24]                      \r\n"
      "movi   v17.4s, #0x0                              \r\n"
      "ldr    d3, [%[b_ptr], #16]                       \r\n"
      "movi   v18.4s, #0x0                              \r\n"
      "mov    v2.d[1], x28                              \r\n"
      "movi   v19.4s, #0x0                              \r\n"
      "ldr    x28, [%[b_ptr], #24]                      \r\n"
      "movi   v20.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #64]                \r\n"
      "movi   v21.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[a_ptr], #64]                \r\n"
      "movi   v22.4s, #0x0                              \r\n"
      "mov    v1.d[1], x27                              \r\n"
      "movi   v23.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #128]               \r\n"
      "movi   v24.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[a_ptr], #128]               \r\n"
      "movi   v25.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #192]               \r\n"
      "movi   v26.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #256]               \r\n"
      "movi   v27.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[a_ptr], #192]               \r\n"
      "movi   v28.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #320]               \r\n"
      "movi   v29.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[a_ptr], #256]               \r\n"
      "movi   v30.4s, #0x0                              \r\n"
      "prfm   pldl1keep, [%[b_ptr], #384]               \r\n"
      "movi   v31.4s, #0x0                              \r\n"
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b)
      :
      : "x27", "x28", "v0", "v1", "v2", "v3",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31"
    );
  }

  if (kloop) {
    asm volatile (
      "1:                                             \r\n"
      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla   v8.4s, v2.4s, v0.s[0]                   \r\n"
      "fmla   v9.4s, v2.4s, v0.s[1]                   \r\n"
      "fmla   v10.4s, v2.4s, v0.s[2]                  \r\n"

      "ldr	  d6, [%[a_ptr], #32]                     \r\n"
      "fmla   v11.4s, v2.4s, v0.s[3]                  \r\n"
      "ldr    x28, [%[a_ptr], #40]                    \r\n"
      "fmla   v12.4s, v2.4s, v1.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"
      
      "prfm   pldl1keep, [%[a_ptr], #320]             \r\n"
      "mov    v4.d[1], xzr                            \r\n"
      "fmla   v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla   v15.4s, v2.4s, v1.s[3]                  \r\n"
      "fmla   v16.4s, v3.4s, v0.s[0]                  \r\n"

      "ldr    d2, [%[b_ptr], #48]                     \r\n"
      "mov    v6.d[1], x28                            \r\n"
      "fmla   v17.4s, v3.4s, v0.s[1]                  \r\n"
      "ldr    x27, [%[b_ptr], #56]                    \r\n"
      "fmla   v18.4s, v3.4s, v0.s[2]                  \r\n"
      "fmla   v19.4s, v3.4s, v0.s[3]                  \r\n"

      "ldr	  d7, [%[a_ptr], #48]                     \r\n"
      "fmla   v20.4s, v3.4s, v1.s[0]                  \r\n"
      "ldr    x28, [%[a_ptr], #56]                    \r\n"
      "fmla   v21.4s, v3.4s, v1.s[1]                  \r\n"
      "fmla   v22.4s, v3.4s, v1.s[2]                  \r\n"

      "prfm   pldl1keep, [%[b_ptr], #448]             \r\n"
      "mov    v2.d[1], x27                            \r\n"
      "fmla   v23.4s, v3.4s, v1.s[3]                  \r\n"
      "fmla   v24.4s, v4.4s, v0.s[0]                  \r\n"
      "fmla   v25.4s, v4.4s, v0.s[1]                  \r\n"

      "ldr    d3, [%[b_ptr], #64]                     \r\n"
      "fmla   v26.4s, v4.4s, v0.s[2]                  \r\n"
      "ldr    x27, [%[b_ptr], #72]                    \r\n"
      "fmla   v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla   v28.4s, v4.4s, v1.s[0]                  \r\n"

      "mov    v7.d[1], x28                            \r\n"
      "fmla   v29.4s, v4.4s, v1.s[1]                  \r\n"
      "fmla   v30.4s, v4.4s, v1.s[2]                  \r\n"
      "fmla   v31.4s, v4.4s, v1.s[3]                  \r\n"
      
      "ldr    d4, [%[b_ptr], #80]                     \r\n"
      "mov    v3.d[1], x27                            \r\n"
      "fmla   v8.4s, v2.4s, v6.s[0]                   \r\n"
      "fmla   v9.4s, v2.4s, v6.s[1]                   \r\n"
      "fmla   v10.4s, v2.4s, v6.s[2]                  \r\n"

      "ldr    d0, [%[a_ptr], #64]                     \r\n"
      "fmla   v11.4s, v2.4s, v6.s[3]                  \r\n"
      "ldr    x27, [%[a_ptr], #72]                    \r\n"
      "fmla   v12.4s, v2.4s, v7.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v7.s[1]                  \r\n"

      "prfm   pldl1keep, [%[b_ptr], #512]             \r\n"
      "mov    v4.d[1], xzr                            \r\n"
      "fmla   v14.4s, v2.4s, v7.s[2]                  \r\n"
      "fmla   v15.4s, v2.4s, v7.s[3]                  \r\n"
      "fmla   v16.4s, v3.4s, v6.s[0]                  \r\n"

      "ldr    d2, [%[b_ptr], #96]                     \r\n"
      "mov    v0.d[1], x27                            \r\n"
      "fmla   v17.4s, v3.4s, v6.s[1]                  \r\n"
      "ldr    x28, [%[b_ptr], #104]                   \r\n"
      "fmla   v18.4s, v3.4s, v6.s[2]                  \r\n"
      "fmla   v19.4s, v3.4s, v6.s[3]                  \r\n"

      "ldr	  d1, [%[a_ptr], #80]                     \r\n"
      "fmla   v20.4s, v3.4s, v7.s[0]                  \r\n"
      "ldr    x27, [%[a_ptr], #88]                    \r\n"
      "fmla   v21.4s, v3.4s, v7.s[1]                  \r\n"
      "fmla   v22.4s, v3.4s, v7.s[2]                  \r\n"

      "mov    v2.d[1], x28                            \r\n"
      "add    %[a_ptr], %[a_ptr], #64                 \r\n"
      "fmla   v23.4s, v3.4s, v7.s[3]                  \r\n"
      "fmla   v24.4s, v4.4s, v6.s[0]                  \r\n"
      "fmla   v25.4s, v4.4s, v6.s[1]                  \r\n"

      "ldr    d3, [%[b_ptr], #112]                    \r\n"
      "subs   %x[kloop], %x[kloop], #1                \r\n"
      "fmla   v26.4s, v4.4s, v6.s[2]                  \r\n"
      "ldr    x28, [%[b_ptr], #120]                   \r\n"
      "fmla   v27.4s, v4.4s, v6.s[3]                  \r\n"
      "fmla   v28.4s, v4.4s, v7.s[0]                  \r\n"
      
      "mov    v1.d[1], x27                            \r\n"
      "add    %[b_ptr], %[b_ptr], #96                 \r\n"
      "fmla   v29.4s, v4.4s, v7.s[1]                  \r\n"
      "fmla   v30.4s, v4.4s, v7.s[2]                  \r\n"
      "fmla   v31.4s, v4.4s, v7.s[3]                  \r\n"

      "bne    1b                                      \r\n"
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b),
        [kloop] "+r" (kloop)
      :
      : "x27", "x28", "v0", "v1", "v2", "v3", "v4", "v6", "v7",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31",
        "cc"
    );
  }

  // if constexpr (RBias && AddRes) {
  if constexpr (AddRes) {
    asm volatile (
      "cbnz   %x[kodd], 2f                            \r\n"

      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla 	v8.4s, v2.4s, v0.s[0]                   \r\n"
      "fmla   v9.4s, v2.4s, v0.s[1]                   \r\n"
      "fmla	  v10.4s, v2.4s, v0.s[2]                  \r\n"

      "ldr	  d6, [%[a_ptr], #32]                     \r\n"
      "fmla	  v11.4s, v2.4s, v0.s[3]                  \r\n"
      "ldr    x28, [%[a_ptr], #40]                    \r\n"
      "fmla 	v12.4s, v2.4s, v1.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr0]]                  \r\n"
      "mov    v4.d[1], xzr                            \r\n"
      "fmla	  v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla	  v15.4s, v2.4s, v1.s[3]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr1]]                  \r\n"
      "fmla	  v16.4s, v3.4s, v0.s[0]                  \r\n"

      "ldr	  d2, [%[b_ptr], #48]                     \r\n"
      "mov    v6.d[1], x28                            \r\n"
      "fmla	  v17.4s, v3.4s, v0.s[1]                  \r\n"
      "ldr    x27, [%[b_ptr], #56]                    \r\n"
      "fmla	  v18.4s, v3.4s, v0.s[2]                  \r\n"
      "fmla	  v19.4s, v3.4s, v0.s[3]                  \r\n"

      "ldr	  d7, [%[a_ptr], #48]                     \r\n"
      "fmla	  v20.4s, v3.4s, v1.s[0]                  \r\n"
      "ldr    x28, [%[a_ptr], #56]                    \r\n"
      "fmla	  v21.4s, v3.4s, v1.s[1]                  \r\n"
      "fmla	  v22.4s, v3.4s, v1.s[2]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr2]]                  \r\n"
      "mov    v2.d[1], x27                            \r\n"
      "fmla	  v23.4s, v3.4s, v1.s[3]                  \r\n"
      "fmla	  v24.4s, v4.4s, v0.s[0]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr3]]                  \r\n"
      "fmla	  v25.4s, v4.4s, v0.s[1]                  \r\n"
      
      "ldr	  d3, [%[b_ptr], #64]                     \r\n"
      "fmla	  v26.4s, v4.4s, v0.s[2]                  \r\n"
      "ldr    x27, [%[b_ptr], #72]                    \r\n"
      "fmla	  v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v1.s[0]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr4]]                  \r\n"
      "mov    v7.d[1], x28                            \r\n"
      "fmla	  v29.4s, v4.4s, v1.s[1]                  \r\n"
      "fmla	  v30.4s, v4.4s, v1.s[2]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr5]]                  \r\n"
      "fmla	  v31.4s, v4.4s, v1.s[3]                  \r\n"

      "ldr	  d4, [%[b_ptr], #80]                     \r\n"
      "mov    v3.d[1], x27                            \r\n"
      "fmla 	v8.4s , v2.4s, v6.s[0]                  \r\n"
      "fmla   v9.4s , v2.4s, v6.s[1]                  \r\n"
      "fmla	  v10.4s, v2.4s, v6.s[2]                  \r\n"

      "ldr    d5, [%[c_ptr0], #0]                     \r\n"
      "fmla	  v11.4s, v2.4s, v6.s[3]                  \r\n"
      "ldr    x27, [%[c_ptr0], #8]                    \r\n"
      "fmla 	v12.4s, v2.4s, v7.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v7.s[1]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr6]]                  \r\n"
      "mov    v4.d[1], xzr                            \r\n"
      "fmla	  v16.4s, v3.4s, v6.s[0]                  \r\n"
      "fmla	  v17.4s, v3.4s, v6.s[1]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr7]]                  \r\n"
      "fmla	  v18.4s, v3.4s, v6.s[2]                  \r\n"

      "ldr    d0, [%[c_ptr0], #16]                    \r\n"
      "mov    v5.d[1], x27                            \r\n"
      "fmla	  v19.4s, v3.4s, v6.s[3]                  \r\n"
      "ldr    x28, [%[c_ptr0], #24]                   \r\n"
      "fmla	  v20.4s, v3.4s, v7.s[0]                  \r\n"
      "fmla	  v21.4s, v3.4s, v7.s[1]                  \r\n"

      "ldr    d1, [%[c_ptr0], #32]                    \r\n"
      "fmla	  v24.4s, v4.4s, v6.s[0]                  \r\n"
      "fmla	  v25.4s, v4.4s, v6.s[1]                  \r\n"
      "fmla	  v26.4s, v4.4s, v6.s[2]                  \r\n"

      "fadd   v8.4s, v8.4s, v5.4s                     \r\n"
      "mov    v0.d[1], x28                            \r\n"
      "fmla	  v27.4s, v4.4s, v6.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v7.s[0]                  \r\n"
      "fmla	  v29.4s, v4.4s, v7.s[1]                  \r\n"

      "mov    v1.d[1], xzr                            \r\n"
      "fmla	  v14.4s, v2.4s, v7.s[2]                  \r\n"
      "fmla	  v22.4s, v3.4s, v7.s[2]                  \r\n"
      "fmla	  v30.4s, v4.4s, v7.s[2]                  \r\n"

      "fadd   v16.4s, v16.4s, v0.4s                   \r\n"
      "fmla	  v15.4s, v2.4s, v7.s[3]                  \r\n"
      "fmla	  v23.4s, v3.4s, v7.s[3]                  \r\n"
      "fmla	  v31.4s, v4.4s, v7.s[3]                  \r\n"

      "fadd   v24.4s, v24.4s, v1.4s                   \r\n"

      "b      3f                                      \r\n"

      "2:                                             \r\n"
      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla 	v8.4s , v2.4s, v0.s[0]                  \r\n"
      "fmla   v9.4s , v2.4s, v0.s[1]                  \r\n"
      "fmla	  v10.4s, v2.4s, v0.s[2]                  \r\n"

      "ldr    d5, [%[c_ptr0], #0]                     \r\n"
      "fmla	  v11.4s, v2.4s, v0.s[3]                  \r\n"
      "ldr    x28, [%[c_ptr0], #8]                    \r\n"
      "fmla 	v12.4s, v2.4s, v1.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr1]]                  \r\n"
      "mov    v4.d[1], xzr                            \r\n"
      "fmla	  v16.4s, v3.4s, v0.s[0]                  \r\n"
      "fmla	  v17.4s, v3.4s, v0.s[1]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr2]]                  \r\n"
      "fmla	  v18.4s, v3.4s, v0.s[2]                  \r\n"

      "ldr    d6, [%[c_ptr0], #16]                    \r\n"
      "mov    v5.d[1], x28                            \r\n"
      "fmla	  v19.4s, v3.4s, v0.s[3]                  \r\n"
      "ldr    x27, [%[c_ptr0], #24]                   \r\n"
      "fmla	  v20.4s, v3.4s, v1.s[0]                  \r\n"
      "fmla	  v21.4s, v3.4s, v1.s[1]                  \r\n"

      "ldr    d7, [%[c_ptr0], #32]                    \r\n"
      "fmla	  v24.4s, v4.4s, v0.s[0]                  \r\n"
      "fmla	  v25.4s, v4.4s, v0.s[1]                  \r\n"
      "fmla	  v26.4s, v4.4s, v0.s[2]                  \r\n"
      
      "fadd   v8.4s, v8.4s, v5.4s                     \r\n"
      "mov    v6.d[1], x27                            \r\n"
      "fmla	  v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v1.s[0]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr3]]                  \r\n"
      "fmla	  v29.4s, v4.4s, v1.s[1]                  \r\n"
      
      "prfm   pldl1keep, [%[c_ptr4]]                  \r\n"
      "mov    v7.d[1], xzr                            \r\n"
      "fmla	  v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla	  v22.4s, v3.4s, v1.s[2]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr5]]                  \r\n"
      "fmla	  v30.4s, v4.4s, v1.s[2]                  \r\n"

      "prfm   pldl1keep, [%[c_ptr6]]                  \r\n"
      "fadd   v16.4s, v16.4s, v6.4s                   \r\n"
      "fmla	  v15.4s, v2.4s, v1.s[3]                  \r\n"
      "fmla	  v23.4s, v3.4s, v1.s[3]                  \r\n"
      "prfm   pldl1keep, [%[c_ptr7]]                  \r\n"
      "fmla	  v31.4s, v4.4s, v1.s[3]                  \r\n"

      "fadd   v24.4s, v24.4s, v7.4s                   \r\n"

      "3:                                             \r\n"
      "ldr    q5, [%[c_ptr1], #0]                     \r\n"
      "ldr    q0, [%[c_ptr1], #16]                    \r\n"
      "ldr    d1, [%[c_ptr1], #32]                    \r\n"

      "ldr    q2, [%[c_ptr2], #0]                     \r\n"
      "ldr    q3, [%[c_ptr2], #16]                    \r\n"
      "ldr    d4, [%[c_ptr2], #32]                    \r\n"
      
      "fadd   v9.4s, v9.4s, v5.4s                     \r\n"
      "fadd   v17.4s, v17.4s, v0.4s                   \r\n"
      "fadd   v25.4s, v25.4s, v1.4s                   \r\n"

      "ldr    q5, [%[c_ptr3], #0]                     \r\n"
      "ldr    q0, [%[c_ptr3], #16]                    \r\n"
      "ldr    d1, [%[c_ptr3], #32]                    \r\n"
      
      "fadd   v10.4s, v10.4s, v2.4s                   \r\n"
      "fadd   v18.4s, v18.4s, v3.4s                   \r\n"
      "fadd   v26.4s, v26.4s, v4.4s                   \r\n"
      
      "ldr    q2, [%[c_ptr4], #0]                     \r\n"
      "ldr    q3, [%[c_ptr4], #16]                    \r\n"
      "ldr    d4, [%[c_ptr4], #32]                    \r\n"

      "fadd   v11.4s, v11.4s, v5.4s                   \r\n"
      "fadd   v19.4s, v19.4s, v0.4s                   \r\n"
      "fadd   v27.4s, v27.4s, v1.4s                   \r\n"
      
      "ldr    q5, [%[c_ptr5], #0]                     \r\n"
      "ldr    q0, [%[c_ptr5], #16]                    \r\n"
      "ldr    d1, [%[c_ptr5], #32]                    \r\n"

      "fadd   v12.4s, v12.4s, v2.4s                   \r\n"
      "fadd   v20.4s, v20.4s, v3.4s                   \r\n"
      "fadd   v28.4s, v28.4s, v4.4s                   \r\n"
      
      "ldr    q2, [%[c_ptr6], #0]                     \r\n"
      "ldr    q3, [%[c_ptr6], #16]                    \r\n"
      "ldr    d4, [%[c_ptr6], #32]                    \r\n"

      "fadd   v13.4s, v13.4s, v5.4s                   \r\n"
      "fadd   v21.4s, v21.4s, v0.4s                   \r\n"
      "fadd   v29.4s, v29.4s, v1.4s                   \r\n"

      "ldr    q5, [%[c_ptr7], #0]                     \r\n"
      "ldr    q0, [%[c_ptr7], #16]                    \r\n"
      "ldr    d1, [%[c_ptr7], #32]                    \r\n"

      "fadd   v14.4s, v14.4s, v2.4s                   \r\n"
      "fadd   v22.4s, v22.4s, v3.4s                   \r\n"
      "fadd   v30.4s, v30.4s, v4.4s                   \r\n"
      "fadd   v15.4s, v15.4s, v5.4s                   \r\n"
      "fadd   v23.4s, v23.4s, v0.4s                   \r\n"
      "fadd   v31.4s, v31.4s, v1.4s                   \r\n"   
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b)
        // [c_ptr] "+r" (c)
      : [kodd] "r" (kodd),
        // [ldc] "r" (ldc)
        [c_ptr0] "r" (c),
        [c_ptr1] "r" (c + ldc),
        [c_ptr2] "r" (c + ldc * 2),
        [c_ptr3] "r" (c + ldc * 3),
        [c_ptr4] "r" (c + ldc * 4),
        [c_ptr5] "r" (c + ldc * 5),
        [c_ptr6] "r" (c + ldc * 6),
        [c_ptr7] "r" (c + ldc * 7)
      : "x27", "x28", "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31",
        "cc"
    );
  } else {
    asm volatile (
      "cbnz   %x[kodd], 2f                            \r\n"

      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla 	v8.4s, v2.4s, v0.s[0]                   \r\n"
      "fmla   v9.4s, v2.4s, v0.s[1]                   \r\n"
      "fmla	  v10.4s, v2.4s, v0.s[2]                  \r\n"

      "ldr	  d6, [%[a_ptr], #32]                     \r\n"
      "fmla	  v11.4s, v2.4s, v0.s[3]                  \r\n"
      "ldr    x28, [%[a_ptr], #40]                    \r\n"
      "fmla 	v12.4s, v2.4s, v1.s[0]                  \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"

      "prfm   pstl1keep, [%[c_ptr0]]                  \r\n"
      "mov    v4.d[1], xzr                            \r\n"
      "fmla	  v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla	  v15.4s, v2.4s, v1.s[3]                  \r\n"
      "fmla	  v16.4s, v3.4s, v0.s[0]                  \r\n"

      "ldr	  d2, [%[b_ptr], #48]                     \r\n"
      "mov    v6.d[1], x28                            \r\n"
      "fmla	  v17.4s, v3.4s, v0.s[1]                  \r\n"
      "ldr    x27, [%[b_ptr], #56]                    \r\n"
      "fmla	  v18.4s, v3.4s, v0.s[2]                  \r\n"
      "fmla	  v19.4s, v3.4s, v0.s[3]                  \r\n"

      "ldr	  d7, [%[a_ptr], #48]                     \r\n"
      "fmla	  v20.4s, v3.4s, v1.s[0]                  \r\n"
      "ldr    x28, [%[a_ptr], #56]                    \r\n"
      "fmla	  v21.4s, v3.4s, v1.s[1]                  \r\n"
      "fmla	  v22.4s, v3.4s, v1.s[2]                  \r\n"

      "prfm   pstl1keep, [%[c_ptr1]]                  \r\n"
      "mov    v2.d[1], x27                            \r\n"
      "fmla	  v23.4s, v3.4s, v1.s[3]                  \r\n"
      "fmla	  v24.4s, v4.4s, v0.s[0]                  \r\n"
      "fmla	  v25.4s, v4.4s, v0.s[1]                  \r\n"
      
      "ldr	  d3, [%[b_ptr], #64]                     \r\n"
      "fmla	  v26.4s, v4.4s, v0.s[2]                  \r\n"
      "ldr    x27, [%[b_ptr], #72]                    \r\n"
      "fmla	  v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v1.s[0]                  \r\n"

      "prfm   pstl1keep, [%[c_ptr2]]                  \r\n"
      "mov    v7.d[1], x28                            \r\n"
      "fmla	  v29.4s, v4.4s, v1.s[1]                  \r\n"
      "fmla	  v30.4s, v4.4s, v1.s[2]                  \r\n"
      "fmla	  v31.4s, v4.4s, v1.s[3]                  \r\n"

      "ldr	  d4, [%[b_ptr], #80]                     \r\n"
      "mov    v3.d[1], x27                            \r\n"
      "fmla 	v8.4s , v2.4s, v6.s[0]                  \r\n"
      "fmla   v9.4s , v2.4s, v6.s[1]                  \r\n"
      "fmla	  v10.4s, v2.4s, v6.s[2]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr3]]                  \r\n"
      "fmla	  v11.4s, v2.4s, v6.s[3]                  \r\n"
      "fmla 	v12.4s, v2.4s, v7.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr4]]                  \r\n"
      "fmla   v13.4s, v2.4s, v7.s[1]                  \r\n"
      "fmla	  v16.4s, v3.4s, v6.s[0]                  \r\n"
      "fmla	  v17.4s, v3.4s, v6.s[1]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr5]]                  \r\n"
      "fmla	  v18.4s, v3.4s, v6.s[2]                  \r\n"
      "fmla	  v19.4s, v3.4s, v6.s[3]                  \r\n"
      "fmla	  v20.4s, v3.4s, v7.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr6]]                  \r\n"
      "fmla	  v21.4s, v3.4s, v7.s[1]                  \r\n"
      "fmla	  v24.4s, v4.4s, v6.s[0]                  \r\n"
      "fmla	  v25.4s, v4.4s, v6.s[1]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr7]]                  \r\n"
      "fmla	  v26.4s, v4.4s, v6.s[2]                  \r\n"
      "fmla	  v27.4s, v4.4s, v6.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v7.s[0]                  \r\n"
      "fmla	  v29.4s, v4.4s, v7.s[1]                  \r\n"
      "fmla	  v14.4s, v2.4s, v7.s[2]                  \r\n"
      "fmla	  v22.4s, v3.4s, v7.s[2]                  \r\n"
      "fmla	  v30.4s, v4.4s, v7.s[2]                  \r\n"
      "fmla	  v15.4s, v2.4s, v7.s[3]                  \r\n"
      "fmla	  v23.4s, v3.4s, v7.s[3]                  \r\n"
      "fmla	  v31.4s, v4.4s, v7.s[3]                  \r\n"

      "b      3f                                      \r\n"

      "2:                                             \r\n"
      "ldr	  d4, [%[b_ptr], #32]                     \r\n"
      "mov    v3.d[1], x28                            \r\n"
      "fmla 	v8.4s , v2.4s, v0.s[0]                  \r\n"
      "fmla   v9.4s , v2.4s, v0.s[1]                  \r\n"
      "fmla	  v10.4s, v2.4s, v0.s[2]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr0]]                  \r\n"
      "fmla	  v11.4s, v2.4s, v0.s[3]                  \r\n"
      "fmla 	v12.4s, v2.4s, v1.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr1]]                  \r\n"
      "fmla   v13.4s, v2.4s, v1.s[1]                  \r\n"
      "fmla	  v16.4s, v3.4s, v0.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr2]]                  \r\n"
      "fmla	  v17.4s, v3.4s, v0.s[1]                  \r\n"
      "fmla	  v18.4s, v3.4s, v0.s[2]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr3]]                  \r\n"
      "fmla	  v19.4s, v3.4s, v0.s[3]                  \r\n"
      "fmla	  v20.4s, v3.4s, v1.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr4]]                  \r\n"
      "fmla	  v21.4s, v3.4s, v1.s[1]                  \r\n"
      "fmla	  v24.4s, v4.4s, v0.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr5]]                  \r\n"
      "fmla	  v25.4s, v4.4s, v0.s[1]                  \r\n"
      "fmla	  v26.4s, v4.4s, v0.s[2]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr6]]                  \r\n"
      "fmla	  v27.4s, v4.4s, v0.s[3]                  \r\n"
      "fmla	  v28.4s, v4.4s, v1.s[0]                  \r\n"
      "prfm   pstl1keep, [%[c_ptr7]]                  \r\n"
      "fmla	  v29.4s, v4.4s, v1.s[1]                  \r\n"
      "fmla	  v14.4s, v2.4s, v1.s[2]                  \r\n"
      "fmla	  v22.4s, v3.4s, v1.s[2]                  \r\n"
      "fmla	  v30.4s, v4.4s, v1.s[2]                  \r\n"
      "fmla	  v15.4s, v2.4s, v1.s[3]                  \r\n"
      "fmla	  v23.4s, v3.4s, v1.s[3]                  \r\n"
      "fmla	  v31.4s, v4.4s, v1.s[3]                  \r\n"

      "3:                                             \r\n"
      : [a_ptr] "+r" (a),
        [b_ptr] "+r" (b)
        // [c_ptr] "+r" (c)
      : [kodd] "r" (kodd),
        // [ldc] "r" (ldc)
        [c_ptr0] "r" (c),
        [c_ptr1] "r" (c + ldc),
        [c_ptr2] "r" (c + ldc * 2),
        [c_ptr3] "r" (c + ldc * 3),
        [c_ptr4] "r" (c + ldc * 4),
        [c_ptr5] "r" (c + ldc * 5),
        [c_ptr6] "r" (c + ldc * 6),
        [c_ptr7] "r" (c + ldc * 7)
      : "x27", "x28", "v0", "v1", "v2", "v3", "v4", "v6", "v7",
        "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31",
        "cc"
    );
  }

  if constexpr (ReLU) {
    if constexpr (AddRes) {
      asm volatile (
        "movi   v5.4s, #0                               \r\n"
        :
        :
        : "v5"
      );
    }

    asm volatile (
      "fmax   v8.4s, v8.4s, v5.4s                     \r\n"
      "fmax   v16.4s, v16.4s, v5.4s                   \r\n"
      "fmax   v24.4s, v24.4s, v5.4s                   \r\n"
      "fmax   v9.4s, v9.4s, v5.4s                     \r\n"
      "fmax   v17.4s, v17.4s, v5.4s                   \r\n"
      "fmax   v25.4s, v25.4s, v5.4s                   \r\n"
      "fmax   v10.4s, v10.4s, v5.4s                   \r\n"
      "fmax   v18.4s, v18.4s, v5.4s                   \r\n"
      "fmax   v26.4s, v26.4s, v5.4s                   \r\n"
      "fmax   v11.4s, v11.4s, v5.4s                   \r\n"
      "fmax   v19.4s, v19.4s, v5.4s                   \r\n"
      "fmax   v27.4s, v27.4s, v5.4s                   \r\n"
      "fmax   v12.4s, v12.4s, v5.4s                   \r\n"
      "fmax   v20.4s, v20.4s, v5.4s                   \r\n"
      "fmax   v28.4s, v28.4s, v5.4s                   \r\n"
      "fmax   v13.4s, v13.4s, v5.4s                   \r\n"
      "fmax   v21.4s, v21.4s, v5.4s                   \r\n"
      "fmax   v29.4s, v29.4s, v5.4s                   \r\n"
      "fmax   v14.4s, v14.4s, v5.4s                   \r\n"
      "fmax   v22.4s, v22.4s, v5.4s                   \r\n"
      "fmax   v30.4s, v30.4s, v5.4s                   \r\n"
      "fmax   v15.4s, v15.4s, v5.4s                   \r\n"
      "fmax   v23.4s, v23.4s, v5.4s                   \r\n"
      "fmax   v31.4s, v31.4s, v5.4s                   \r\n"
      : 
      : 
      : "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15",
        "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23",
        "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31"
    );      
  }

  asm volatile (
    "str	  q8, [%[c_ptr0], #0]                     \r\n"
    "str	  q16, [%[c_ptr0], #16]                   \r\n"
    "str	  s24, [%[c_ptr0], #32]                   \r\n"
    "str	  q9, [%[c_ptr1], #0]                     \r\n"
    "str	  q17, [%[c_ptr1], #16]                   \r\n"
    "str	  s25, [%[c_ptr1], #32]                   \r\n"
    "str	  q10, [%[c_ptr2], #0]                    \r\n"
    "str	  q18, [%[c_ptr2], #16]                   \r\n"
    "str	  s26, [%[c_ptr2], #32]                   \r\n"
    "str	  q11, [%[c_ptr3], #0]                    \r\n"
    "str	  q19, [%[c_ptr3], #16]                   \r\n"
    "str	  s27, [%[c_ptr3], #32]                   \r\n"
    "str	  q12, [%[c_ptr4], #0]                    \r\n"
    "str	  q20, [%[c_ptr4], #16]                   \r\n"
    "str	  s28, [%[c_ptr4], #32]                   \r\n"
    "str	  q13, [%[c_ptr5], #0]                    \r\n"
    "str	  q21, [%[c_ptr5], #16]                   \r\n"
    "str	  s29, [%[c_ptr5], #32]                   \r\n"
    "str	  q14, [%[c_ptr6], #0]                    \r\n"
    "str	  q22, [%[c_ptr6], #16]                   \r\n"
    "str	  s30, [%[c_ptr6], #32]                   \r\n"
    "str	  q15, [%[c_ptr7], #0]                    \r\n"
    "str	  q23, [%[c_ptr7], #16]                   \r\n"
    "str	  s31, [%[c_ptr7], #32]                   \r\n"
    : 
    : [c_ptr0] "r" (c),
      [c_ptr1] "r" (c + ldc),
      [c_ptr2] "r" (c + ldc * 2),
      [c_ptr3] "r" (c + ldc * 3),
      [c_ptr4] "r" (c + ldc * 4),
      [c_ptr5] "r" (c + ldc * 5),
      [c_ptr6] "r" (c + ldc * 6),
      [c_ptr7] "r" (c + ldc * 7)
    : "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", 
      "memory"
  );

#else

  const int m = 8;
  const int n = 12;
  for(int i=0; i<m; i++) {
    for(int j=0; j<n; j++) {
      float val=0.0f;
      for(int l=0; l<k; l++) {
        Lhs aval, bval;
        aval = a[l*lda+i];
        // bval = b[ldb*l+j];
        bval = b[l*ldb+j];    // ReB & PackB

        // val+=a[lda*i+l]*b[ldb*l+j];
        val += aval * bval;
      }
      if (RScale && (RScaleBlend || Blend)) {
        val*=rscale[i];
      }
      if (Load) {
        if (FstIter && RScaleBlend) {
            val+=c[ldc*i+j]*rscale_blend[i];
        } else {
            val+=c[ldc*i+j];
        }
      }
      if (RScale && !(RScaleBlend || Blend)) {
          val*=rscale[i];
      }

      if(RBias) {
        val+=rbias[i];
      }
      if(ReLU) {
        val=std::max(0.0f, val);
      }
      c[ldc*i+j]=val;
    }
  }
#endif
}
};


#endif  // __aarch64


#endif  // GEMM_ROWMAJOR_NOTRANS_KERNELS_8X12_HPP_
