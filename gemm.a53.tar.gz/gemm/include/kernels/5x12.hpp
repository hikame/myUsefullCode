#ifndef GEMM_ROWMAJOR_NOTRANS_KERNELS_5X12_HPP_
#define GEMM_ROWMAJOR_NOTRANS_KERNELS_5X12_HPP_

#include <kernel.hpp>

#ifdef __aarch64__

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 5, 12, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v15", "v16");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+12*(kk+0))
: "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v20", "v21", "v22");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmul	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmul	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmul	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmul	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmul	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmul	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmul	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmul	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmul	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v15", "v16", "v17");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+12*kk+0*12),
[addr_b1] "r" (b+12*kk+1*12)
: "v20", "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v20", "v21", "v22", "v23", "v24", "v25");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmul	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmul	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmul	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmul	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmul	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmul	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmul	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmul	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmul	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v23.4s, v16.s[3]  \r\n"
"	fmla	v7.4s,  v24.4s, v16.s[3]  \r\n"
"	fmla	v8.4s,  v25.4s, v16.s[3]  \r\n"
"	fmla	v9.4s,  v23.4s, v17.s[0]  \r\n"
"	fmla	v10.4s,  v24.4s, v17.s[0]  \r\n"
"	fmla	v11.4s,  v25.4s, v17.s[0]  \r\n"
"	fmla	v12.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v17.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s, v18.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v15", "v16", "v17", "v18");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+12*kk+0*12),
[addr_b1] "r" (b+12*kk+1*12),
[addr_b2] "r" (b+12*kk+2*12)
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmul	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmul	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmul	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmul	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmul	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmul	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmul	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmul	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmul	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v23.4s, v16.s[3]  \r\n"
"	fmla	v7.4s,  v24.4s, v16.s[3]  \r\n"
"	fmla	v8.4s,  v25.4s, v16.s[3]  \r\n"
"	fmla	v9.4s,  v23.4s, v17.s[0]  \r\n"
"	fmla	v10.4s,  v24.4s, v17.s[0]  \r\n"
"	fmla	v11.4s,  v25.4s, v17.s[0]  \r\n"
"	fmla	v12.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v17.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v17.s[3]  \r\n"
"	fmla	v4.4s,  v27.4s, v17.s[3]  \r\n"
"	fmla	v5.4s,  v28.4s, v17.s[3]  \r\n"
"	fmla	v6.4s,  v26.4s, v18.s[0]  \r\n"
"	fmla	v7.4s,  v27.4s, v18.s[0]  \r\n"
"	fmla	v8.4s,  v28.4s, v18.s[0]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v18.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s, v18.4s}, [%[addr_a0]] \r\n"
"ld1    {v19.4s}, [%[addr_a1]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*16),
[addr_a1] "r" (a+5*kk+1*16)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+12*kk+0*12),
[addr_b1] "r" (b+12*kk+1*12),
[addr_b2] "r" (b+12*kk+2*12),
[addr_b3] "r" (b+12*kk+3*12)
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmul	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmul	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmul	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmul	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmul	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmul	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmul	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmul	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmul	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
else {
asm volatile(
"	fmla	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmla	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmla	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmla	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmla	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmla	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmla	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmla	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmla	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmla	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmla	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmla	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmla	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmla	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
kk+=4;
for(; kk<k; kk+=4) {
asm volatile(
"ld1    {v15.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*4)
: "v15");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+12*(kk+0))
: "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v20", "v21", "v22");
}
asm volatile(
"	fmla	v0.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v23.4s, v16.s[3]  \r\n"
"	fmla	v7.4s,  v24.4s, v16.s[3]  \r\n"
"	fmla	v8.4s,  v25.4s, v16.s[3]  \r\n"
"	fmla	v9.4s,  v23.4s, v17.s[0]  \r\n"
"	fmla	v10.4s,  v24.4s, v17.s[0]  \r\n"
"	fmla	v11.4s,  v25.4s, v17.s[0]  \r\n"
"	fmla	v12.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v17.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"ld1    {v16.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+1*4)
: "v16");
if constexpr(ReB) {
asm volatile(
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+12*(kk+1))
: "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v23", "v24", "v25");
}
asm volatile(
"	fmla	v0.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v17.s[3]  \r\n"
"	fmla	v4.4s,  v27.4s, v17.s[3]  \r\n"
"	fmla	v5.4s,  v28.4s, v17.s[3]  \r\n"
"	fmla	v6.4s,  v26.4s, v18.s[0]  \r\n"
"	fmla	v7.4s,  v27.4s, v18.s[0]  \r\n"
"	fmla	v8.4s,  v28.4s, v18.s[0]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v18.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"ld1    {v17.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+2*4)
: "v17");
if constexpr(ReB) {
asm volatile(
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+12*(kk+2))
: "v26", "v27", "v28");
}
else {
asm volatile(
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v26", "v27", "v28");
}
asm volatile(
"	fmla	v0.4s,  v29.4s, v18.s[3]  \r\n"
"	fmla	v1.4s,  v30.4s, v18.s[3]  \r\n"
"	fmla	v2.4s,  v31.4s, v18.s[3]  \r\n"
"	fmla	v3.4s,  v29.4s, v19.s[0]  \r\n"
"	fmla	v4.4s,  v30.4s, v19.s[0]  \r\n"
"	fmla	v5.4s,  v31.4s, v19.s[0]  \r\n"
"	fmla	v6.4s,  v29.4s, v19.s[1]  \r\n"
"	fmla	v7.4s,  v30.4s, v19.s[1]  \r\n"
"	fmla	v8.4s,  v31.4s, v19.s[1]  \r\n"
"	fmla	v9.4s,  v29.4s, v19.s[2]  \r\n"
"	fmla	v10.4s,  v30.4s, v19.s[2]  \r\n"
"	fmla	v11.4s,  v31.4s, v19.s[2]  \r\n"
"	fmla	v12.4s,  v29.4s, v19.s[3]  \r\n"
"	fmla	v13.4s,  v30.4s, v19.s[3]  \r\n"
"	fmla	v14.4s,  v31.4s, v19.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"ld1    {v18.4s, v19.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+3*4)
: "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+12*(kk+3))
: "v29", "v30", "v31");
}
else {
asm volatile(
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v29", "v30", "v31");
}
asm volatile(
"	fmla	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmla	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmla	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmla	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmla	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmla	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmla	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmla	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmla	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmla	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmla	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmla	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmla	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmla	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
asm volatile(
"	fmla	v0.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v23.4s, v16.s[3]  \r\n"
"	fmla	v7.4s,  v24.4s, v16.s[3]  \r\n"
"	fmla	v8.4s,  v25.4s, v16.s[3]  \r\n"
"	fmla	v9.4s,  v23.4s, v17.s[0]  \r\n"
"	fmla	v10.4s,  v24.4s, v17.s[0]  \r\n"
"	fmla	v11.4s,  v25.4s, v17.s[0]  \r\n"
"	fmla	v12.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v17.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v17.s[3]  \r\n"
"	fmla	v4.4s,  v27.4s, v17.s[3]  \r\n"
"	fmla	v5.4s,  v28.4s, v17.s[3]  \r\n"
"	fmla	v6.4s,  v26.4s, v18.s[0]  \r\n"
"	fmla	v7.4s,  v27.4s, v18.s[0]  \r\n"
"	fmla	v8.4s,  v28.4s, v18.s[0]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v18.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v29.4s, v18.s[3]  \r\n"
"	fmla	v1.4s,  v30.4s, v18.s[3]  \r\n"
"	fmla	v2.4s,  v31.4s, v18.s[3]  \r\n"
"	fmla	v3.4s,  v29.4s, v19.s[0]  \r\n"
"	fmla	v4.4s,  v30.4s, v19.s[0]  \r\n"
"	fmla	v5.4s,  v31.4s, v19.s[0]  \r\n"
"	fmla	v6.4s,  v29.4s, v19.s[1]  \r\n"
"	fmla	v7.4s,  v30.4s, v19.s[1]  \r\n"
"	fmla	v8.4s,  v31.4s, v19.s[1]  \r\n"
"	fmla	v9.4s,  v29.4s, v19.s[2]  \r\n"
"	fmla	v10.4s,  v30.4s, v19.s[2]  \r\n"
"	fmla	v11.4s,  v31.4s, v19.s[2]  \r\n"
"	fmla	v12.4s,  v29.4s, v19.s[3]  \r\n"
"	fmla	v13.4s,  v30.4s, v19.s[3]  \r\n"
"	fmla	v14.4s,  v31.4s, v19.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s15, [%[addr_a0]] \r\n"
"ldr    s16, [%[addr_a1]] \r\n"
"ldr    s17, [%[addr_a2]] \r\n"
"ldr    s18, [%[addr_a3]] \r\n"
"ldr    s19, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+12*(kk+0))
: "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v20", "v21", "v22");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v4.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v5.4s,  v22.4s, v16.s[0]  \r\n"
"	fmul	v6.4s,  v20.4s, v17.s[0]  \r\n"
"	fmul	v7.4s,  v21.4s, v17.s[0]  \r\n"
"	fmul	v8.4s,  v22.4s, v17.s[0]  \r\n"
"	fmul	v9.4s,  v20.4s, v18.s[0]  \r\n"
"	fmul	v10.4s,  v21.4s, v18.s[0]  \r\n"
"	fmul	v11.4s,  v22.4s, v18.s[0]  \r\n"
"	fmul	v12.4s,  v20.4s, v19.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v19.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v19.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d15, [%[addr_a0]] \r\n"
"ldr    d16, [%[addr_a1]] \r\n"
"ldr    d17, [%[addr_a2]] \r\n"
"ldr    d18, [%[addr_a3]] \r\n"
"ldr    d19, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+12*kk+0*12),
[addr_b1] "r" (b+12*kk+1*12)
: "v20", "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v20", "v21", "v22", "v23", "v24", "v25");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v4.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v5.4s,  v22.4s, v16.s[0]  \r\n"
"	fmul	v6.4s,  v20.4s, v17.s[0]  \r\n"
"	fmul	v7.4s,  v21.4s, v17.s[0]  \r\n"
"	fmul	v8.4s,  v22.4s, v17.s[0]  \r\n"
"	fmul	v9.4s,  v20.4s, v18.s[0]  \r\n"
"	fmul	v10.4s,  v21.4s, v18.s[0]  \r\n"
"	fmul	v11.4s,  v22.4s, v18.s[0]  \r\n"
"	fmul	v12.4s,  v20.4s, v19.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v19.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v19.s[0]  \r\n"
"	fmla	v0.4s,  v23.4s, v15.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v15.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v15.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v6.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v7.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v8.4s,  v25.4s, v17.s[1]  \r\n"
"	fmla	v9.4s,  v23.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v24.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v25.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v23.4s, v19.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v19.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v19.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q15, [%[addr_a0]] \r\n"
"ldr    q16, [%[addr_a1]] \r\n"
"ldr    q17, [%[addr_a2]] \r\n"
"ldr    q18, [%[addr_a3]] \r\n"
"ldr    q19, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+12*kk+0*12),
[addr_b1] "r" (b+12*kk+1*12),
[addr_b2] "r" (b+12*kk+2*12)
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v4.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v5.4s,  v22.4s, v16.s[0]  \r\n"
"	fmul	v6.4s,  v20.4s, v17.s[0]  \r\n"
"	fmul	v7.4s,  v21.4s, v17.s[0]  \r\n"
"	fmul	v8.4s,  v22.4s, v17.s[0]  \r\n"
"	fmul	v9.4s,  v20.4s, v18.s[0]  \r\n"
"	fmul	v10.4s,  v21.4s, v18.s[0]  \r\n"
"	fmul	v11.4s,  v22.4s, v18.s[0]  \r\n"
"	fmul	v12.4s,  v20.4s, v19.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v19.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v19.s[0]  \r\n"
"	fmla	v0.4s,  v23.4s, v15.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v15.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v15.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v6.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v7.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v8.4s,  v25.4s, v17.s[1]  \r\n"
"	fmla	v9.4s,  v23.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v24.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v25.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v23.4s, v19.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v19.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v19.s[1]  \r\n"
"	fmla	v0.4s,  v26.4s, v15.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v15.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v15.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v27.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v28.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v7.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v8.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[2]  \r\n"
"	fmla	v12.4s,  v26.4s, v19.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v19.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v19.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
"dup     v4.4s, %w[zero] \r\n"
"dup     v5.4s, %w[zero] \r\n"
"dup     v6.4s, %w[zero] \r\n"
"dup     v7.4s, %w[zero] \r\n"
"dup     v8.4s, %w[zero] \r\n"
"dup     v9.4s, %w[zero] \r\n"
"dup     v10.4s, %w[zero] \r\n"
"dup     v11.4s, %w[zero] \r\n"
"dup     v12.4s, %w[zero] \r\n"
"dup     v13.4s, %w[zero] \r\n"
"dup     v14.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
asm volatile(
"ldr    q15, [%[addr_a0]] \r\n"
"ldr    q16, [%[addr_a1]] \r\n"
"ldr    q17, [%[addr_a2]] \r\n"
"ldr    q18, [%[addr_a3]] \r\n"
"ldr    q19, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+12*kk+0*12),
[addr_b1] "r" (b+12*kk+1*12),
[addr_b2] "r" (b+12*kk+2*12),
[addr_b3] "r" (b+12*kk+3*12)
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
asm volatile(
"	fmla	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmla	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmla	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmla	v3.4s,  v20.4s, v16.s[0]  \r\n"
"	fmla	v4.4s,  v21.4s, v16.s[0]  \r\n"
"	fmla	v5.4s,  v22.4s, v16.s[0]  \r\n"
"	fmla	v6.4s,  v20.4s, v17.s[0]  \r\n"
"	fmla	v7.4s,  v21.4s, v17.s[0]  \r\n"
"	fmla	v8.4s,  v22.4s, v17.s[0]  \r\n"
"	fmla	v9.4s,  v20.4s, v18.s[0]  \r\n"
"	fmla	v10.4s,  v21.4s, v18.s[0]  \r\n"
"	fmla	v11.4s,  v22.4s, v18.s[0]  \r\n"
"	fmla	v12.4s,  v20.4s, v19.s[0]  \r\n"
"	fmla	v13.4s,  v21.4s, v19.s[0]  \r\n"
"	fmla	v14.4s,  v22.4s, v19.s[0]  \r\n"
"	fmla	v0.4s,  v23.4s, v15.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v15.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v15.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v6.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v7.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v8.4s,  v25.4s, v17.s[1]  \r\n"
"	fmla	v9.4s,  v23.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v24.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v25.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v23.4s, v19.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v19.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v19.s[1]  \r\n"
"	fmla	v0.4s,  v26.4s, v15.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v15.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v15.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v27.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v28.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v7.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v8.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[2]  \r\n"
"	fmla	v12.4s,  v26.4s, v19.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v19.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v19.s[2]  \r\n"
"	fmla	v0.4s,  v29.4s, v15.s[3]  \r\n"
"	fmla	v1.4s,  v30.4s, v15.s[3]  \r\n"
"	fmla	v2.4s,  v31.4s, v15.s[3]  \r\n"
"	fmla	v3.4s,  v29.4s, v16.s[3]  \r\n"
"	fmla	v4.4s,  v30.4s, v16.s[3]  \r\n"
"	fmla	v5.4s,  v31.4s, v16.s[3]  \r\n"
"	fmla	v6.4s,  v29.4s, v17.s[3]  \r\n"
"	fmla	v7.4s,  v30.4s, v17.s[3]  \r\n"
"	fmla	v8.4s,  v31.4s, v17.s[3]  \r\n"
"	fmla	v9.4s,  v29.4s, v18.s[3]  \r\n"
"	fmla	v10.4s,  v30.4s, v18.s[3]  \r\n"
"	fmla	v11.4s,  v31.4s, v18.s[3]  \r\n"
"	fmla	v12.4s,  v29.4s, v19.s[3]  \r\n"
"	fmla	v13.4s,  v30.4s, v19.s[3]  \r\n"
"	fmla	v14.4s,  v31.4s, v19.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v15.4s, v16.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v15.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v15.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v15.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v15.s[1]       \r\n"
"fmul    v4.4s,  v4.4s,  v15.s[1]       \r\n"
"fmul    v5.4s,  v5.4s,  v15.s[1]       \r\n"
"fmul    v6.4s,  v6.4s,  v15.s[2]       \r\n"
"fmul    v7.4s,  v7.4s,  v15.s[2]       \r\n"
"fmul    v8.4s,  v8.4s,  v15.s[2]       \r\n"
"fmul    v9.4s,  v9.4s,  v15.s[3]       \r\n"
"fmul    v10.4s,  v10.4s,  v15.s[3]       \r\n"
"fmul    v11.4s,  v11.4s,  v15.s[3]       \r\n"
"fmul    v12.4s,  v12.4s,  v16.s[0]       \r\n"
"fmul    v13.4s,  v13.4s,  v16.s[0]       \r\n"
"fmul    v14.4s,  v14.4s,  v16.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v30.4s, v31.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_c0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_c1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_c2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_c3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v15.4s,  v30.s[0]       \r\n"
"fmla    v1.4s,  v16.4s,  v30.s[0]       \r\n"
"fmla    v2.4s,  v17.4s,  v30.s[0]       \r\n"
"fmla    v3.4s,  v18.4s,  v30.s[1]       \r\n"
"fmla    v4.4s,  v19.4s,  v30.s[1]       \r\n"
"fmla    v5.4s,  v20.4s,  v30.s[1]       \r\n"
"fmla    v6.4s,  v21.4s,  v30.s[2]       \r\n"
"fmla    v7.4s,  v22.4s,  v30.s[2]       \r\n"
"fmla    v8.4s,  v23.4s,  v30.s[2]       \r\n"
"fmla    v9.4s,  v24.4s,  v30.s[3]       \r\n"
"fmla    v10.4s,  v25.4s,  v30.s[3]       \r\n"
"fmla    v11.4s,  v26.4s,  v30.s[3]       \r\n"
"fmla    v12.4s,  v27.4s,  v31.s[0]       \r\n"
"fmla    v13.4s,  v28.4s,  v31.s[0]       \r\n"
"fmla    v14.4s,  v29.4s,  v31.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_itm0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_itm1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_itm2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_itm3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_itm4]] \r\n"
:
: [addr_itm0] "r" (itm+12*0),
[addr_itm1] "r" (itm+12*1),
[addr_itm2] "r" (itm+12*2),
[addr_itm3] "r" (itm+12*3),
[addr_itm4] "r" (itm+12*4)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_c0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_c1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_c2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_c3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29");
}
asm volatile(
"fadd     v0.4s, v15.4s,  v0.4s \r\n"
"fadd     v1.4s, v16.4s,  v1.4s \r\n"
"fadd     v2.4s, v17.4s,  v2.4s \r\n"
"fadd     v3.4s, v18.4s,  v3.4s \r\n"
"fadd     v4.4s, v19.4s,  v4.4s \r\n"
"fadd     v5.4s, v20.4s,  v5.4s \r\n"
"fadd     v6.4s, v21.4s,  v6.4s \r\n"
"fadd     v7.4s, v22.4s,  v7.4s \r\n"
"fadd     v8.4s, v23.4s,  v8.4s \r\n"
"fadd     v9.4s, v24.4s,  v9.4s \r\n"
"fadd     v10.4s, v25.4s,  v10.4s \r\n"
"fadd     v11.4s, v26.4s,  v11.4s \r\n"
"fadd     v12.4s, v27.4s,  v12.4s \r\n"
"fadd     v13.4s, v28.4s,  v13.4s \r\n"
"fadd     v14.4s, v29.4s,  v14.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v15.4s, v16.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v15.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v15.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v15.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v15.s[1]       \r\n"
"fmul    v4.4s,  v4.4s,  v15.s[1]       \r\n"
"fmul    v5.4s,  v5.4s,  v15.s[1]       \r\n"
"fmul    v6.4s,  v6.4s,  v15.s[2]       \r\n"
"fmul    v7.4s,  v7.4s,  v15.s[2]       \r\n"
"fmul    v8.4s,  v8.4s,  v15.s[2]       \r\n"
"fmul    v9.4s,  v9.4s,  v15.s[3]       \r\n"
"fmul    v10.4s,  v10.4s,  v15.s[3]       \r\n"
"fmul    v11.4s,  v11.4s,  v15.s[3]       \r\n"
"fmul    v12.4s,  v12.4s,  v16.s[0]       \r\n"
"fmul    v13.4s,  v13.4s,  v16.s[0]       \r\n"
"fmul    v14.4s,  v14.4s,  v16.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_c0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_c1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_c2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_c3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29");
asm volatile(
"fadd     v0.4s, v15.4s,  v0.4s \r\n"
"fadd     v1.4s, v16.4s,  v1.4s \r\n"
"fadd     v2.4s, v17.4s,  v2.4s \r\n"
"fadd     v3.4s, v18.4s,  v3.4s \r\n"
"fadd     v4.4s, v19.4s,  v4.4s \r\n"
"fadd     v5.4s, v20.4s,  v5.4s \r\n"
"fadd     v6.4s, v21.4s,  v6.4s \r\n"
"fadd     v7.4s, v22.4s,  v7.4s \r\n"
"fadd     v8.4s, v23.4s,  v8.4s \r\n"
"fadd     v9.4s, v24.4s,  v9.4s \r\n"
"fadd     v10.4s, v25.4s,  v10.4s \r\n"
"fadd     v11.4s, v26.4s,  v11.4s \r\n"
"fadd     v12.4s, v27.4s,  v12.4s \r\n"
"fadd     v13.4s, v28.4s,  v13.4s \r\n"
"fadd     v14.4s, v29.4s,  v14.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v30.4s, v31.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_c0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_c1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_c2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_c3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v15.4s,  v30.s[0]       \r\n"
"fmla    v1.4s,  v16.4s,  v30.s[0]       \r\n"
"fmla    v2.4s,  v17.4s,  v30.s[0]       \r\n"
"fmla    v3.4s,  v18.4s,  v30.s[1]       \r\n"
"fmla    v4.4s,  v19.4s,  v30.s[1]       \r\n"
"fmla    v5.4s,  v20.4s,  v30.s[1]       \r\n"
"fmla    v6.4s,  v21.4s,  v30.s[2]       \r\n"
"fmla    v7.4s,  v22.4s,  v30.s[2]       \r\n"
"fmla    v8.4s,  v23.4s,  v30.s[2]       \r\n"
"fmla    v9.4s,  v24.4s,  v30.s[3]       \r\n"
"fmla    v10.4s,  v25.4s,  v30.s[3]       \r\n"
"fmla    v11.4s,  v26.4s,  v30.s[3]       \r\n"
"fmla    v12.4s,  v27.4s,  v31.s[0]       \r\n"
"fmla    v13.4s,  v28.4s,  v31.s[0]       \r\n"
"fmla    v14.4s,  v29.4s,  v31.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v15.4s, v16.4s}, [%[addr_bias]] \r\n"
"dup    v17.4s, v15.s[0]               \r\n"
"dup    v18.4s, v15.s[1]               \r\n"
"dup    v19.4s, v15.s[2]               \r\n"
"dup    v20.4s, v15.s[3]               \r\n"
"dup    v21.4s, v16.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v17.4s \r\n"
"fadd     v1.4s, v1.4s,  v17.4s \r\n"
"fadd     v2.4s, v2.4s,  v17.4s \r\n"
"fadd     v3.4s, v3.4s,  v18.4s \r\n"
"fadd     v4.4s, v4.4s,  v18.4s \r\n"
"fadd     v5.4s, v5.4s,  v18.4s \r\n"
"fadd     v6.4s, v6.4s,  v19.4s \r\n"
"fadd     v7.4s, v7.4s,  v19.4s \r\n"
"fadd     v8.4s, v8.4s,  v19.4s \r\n"
"fadd     v9.4s, v9.4s,  v20.4s \r\n"
"fadd     v10.4s, v10.4s,  v20.4s \r\n"
"fadd     v11.4s, v11.4s,  v20.4s \r\n"
"fadd     v12.4s, v12.4s,  v21.4s \r\n"
"fadd     v13.4s, v13.4s,  v21.4s \r\n"
"fadd     v14.4s, v14.4s,  v21.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5", "v5", "v6", "v6", "v7", "v7", "v8", "v8", "v9", "v9", "v10", "v10", "v11", "v11", "v12", "v12", "v13", "v13", "v14", "v14", "v15", "v15", "v16", "v16", "v17", "v17", "v18", "v18", "v19", "v19", "v20", "v20", "v21");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v15.4s, w9             \r\n"
"fmax    v0.4s, v15.4s,  v0.4s \r\n"
"fmax    v1.4s, v15.4s,  v1.4s \r\n"
"fmax    v2.4s, v15.4s,  v2.4s \r\n"
"fmax    v3.4s, v15.4s,  v3.4s \r\n"
"fmax    v4.4s, v15.4s,  v4.4s \r\n"
"fmax    v5.4s, v15.4s,  v5.4s \r\n"
"fmax    v6.4s, v15.4s,  v6.4s \r\n"
"fmax    v7.4s, v15.4s,  v7.4s \r\n"
"fmax    v8.4s, v15.4s,  v8.4s \r\n"
"fmax    v9.4s, v15.4s,  v9.4s \r\n"
"fmax    v10.4s, v15.4s,  v10.4s \r\n"
"fmax    v11.4s, v15.4s,  v11.4s \r\n"
"fmax    v12.4s, v15.4s,  v12.4s \r\n"
"fmax    v13.4s, v15.4s,  v13.4s \r\n"
"fmax    v14.4s, v15.4s,  v14.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"st1    { v0.4s,  v1.4s,  v2.4s,  v3.4s}, [%[addr_itm0]] \r\n"
"st1    { v4.4s,  v5.4s,  v6.4s,  v7.4s}, [%[addr_itm1]] \r\n"
"st1    { v8.4s,  v9.4s,  v10.4s,  v11.4s}, [%[addr_itm2]] \r\n"
"st1    { v12.4s,  v13.4s,  v14.4s}, [%[addr_itm3]] \r\n"
:
: [addr_itm0] "r" (itm+8*0),
[addr_itm1] "r" (itm+8*2),
[addr_itm2] "r" (itm+8*4),
[addr_itm3] "r" (itm+8*6)
: "memory");}
else {
asm volatile(
"st1    {v0.4s, v1.4s, v2.4s}, [%[addr_c0]] \r\n"
"st1    {v3.4s, v4.4s, v5.4s}, [%[addr_c1]] \r\n"
"st1    {v6.4s, v7.4s, v8.4s}, [%[addr_c2]] \r\n"
"st1    {v9.4s, v10.4s, v11.4s}, [%[addr_c3]] \r\n"
"st1    {v12.4s, v13.4s, v14.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 5, 11, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v15", "v16");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+11*(kk+0))
: "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v20", "v21", "v22");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmul	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmul	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmul	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmul	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmul	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmul	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmul	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmul	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmul	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v15", "v16", "v17");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+11*kk+0*11),
[addr_b1] "r" (b+11*kk+1*11)
: "v20", "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v20", "v21", "v22", "v23", "v24", "v25");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmul	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmul	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmul	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmul	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmul	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmul	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmul	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmul	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmul	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v23.4s, v16.s[3]  \r\n"
"	fmla	v7.4s,  v24.4s, v16.s[3]  \r\n"
"	fmla	v8.4s,  v25.4s, v16.s[3]  \r\n"
"	fmla	v9.4s,  v23.4s, v17.s[0]  \r\n"
"	fmla	v10.4s,  v24.4s, v17.s[0]  \r\n"
"	fmla	v11.4s,  v25.4s, v17.s[0]  \r\n"
"	fmla	v12.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v17.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s, v18.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v15", "v16", "v17", "v18");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+11*kk+0*11),
[addr_b1] "r" (b+11*kk+1*11),
[addr_b2] "r" (b+11*kk+2*11)
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmul	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmul	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmul	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmul	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmul	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmul	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmul	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmul	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmul	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v23.4s, v16.s[3]  \r\n"
"	fmla	v7.4s,  v24.4s, v16.s[3]  \r\n"
"	fmla	v8.4s,  v25.4s, v16.s[3]  \r\n"
"	fmla	v9.4s,  v23.4s, v17.s[0]  \r\n"
"	fmla	v10.4s,  v24.4s, v17.s[0]  \r\n"
"	fmla	v11.4s,  v25.4s, v17.s[0]  \r\n"
"	fmla	v12.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v17.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v17.s[3]  \r\n"
"	fmla	v4.4s,  v27.4s, v17.s[3]  \r\n"
"	fmla	v5.4s,  v28.4s, v17.s[3]  \r\n"
"	fmla	v6.4s,  v26.4s, v18.s[0]  \r\n"
"	fmla	v7.4s,  v27.4s, v18.s[0]  \r\n"
"	fmla	v8.4s,  v28.4s, v18.s[0]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v18.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s, v18.4s}, [%[addr_a0]] \r\n"
"ld1    {v19.4s}, [%[addr_a1]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*16),
[addr_a1] "r" (a+5*kk+1*16)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+11*kk+0*11),
[addr_b1] "r" (b+11*kk+1*11),
[addr_b2] "r" (b+11*kk+2*11),
[addr_b3] "r" (b+11*kk+3*11)
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmul	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmul	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmul	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmul	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmul	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmul	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmul	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmul	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmul	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
else {
asm volatile(
"	fmla	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmla	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmla	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmla	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmla	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmla	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmla	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmla	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmla	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmla	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmla	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmla	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmla	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmla	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
kk+=4;
for(; kk<k; kk+=4) {
asm volatile(
"ld1    {v15.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*4)
: "v15");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+11*(kk+0))
: "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v20", "v21", "v22");
}
asm volatile(
"	fmla	v0.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v23.4s, v16.s[3]  \r\n"
"	fmla	v7.4s,  v24.4s, v16.s[3]  \r\n"
"	fmla	v8.4s,  v25.4s, v16.s[3]  \r\n"
"	fmla	v9.4s,  v23.4s, v17.s[0]  \r\n"
"	fmla	v10.4s,  v24.4s, v17.s[0]  \r\n"
"	fmla	v11.4s,  v25.4s, v17.s[0]  \r\n"
"	fmla	v12.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v17.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"ld1    {v16.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+1*4)
: "v16");
if constexpr(ReB) {
asm volatile(
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+11*(kk+1))
: "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v23", "v24", "v25");
}
asm volatile(
"	fmla	v0.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v17.s[3]  \r\n"
"	fmla	v4.4s,  v27.4s, v17.s[3]  \r\n"
"	fmla	v5.4s,  v28.4s, v17.s[3]  \r\n"
"	fmla	v6.4s,  v26.4s, v18.s[0]  \r\n"
"	fmla	v7.4s,  v27.4s, v18.s[0]  \r\n"
"	fmla	v8.4s,  v28.4s, v18.s[0]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v18.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"ld1    {v17.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+2*4)
: "v17");
if constexpr(ReB) {
asm volatile(
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+11*(kk+2))
: "v26", "v27", "v28");
}
else {
asm volatile(
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v26", "v27", "v28");
}
asm volatile(
"	fmla	v0.4s,  v29.4s, v18.s[3]  \r\n"
"	fmla	v1.4s,  v30.4s, v18.s[3]  \r\n"
"	fmla	v2.4s,  v31.4s, v18.s[3]  \r\n"
"	fmla	v3.4s,  v29.4s, v19.s[0]  \r\n"
"	fmla	v4.4s,  v30.4s, v19.s[0]  \r\n"
"	fmla	v5.4s,  v31.4s, v19.s[0]  \r\n"
"	fmla	v6.4s,  v29.4s, v19.s[1]  \r\n"
"	fmla	v7.4s,  v30.4s, v19.s[1]  \r\n"
"	fmla	v8.4s,  v31.4s, v19.s[1]  \r\n"
"	fmla	v9.4s,  v29.4s, v19.s[2]  \r\n"
"	fmla	v10.4s,  v30.4s, v19.s[2]  \r\n"
"	fmla	v11.4s,  v31.4s, v19.s[2]  \r\n"
"	fmla	v12.4s,  v29.4s, v19.s[3]  \r\n"
"	fmla	v13.4s,  v30.4s, v19.s[3]  \r\n"
"	fmla	v14.4s,  v31.4s, v19.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"ld1    {v18.4s, v19.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+3*4)
: "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+11*(kk+3))
: "v29", "v30", "v31");
}
else {
asm volatile(
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v29", "v30", "v31");
}
asm volatile(
"	fmla	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmla	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmla	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmla	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmla	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmla	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmla	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmla	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmla	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmla	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmla	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmla	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmla	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmla	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
asm volatile(
"	fmla	v0.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v23.4s, v16.s[3]  \r\n"
"	fmla	v7.4s,  v24.4s, v16.s[3]  \r\n"
"	fmla	v8.4s,  v25.4s, v16.s[3]  \r\n"
"	fmla	v9.4s,  v23.4s, v17.s[0]  \r\n"
"	fmla	v10.4s,  v24.4s, v17.s[0]  \r\n"
"	fmla	v11.4s,  v25.4s, v17.s[0]  \r\n"
"	fmla	v12.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v17.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v17.s[3]  \r\n"
"	fmla	v4.4s,  v27.4s, v17.s[3]  \r\n"
"	fmla	v5.4s,  v28.4s, v17.s[3]  \r\n"
"	fmla	v6.4s,  v26.4s, v18.s[0]  \r\n"
"	fmla	v7.4s,  v27.4s, v18.s[0]  \r\n"
"	fmla	v8.4s,  v28.4s, v18.s[0]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v18.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v29.4s, v18.s[3]  \r\n"
"	fmla	v1.4s,  v30.4s, v18.s[3]  \r\n"
"	fmla	v2.4s,  v31.4s, v18.s[3]  \r\n"
"	fmla	v3.4s,  v29.4s, v19.s[0]  \r\n"
"	fmla	v4.4s,  v30.4s, v19.s[0]  \r\n"
"	fmla	v5.4s,  v31.4s, v19.s[0]  \r\n"
"	fmla	v6.4s,  v29.4s, v19.s[1]  \r\n"
"	fmla	v7.4s,  v30.4s, v19.s[1]  \r\n"
"	fmla	v8.4s,  v31.4s, v19.s[1]  \r\n"
"	fmla	v9.4s,  v29.4s, v19.s[2]  \r\n"
"	fmla	v10.4s,  v30.4s, v19.s[2]  \r\n"
"	fmla	v11.4s,  v31.4s, v19.s[2]  \r\n"
"	fmla	v12.4s,  v29.4s, v19.s[3]  \r\n"
"	fmla	v13.4s,  v30.4s, v19.s[3]  \r\n"
"	fmla	v14.4s,  v31.4s, v19.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s15, [%[addr_a0]] \r\n"
"ldr    s16, [%[addr_a1]] \r\n"
"ldr    s17, [%[addr_a2]] \r\n"
"ldr    s18, [%[addr_a3]] \r\n"
"ldr    s19, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+11*(kk+0))
: "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v20", "v21", "v22");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v4.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v5.4s,  v22.4s, v16.s[0]  \r\n"
"	fmul	v6.4s,  v20.4s, v17.s[0]  \r\n"
"	fmul	v7.4s,  v21.4s, v17.s[0]  \r\n"
"	fmul	v8.4s,  v22.4s, v17.s[0]  \r\n"
"	fmul	v9.4s,  v20.4s, v18.s[0]  \r\n"
"	fmul	v10.4s,  v21.4s, v18.s[0]  \r\n"
"	fmul	v11.4s,  v22.4s, v18.s[0]  \r\n"
"	fmul	v12.4s,  v20.4s, v19.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v19.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v19.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d15, [%[addr_a0]] \r\n"
"ldr    d16, [%[addr_a1]] \r\n"
"ldr    d17, [%[addr_a2]] \r\n"
"ldr    d18, [%[addr_a3]] \r\n"
"ldr    d19, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+11*kk+0*11),
[addr_b1] "r" (b+11*kk+1*11)
: "v20", "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v20", "v21", "v22", "v23", "v24", "v25");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v4.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v5.4s,  v22.4s, v16.s[0]  \r\n"
"	fmul	v6.4s,  v20.4s, v17.s[0]  \r\n"
"	fmul	v7.4s,  v21.4s, v17.s[0]  \r\n"
"	fmul	v8.4s,  v22.4s, v17.s[0]  \r\n"
"	fmul	v9.4s,  v20.4s, v18.s[0]  \r\n"
"	fmul	v10.4s,  v21.4s, v18.s[0]  \r\n"
"	fmul	v11.4s,  v22.4s, v18.s[0]  \r\n"
"	fmul	v12.4s,  v20.4s, v19.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v19.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v19.s[0]  \r\n"
"	fmla	v0.4s,  v23.4s, v15.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v15.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v15.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v6.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v7.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v8.4s,  v25.4s, v17.s[1]  \r\n"
"	fmla	v9.4s,  v23.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v24.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v25.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v23.4s, v19.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v19.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v19.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q15, [%[addr_a0]] \r\n"
"ldr    q16, [%[addr_a1]] \r\n"
"ldr    q17, [%[addr_a2]] \r\n"
"ldr    q18, [%[addr_a3]] \r\n"
"ldr    q19, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+11*kk+0*11),
[addr_b1] "r" (b+11*kk+1*11),
[addr_b2] "r" (b+11*kk+2*11)
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v4.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v5.4s,  v22.4s, v16.s[0]  \r\n"
"	fmul	v6.4s,  v20.4s, v17.s[0]  \r\n"
"	fmul	v7.4s,  v21.4s, v17.s[0]  \r\n"
"	fmul	v8.4s,  v22.4s, v17.s[0]  \r\n"
"	fmul	v9.4s,  v20.4s, v18.s[0]  \r\n"
"	fmul	v10.4s,  v21.4s, v18.s[0]  \r\n"
"	fmul	v11.4s,  v22.4s, v18.s[0]  \r\n"
"	fmul	v12.4s,  v20.4s, v19.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v19.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v19.s[0]  \r\n"
"	fmla	v0.4s,  v23.4s, v15.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v15.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v15.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v6.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v7.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v8.4s,  v25.4s, v17.s[1]  \r\n"
"	fmla	v9.4s,  v23.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v24.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v25.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v23.4s, v19.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v19.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v19.s[1]  \r\n"
"	fmla	v0.4s,  v26.4s, v15.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v15.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v15.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v27.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v28.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v7.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v8.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[2]  \r\n"
"	fmla	v12.4s,  v26.4s, v19.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v19.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v19.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
"dup     v4.4s, %w[zero] \r\n"
"dup     v5.4s, %w[zero] \r\n"
"dup     v6.4s, %w[zero] \r\n"
"dup     v7.4s, %w[zero] \r\n"
"dup     v8.4s, %w[zero] \r\n"
"dup     v9.4s, %w[zero] \r\n"
"dup     v10.4s, %w[zero] \r\n"
"dup     v11.4s, %w[zero] \r\n"
"dup     v12.4s, %w[zero] \r\n"
"dup     v13.4s, %w[zero] \r\n"
"dup     v14.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
asm volatile(
"ldr    q15, [%[addr_a0]] \r\n"
"ldr    q16, [%[addr_a1]] \r\n"
"ldr    q17, [%[addr_a2]] \r\n"
"ldr    q18, [%[addr_a3]] \r\n"
"ldr    q19, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+11*kk+0*11),
[addr_b1] "r" (b+11*kk+1*11),
[addr_b2] "r" (b+11*kk+2*11),
[addr_b3] "r" (b+11*kk+3*11)
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
asm volatile(
"	fmla	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmla	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmla	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmla	v3.4s,  v20.4s, v16.s[0]  \r\n"
"	fmla	v4.4s,  v21.4s, v16.s[0]  \r\n"
"	fmla	v5.4s,  v22.4s, v16.s[0]  \r\n"
"	fmla	v6.4s,  v20.4s, v17.s[0]  \r\n"
"	fmla	v7.4s,  v21.4s, v17.s[0]  \r\n"
"	fmla	v8.4s,  v22.4s, v17.s[0]  \r\n"
"	fmla	v9.4s,  v20.4s, v18.s[0]  \r\n"
"	fmla	v10.4s,  v21.4s, v18.s[0]  \r\n"
"	fmla	v11.4s,  v22.4s, v18.s[0]  \r\n"
"	fmla	v12.4s,  v20.4s, v19.s[0]  \r\n"
"	fmla	v13.4s,  v21.4s, v19.s[0]  \r\n"
"	fmla	v14.4s,  v22.4s, v19.s[0]  \r\n"
"	fmla	v0.4s,  v23.4s, v15.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v15.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v15.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v6.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v7.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v8.4s,  v25.4s, v17.s[1]  \r\n"
"	fmla	v9.4s,  v23.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v24.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v25.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v23.4s, v19.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v19.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v19.s[1]  \r\n"
"	fmla	v0.4s,  v26.4s, v15.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v15.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v15.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v27.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v28.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v7.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v8.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[2]  \r\n"
"	fmla	v12.4s,  v26.4s, v19.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v19.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v19.s[2]  \r\n"
"	fmla	v0.4s,  v29.4s, v15.s[3]  \r\n"
"	fmla	v1.4s,  v30.4s, v15.s[3]  \r\n"
"	fmla	v2.4s,  v31.4s, v15.s[3]  \r\n"
"	fmla	v3.4s,  v29.4s, v16.s[3]  \r\n"
"	fmla	v4.4s,  v30.4s, v16.s[3]  \r\n"
"	fmla	v5.4s,  v31.4s, v16.s[3]  \r\n"
"	fmla	v6.4s,  v29.4s, v17.s[3]  \r\n"
"	fmla	v7.4s,  v30.4s, v17.s[3]  \r\n"
"	fmla	v8.4s,  v31.4s, v17.s[3]  \r\n"
"	fmla	v9.4s,  v29.4s, v18.s[3]  \r\n"
"	fmla	v10.4s,  v30.4s, v18.s[3]  \r\n"
"	fmla	v11.4s,  v31.4s, v18.s[3]  \r\n"
"	fmla	v12.4s,  v29.4s, v19.s[3]  \r\n"
"	fmla	v13.4s,  v30.4s, v19.s[3]  \r\n"
"	fmla	v14.4s,  v31.4s, v19.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v15.4s, v16.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v15.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v15.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v15.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v15.s[1]       \r\n"
"fmul    v4.4s,  v4.4s,  v15.s[1]       \r\n"
"fmul    v5.4s,  v5.4s,  v15.s[1]       \r\n"
"fmul    v6.4s,  v6.4s,  v15.s[2]       \r\n"
"fmul    v7.4s,  v7.4s,  v15.s[2]       \r\n"
"fmul    v8.4s,  v8.4s,  v15.s[2]       \r\n"
"fmul    v9.4s,  v9.4s,  v15.s[3]       \r\n"
"fmul    v10.4s,  v10.4s,  v15.s[3]       \r\n"
"fmul    v11.4s,  v11.4s,  v15.s[3]       \r\n"
"fmul    v12.4s,  v12.4s,  v16.s[0]       \r\n"
"fmul    v13.4s,  v13.4s,  v16.s[0]       \r\n"
"fmul    v14.4s,  v14.4s,  v16.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v30.4s, v31.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_c0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_c1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_c2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_c3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v15.4s,  v30.s[0]       \r\n"
"fmla    v1.4s,  v16.4s,  v30.s[0]       \r\n"
"fmla    v2.4s,  v17.4s,  v30.s[0]       \r\n"
"fmla    v3.4s,  v18.4s,  v30.s[1]       \r\n"
"fmla    v4.4s,  v19.4s,  v30.s[1]       \r\n"
"fmla    v5.4s,  v20.4s,  v30.s[1]       \r\n"
"fmla    v6.4s,  v21.4s,  v30.s[2]       \r\n"
"fmla    v7.4s,  v22.4s,  v30.s[2]       \r\n"
"fmla    v8.4s,  v23.4s,  v30.s[2]       \r\n"
"fmla    v9.4s,  v24.4s,  v30.s[3]       \r\n"
"fmla    v10.4s,  v25.4s,  v30.s[3]       \r\n"
"fmla    v11.4s,  v26.4s,  v30.s[3]       \r\n"
"fmla    v12.4s,  v27.4s,  v31.s[0]       \r\n"
"fmla    v13.4s,  v28.4s,  v31.s[0]       \r\n"
"fmla    v14.4s,  v29.4s,  v31.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_itm0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_itm1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_itm2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_itm3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_itm4]] \r\n"
:
: [addr_itm0] "r" (itm+11*0),
[addr_itm1] "r" (itm+11*1),
[addr_itm2] "r" (itm+11*2),
[addr_itm3] "r" (itm+11*3),
[addr_itm4] "r" (itm+11*4)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_c0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_c1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_c2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_c3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29");
}
asm volatile(
"fadd     v0.4s, v15.4s,  v0.4s \r\n"
"fadd     v1.4s, v16.4s,  v1.4s \r\n"
"fadd     v2.4s, v17.4s,  v2.4s \r\n"
"fadd     v3.4s, v18.4s,  v3.4s \r\n"
"fadd     v4.4s, v19.4s,  v4.4s \r\n"
"fadd     v5.4s, v20.4s,  v5.4s \r\n"
"fadd     v6.4s, v21.4s,  v6.4s \r\n"
"fadd     v7.4s, v22.4s,  v7.4s \r\n"
"fadd     v8.4s, v23.4s,  v8.4s \r\n"
"fadd     v9.4s, v24.4s,  v9.4s \r\n"
"fadd     v10.4s, v25.4s,  v10.4s \r\n"
"fadd     v11.4s, v26.4s,  v11.4s \r\n"
"fadd     v12.4s, v27.4s,  v12.4s \r\n"
"fadd     v13.4s, v28.4s,  v13.4s \r\n"
"fadd     v14.4s, v29.4s,  v14.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v15.4s, v16.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v15.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v15.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v15.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v15.s[1]       \r\n"
"fmul    v4.4s,  v4.4s,  v15.s[1]       \r\n"
"fmul    v5.4s,  v5.4s,  v15.s[1]       \r\n"
"fmul    v6.4s,  v6.4s,  v15.s[2]       \r\n"
"fmul    v7.4s,  v7.4s,  v15.s[2]       \r\n"
"fmul    v8.4s,  v8.4s,  v15.s[2]       \r\n"
"fmul    v9.4s,  v9.4s,  v15.s[3]       \r\n"
"fmul    v10.4s,  v10.4s,  v15.s[3]       \r\n"
"fmul    v11.4s,  v11.4s,  v15.s[3]       \r\n"
"fmul    v12.4s,  v12.4s,  v16.s[0]       \r\n"
"fmul    v13.4s,  v13.4s,  v16.s[0]       \r\n"
"fmul    v14.4s,  v14.4s,  v16.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_c0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_c1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_c2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_c3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29");
asm volatile(
"fadd     v0.4s, v15.4s,  v0.4s \r\n"
"fadd     v1.4s, v16.4s,  v1.4s \r\n"
"fadd     v2.4s, v17.4s,  v2.4s \r\n"
"fadd     v3.4s, v18.4s,  v3.4s \r\n"
"fadd     v4.4s, v19.4s,  v4.4s \r\n"
"fadd     v5.4s, v20.4s,  v5.4s \r\n"
"fadd     v6.4s, v21.4s,  v6.4s \r\n"
"fadd     v7.4s, v22.4s,  v7.4s \r\n"
"fadd     v8.4s, v23.4s,  v8.4s \r\n"
"fadd     v9.4s, v24.4s,  v9.4s \r\n"
"fadd     v10.4s, v25.4s,  v10.4s \r\n"
"fadd     v11.4s, v26.4s,  v11.4s \r\n"
"fadd     v12.4s, v27.4s,  v12.4s \r\n"
"fadd     v13.4s, v28.4s,  v13.4s \r\n"
"fadd     v14.4s, v29.4s,  v14.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v30.4s, v31.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_c0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_c1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_c2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_c3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v15.4s,  v30.s[0]       \r\n"
"fmla    v1.4s,  v16.4s,  v30.s[0]       \r\n"
"fmla    v2.4s,  v17.4s,  v30.s[0]       \r\n"
"fmla    v3.4s,  v18.4s,  v30.s[1]       \r\n"
"fmla    v4.4s,  v19.4s,  v30.s[1]       \r\n"
"fmla    v5.4s,  v20.4s,  v30.s[1]       \r\n"
"fmla    v6.4s,  v21.4s,  v30.s[2]       \r\n"
"fmla    v7.4s,  v22.4s,  v30.s[2]       \r\n"
"fmla    v8.4s,  v23.4s,  v30.s[2]       \r\n"
"fmla    v9.4s,  v24.4s,  v30.s[3]       \r\n"
"fmla    v10.4s,  v25.4s,  v30.s[3]       \r\n"
"fmla    v11.4s,  v26.4s,  v30.s[3]       \r\n"
"fmla    v12.4s,  v27.4s,  v31.s[0]       \r\n"
"fmla    v13.4s,  v28.4s,  v31.s[0]       \r\n"
"fmla    v14.4s,  v29.4s,  v31.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v15.4s, v16.4s}, [%[addr_bias]] \r\n"
"dup    v17.4s, v15.s[0]               \r\n"
"dup    v18.4s, v15.s[1]               \r\n"
"dup    v19.4s, v15.s[2]               \r\n"
"dup    v20.4s, v15.s[3]               \r\n"
"dup    v21.4s, v16.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v17.4s \r\n"
"fadd     v1.4s, v1.4s,  v17.4s \r\n"
"fadd     v2.4s, v2.4s,  v17.4s \r\n"
"fadd     v3.4s, v3.4s,  v18.4s \r\n"
"fadd     v4.4s, v4.4s,  v18.4s \r\n"
"fadd     v5.4s, v5.4s,  v18.4s \r\n"
"fadd     v6.4s, v6.4s,  v19.4s \r\n"
"fadd     v7.4s, v7.4s,  v19.4s \r\n"
"fadd     v8.4s, v8.4s,  v19.4s \r\n"
"fadd     v9.4s, v9.4s,  v20.4s \r\n"
"fadd     v10.4s, v10.4s,  v20.4s \r\n"
"fadd     v11.4s, v11.4s,  v20.4s \r\n"
"fadd     v12.4s, v12.4s,  v21.4s \r\n"
"fadd     v13.4s, v13.4s,  v21.4s \r\n"
"fadd     v14.4s, v14.4s,  v21.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5", "v5", "v6", "v6", "v7", "v7", "v8", "v8", "v9", "v9", "v10", "v10", "v11", "v11", "v12", "v12", "v13", "v13", "v14", "v14", "v15", "v15", "v16", "v16", "v17", "v17", "v18", "v18", "v19", "v19", "v20", "v20", "v21");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v15.4s, w9             \r\n"
"fmax    v0.4s, v15.4s,  v0.4s \r\n"
"fmax    v1.4s, v15.4s,  v1.4s \r\n"
"fmax    v2.4s, v15.4s,  v2.4s \r\n"
"fmax    v3.4s, v15.4s,  v3.4s \r\n"
"fmax    v4.4s, v15.4s,  v4.4s \r\n"
"fmax    v5.4s, v15.4s,  v5.4s \r\n"
"fmax    v6.4s, v15.4s,  v6.4s \r\n"
"fmax    v7.4s, v15.4s,  v7.4s \r\n"
"fmax    v8.4s, v15.4s,  v8.4s \r\n"
"fmax    v9.4s, v15.4s,  v9.4s \r\n"
"fmax    v10.4s, v15.4s,  v10.4s \r\n"
"fmax    v11.4s, v15.4s,  v11.4s \r\n"
"fmax    v12.4s, v15.4s,  v12.4s \r\n"
"fmax    v13.4s, v15.4s,  v13.4s \r\n"
"fmax    v14.4s, v15.4s,  v14.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"mov    s15,  v2.s[2]           \r\n"
"mov    s16,  v5.s[2]           \r\n"
"mov    s17,  v8.s[2]           \r\n"
"mov    s18,  v11.s[2]           \r\n"
"mov    s19,  v14.s[2]           \r\n"
"str     q0, [%[addr_itm],   0] \r\n"
"str     q1, [%[addr_itm],   16] \r\n"
"str     d2, [%[addr_itm],   32] \r\n"
"str     s15, [%[addr_itm],   40] \r\n"
"str     q3, [%[addr_itm],   44] \r\n"
"str     q4, [%[addr_itm],   60] \r\n"
"str     d5, [%[addr_itm],   76] \r\n"
"str     s16, [%[addr_itm],   84] \r\n"
"str     q6, [%[addr_itm],   88] \r\n"
"str     q7, [%[addr_itm],   104] \r\n"
"str     d8, [%[addr_itm],   120] \r\n"
"str     s17, [%[addr_itm],   128] \r\n"
"str     q9, [%[addr_itm],   132] \r\n"
"str     q10, [%[addr_itm],   148] \r\n"
"str     d11, [%[addr_itm],   164] \r\n"
"str     s18, [%[addr_itm],   172] \r\n"
"str     q12, [%[addr_itm],   176] \r\n"
"str     q13, [%[addr_itm],   192] \r\n"
"str     d14, [%[addr_itm],   208] \r\n"
"str     s19, [%[addr_itm],   216] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"mov    s15,  v2.s[2]           \r\n"
"mov    s16,  v5.s[2]           \r\n"
"mov    s17,  v8.s[2]           \r\n"
"mov    s18,  v11.s[2]           \r\n"
"mov    s19,  v14.s[2]           \r\n"
"str     q0, [%[addr_c0],   0] \r\n"
"str     q1, [%[addr_c0],   16] \r\n"
"str     d2, [%[addr_c0],   32] \r\n"
"str     s15, [%[addr_c0],   40] \r\n"
"str     q3, [%[addr_c1],   0] \r\n"
"str     q4, [%[addr_c1],   16] \r\n"
"str     d5, [%[addr_c1],   32] \r\n"
"str     s16, [%[addr_c1],   40] \r\n"
"str     q6, [%[addr_c2],   0] \r\n"
"str     q7, [%[addr_c2],   16] \r\n"
"str     d8, [%[addr_c2],   32] \r\n"
"str     s17, [%[addr_c2],   40] \r\n"
"str     q9, [%[addr_c3],   0] \r\n"
"str     q10, [%[addr_c3],   16] \r\n"
"str     d11, [%[addr_c3],   32] \r\n"
"str     s18, [%[addr_c3],   40] \r\n"
"str     q12, [%[addr_c4],   0] \r\n"
"str     q13, [%[addr_c4],   16] \r\n"
"str     d14, [%[addr_c4],   32] \r\n"
"str     s19, [%[addr_c4],   40] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 5, 10, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v15", "v16");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+10*(kk+0))
: "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v20", "v21", "v22");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmul	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmul	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmul	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmul	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmul	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmul	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmul	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmul	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmul	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v15", "v16", "v17");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+10*kk+0*10),
[addr_b1] "r" (b+10*kk+1*10)
: "v20", "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v20", "v21", "v22", "v23", "v24", "v25");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmul	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmul	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmul	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmul	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmul	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmul	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmul	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmul	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmul	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v23.4s, v16.s[3]  \r\n"
"	fmla	v7.4s,  v24.4s, v16.s[3]  \r\n"
"	fmla	v8.4s,  v25.4s, v16.s[3]  \r\n"
"	fmla	v9.4s,  v23.4s, v17.s[0]  \r\n"
"	fmla	v10.4s,  v24.4s, v17.s[0]  \r\n"
"	fmla	v11.4s,  v25.4s, v17.s[0]  \r\n"
"	fmla	v12.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v17.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s, v18.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v15", "v16", "v17", "v18");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+10*kk+0*10),
[addr_b1] "r" (b+10*kk+1*10),
[addr_b2] "r" (b+10*kk+2*10)
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmul	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmul	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmul	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmul	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmul	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmul	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmul	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmul	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmul	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v23.4s, v16.s[3]  \r\n"
"	fmla	v7.4s,  v24.4s, v16.s[3]  \r\n"
"	fmla	v8.4s,  v25.4s, v16.s[3]  \r\n"
"	fmla	v9.4s,  v23.4s, v17.s[0]  \r\n"
"	fmla	v10.4s,  v24.4s, v17.s[0]  \r\n"
"	fmla	v11.4s,  v25.4s, v17.s[0]  \r\n"
"	fmla	v12.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v17.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v17.s[3]  \r\n"
"	fmla	v4.4s,  v27.4s, v17.s[3]  \r\n"
"	fmla	v5.4s,  v28.4s, v17.s[3]  \r\n"
"	fmla	v6.4s,  v26.4s, v18.s[0]  \r\n"
"	fmla	v7.4s,  v27.4s, v18.s[0]  \r\n"
"	fmla	v8.4s,  v28.4s, v18.s[0]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v18.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s, v18.4s}, [%[addr_a0]] \r\n"
"ld1    {v19.4s}, [%[addr_a1]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*16),
[addr_a1] "r" (a+5*kk+1*16)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+10*kk+0*10),
[addr_b1] "r" (b+10*kk+1*10),
[addr_b2] "r" (b+10*kk+2*10),
[addr_b3] "r" (b+10*kk+3*10)
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmul	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmul	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmul	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmul	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmul	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmul	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmul	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmul	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmul	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
else {
asm volatile(
"	fmla	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmla	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmla	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmla	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmla	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmla	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmla	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmla	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmla	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmla	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmla	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmla	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmla	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmla	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
kk+=4;
for(; kk<k; kk+=4) {
asm volatile(
"ld1    {v15.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*4)
: "v15");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+10*(kk+0))
: "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v20", "v21", "v22");
}
asm volatile(
"	fmla	v0.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v23.4s, v16.s[3]  \r\n"
"	fmla	v7.4s,  v24.4s, v16.s[3]  \r\n"
"	fmla	v8.4s,  v25.4s, v16.s[3]  \r\n"
"	fmla	v9.4s,  v23.4s, v17.s[0]  \r\n"
"	fmla	v10.4s,  v24.4s, v17.s[0]  \r\n"
"	fmla	v11.4s,  v25.4s, v17.s[0]  \r\n"
"	fmla	v12.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v17.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"ld1    {v16.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+1*4)
: "v16");
if constexpr(ReB) {
asm volatile(
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+10*(kk+1))
: "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v23", "v24", "v25");
}
asm volatile(
"	fmla	v0.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v17.s[3]  \r\n"
"	fmla	v4.4s,  v27.4s, v17.s[3]  \r\n"
"	fmla	v5.4s,  v28.4s, v17.s[3]  \r\n"
"	fmla	v6.4s,  v26.4s, v18.s[0]  \r\n"
"	fmla	v7.4s,  v27.4s, v18.s[0]  \r\n"
"	fmla	v8.4s,  v28.4s, v18.s[0]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v18.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"ld1    {v17.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+2*4)
: "v17");
if constexpr(ReB) {
asm volatile(
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+10*(kk+2))
: "v26", "v27", "v28");
}
else {
asm volatile(
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v26", "v27", "v28");
}
asm volatile(
"	fmla	v0.4s,  v29.4s, v18.s[3]  \r\n"
"	fmla	v1.4s,  v30.4s, v18.s[3]  \r\n"
"	fmla	v2.4s,  v31.4s, v18.s[3]  \r\n"
"	fmla	v3.4s,  v29.4s, v19.s[0]  \r\n"
"	fmla	v4.4s,  v30.4s, v19.s[0]  \r\n"
"	fmla	v5.4s,  v31.4s, v19.s[0]  \r\n"
"	fmla	v6.4s,  v29.4s, v19.s[1]  \r\n"
"	fmla	v7.4s,  v30.4s, v19.s[1]  \r\n"
"	fmla	v8.4s,  v31.4s, v19.s[1]  \r\n"
"	fmla	v9.4s,  v29.4s, v19.s[2]  \r\n"
"	fmla	v10.4s,  v30.4s, v19.s[2]  \r\n"
"	fmla	v11.4s,  v31.4s, v19.s[2]  \r\n"
"	fmla	v12.4s,  v29.4s, v19.s[3]  \r\n"
"	fmla	v13.4s,  v30.4s, v19.s[3]  \r\n"
"	fmla	v14.4s,  v31.4s, v19.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"ld1    {v18.4s, v19.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+3*4)
: "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+10*(kk+3))
: "v29", "v30", "v31");
}
else {
asm volatile(
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v29", "v30", "v31");
}
asm volatile(
"	fmla	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmla	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmla	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmla	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmla	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmla	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmla	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmla	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmla	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmla	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmla	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmla	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmla	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmla	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
asm volatile(
"	fmla	v0.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v23.4s, v16.s[3]  \r\n"
"	fmla	v7.4s,  v24.4s, v16.s[3]  \r\n"
"	fmla	v8.4s,  v25.4s, v16.s[3]  \r\n"
"	fmla	v9.4s,  v23.4s, v17.s[0]  \r\n"
"	fmla	v10.4s,  v24.4s, v17.s[0]  \r\n"
"	fmla	v11.4s,  v25.4s, v17.s[0]  \r\n"
"	fmla	v12.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v17.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v17.s[3]  \r\n"
"	fmla	v4.4s,  v27.4s, v17.s[3]  \r\n"
"	fmla	v5.4s,  v28.4s, v17.s[3]  \r\n"
"	fmla	v6.4s,  v26.4s, v18.s[0]  \r\n"
"	fmla	v7.4s,  v27.4s, v18.s[0]  \r\n"
"	fmla	v8.4s,  v28.4s, v18.s[0]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v18.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v29.4s, v18.s[3]  \r\n"
"	fmla	v1.4s,  v30.4s, v18.s[3]  \r\n"
"	fmla	v2.4s,  v31.4s, v18.s[3]  \r\n"
"	fmla	v3.4s,  v29.4s, v19.s[0]  \r\n"
"	fmla	v4.4s,  v30.4s, v19.s[0]  \r\n"
"	fmla	v5.4s,  v31.4s, v19.s[0]  \r\n"
"	fmla	v6.4s,  v29.4s, v19.s[1]  \r\n"
"	fmla	v7.4s,  v30.4s, v19.s[1]  \r\n"
"	fmla	v8.4s,  v31.4s, v19.s[1]  \r\n"
"	fmla	v9.4s,  v29.4s, v19.s[2]  \r\n"
"	fmla	v10.4s,  v30.4s, v19.s[2]  \r\n"
"	fmla	v11.4s,  v31.4s, v19.s[2]  \r\n"
"	fmla	v12.4s,  v29.4s, v19.s[3]  \r\n"
"	fmla	v13.4s,  v30.4s, v19.s[3]  \r\n"
"	fmla	v14.4s,  v31.4s, v19.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s15, [%[addr_a0]] \r\n"
"ldr    s16, [%[addr_a1]] \r\n"
"ldr    s17, [%[addr_a2]] \r\n"
"ldr    s18, [%[addr_a3]] \r\n"
"ldr    s19, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+10*(kk+0))
: "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v20", "v21", "v22");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v4.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v5.4s,  v22.4s, v16.s[0]  \r\n"
"	fmul	v6.4s,  v20.4s, v17.s[0]  \r\n"
"	fmul	v7.4s,  v21.4s, v17.s[0]  \r\n"
"	fmul	v8.4s,  v22.4s, v17.s[0]  \r\n"
"	fmul	v9.4s,  v20.4s, v18.s[0]  \r\n"
"	fmul	v10.4s,  v21.4s, v18.s[0]  \r\n"
"	fmul	v11.4s,  v22.4s, v18.s[0]  \r\n"
"	fmul	v12.4s,  v20.4s, v19.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v19.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v19.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d15, [%[addr_a0]] \r\n"
"ldr    d16, [%[addr_a1]] \r\n"
"ldr    d17, [%[addr_a2]] \r\n"
"ldr    d18, [%[addr_a3]] \r\n"
"ldr    d19, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+10*kk+0*10),
[addr_b1] "r" (b+10*kk+1*10)
: "v20", "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v20", "v21", "v22", "v23", "v24", "v25");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v4.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v5.4s,  v22.4s, v16.s[0]  \r\n"
"	fmul	v6.4s,  v20.4s, v17.s[0]  \r\n"
"	fmul	v7.4s,  v21.4s, v17.s[0]  \r\n"
"	fmul	v8.4s,  v22.4s, v17.s[0]  \r\n"
"	fmul	v9.4s,  v20.4s, v18.s[0]  \r\n"
"	fmul	v10.4s,  v21.4s, v18.s[0]  \r\n"
"	fmul	v11.4s,  v22.4s, v18.s[0]  \r\n"
"	fmul	v12.4s,  v20.4s, v19.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v19.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v19.s[0]  \r\n"
"	fmla	v0.4s,  v23.4s, v15.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v15.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v15.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v6.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v7.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v8.4s,  v25.4s, v17.s[1]  \r\n"
"	fmla	v9.4s,  v23.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v24.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v25.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v23.4s, v19.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v19.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v19.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q15, [%[addr_a0]] \r\n"
"ldr    q16, [%[addr_a1]] \r\n"
"ldr    q17, [%[addr_a2]] \r\n"
"ldr    q18, [%[addr_a3]] \r\n"
"ldr    q19, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+10*kk+0*10),
[addr_b1] "r" (b+10*kk+1*10),
[addr_b2] "r" (b+10*kk+2*10)
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v4.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v5.4s,  v22.4s, v16.s[0]  \r\n"
"	fmul	v6.4s,  v20.4s, v17.s[0]  \r\n"
"	fmul	v7.4s,  v21.4s, v17.s[0]  \r\n"
"	fmul	v8.4s,  v22.4s, v17.s[0]  \r\n"
"	fmul	v9.4s,  v20.4s, v18.s[0]  \r\n"
"	fmul	v10.4s,  v21.4s, v18.s[0]  \r\n"
"	fmul	v11.4s,  v22.4s, v18.s[0]  \r\n"
"	fmul	v12.4s,  v20.4s, v19.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v19.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v19.s[0]  \r\n"
"	fmla	v0.4s,  v23.4s, v15.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v15.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v15.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v6.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v7.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v8.4s,  v25.4s, v17.s[1]  \r\n"
"	fmla	v9.4s,  v23.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v24.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v25.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v23.4s, v19.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v19.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v19.s[1]  \r\n"
"	fmla	v0.4s,  v26.4s, v15.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v15.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v15.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v27.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v28.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v7.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v8.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[2]  \r\n"
"	fmla	v12.4s,  v26.4s, v19.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v19.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v19.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
"dup     v4.4s, %w[zero] \r\n"
"dup     v5.4s, %w[zero] \r\n"
"dup     v6.4s, %w[zero] \r\n"
"dup     v7.4s, %w[zero] \r\n"
"dup     v8.4s, %w[zero] \r\n"
"dup     v9.4s, %w[zero] \r\n"
"dup     v10.4s, %w[zero] \r\n"
"dup     v11.4s, %w[zero] \r\n"
"dup     v12.4s, %w[zero] \r\n"
"dup     v13.4s, %w[zero] \r\n"
"dup     v14.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
asm volatile(
"ldr    q15, [%[addr_a0]] \r\n"
"ldr    q16, [%[addr_a1]] \r\n"
"ldr    q17, [%[addr_a2]] \r\n"
"ldr    q18, [%[addr_a3]] \r\n"
"ldr    q19, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+10*kk+0*10),
[addr_b1] "r" (b+10*kk+1*10),
[addr_b2] "r" (b+10*kk+2*10),
[addr_b3] "r" (b+10*kk+3*10)
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
asm volatile(
"	fmla	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmla	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmla	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmla	v3.4s,  v20.4s, v16.s[0]  \r\n"
"	fmla	v4.4s,  v21.4s, v16.s[0]  \r\n"
"	fmla	v5.4s,  v22.4s, v16.s[0]  \r\n"
"	fmla	v6.4s,  v20.4s, v17.s[0]  \r\n"
"	fmla	v7.4s,  v21.4s, v17.s[0]  \r\n"
"	fmla	v8.4s,  v22.4s, v17.s[0]  \r\n"
"	fmla	v9.4s,  v20.4s, v18.s[0]  \r\n"
"	fmla	v10.4s,  v21.4s, v18.s[0]  \r\n"
"	fmla	v11.4s,  v22.4s, v18.s[0]  \r\n"
"	fmla	v12.4s,  v20.4s, v19.s[0]  \r\n"
"	fmla	v13.4s,  v21.4s, v19.s[0]  \r\n"
"	fmla	v14.4s,  v22.4s, v19.s[0]  \r\n"
"	fmla	v0.4s,  v23.4s, v15.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v15.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v15.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v6.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v7.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v8.4s,  v25.4s, v17.s[1]  \r\n"
"	fmla	v9.4s,  v23.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v24.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v25.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v23.4s, v19.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v19.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v19.s[1]  \r\n"
"	fmla	v0.4s,  v26.4s, v15.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v15.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v15.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v27.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v28.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v7.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v8.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[2]  \r\n"
"	fmla	v12.4s,  v26.4s, v19.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v19.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v19.s[2]  \r\n"
"	fmla	v0.4s,  v29.4s, v15.s[3]  \r\n"
"	fmla	v1.4s,  v30.4s, v15.s[3]  \r\n"
"	fmla	v2.4s,  v31.4s, v15.s[3]  \r\n"
"	fmla	v3.4s,  v29.4s, v16.s[3]  \r\n"
"	fmla	v4.4s,  v30.4s, v16.s[3]  \r\n"
"	fmla	v5.4s,  v31.4s, v16.s[3]  \r\n"
"	fmla	v6.4s,  v29.4s, v17.s[3]  \r\n"
"	fmla	v7.4s,  v30.4s, v17.s[3]  \r\n"
"	fmla	v8.4s,  v31.4s, v17.s[3]  \r\n"
"	fmla	v9.4s,  v29.4s, v18.s[3]  \r\n"
"	fmla	v10.4s,  v30.4s, v18.s[3]  \r\n"
"	fmla	v11.4s,  v31.4s, v18.s[3]  \r\n"
"	fmla	v12.4s,  v29.4s, v19.s[3]  \r\n"
"	fmla	v13.4s,  v30.4s, v19.s[3]  \r\n"
"	fmla	v14.4s,  v31.4s, v19.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v15.4s, v16.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v15.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v15.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v15.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v15.s[1]       \r\n"
"fmul    v4.4s,  v4.4s,  v15.s[1]       \r\n"
"fmul    v5.4s,  v5.4s,  v15.s[1]       \r\n"
"fmul    v6.4s,  v6.4s,  v15.s[2]       \r\n"
"fmul    v7.4s,  v7.4s,  v15.s[2]       \r\n"
"fmul    v8.4s,  v8.4s,  v15.s[2]       \r\n"
"fmul    v9.4s,  v9.4s,  v15.s[3]       \r\n"
"fmul    v10.4s,  v10.4s,  v15.s[3]       \r\n"
"fmul    v11.4s,  v11.4s,  v15.s[3]       \r\n"
"fmul    v12.4s,  v12.4s,  v16.s[0]       \r\n"
"fmul    v13.4s,  v13.4s,  v16.s[0]       \r\n"
"fmul    v14.4s,  v14.4s,  v16.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v30.4s, v31.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_c0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_c1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_c2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_c3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v15.4s,  v30.s[0]       \r\n"
"fmla    v1.4s,  v16.4s,  v30.s[0]       \r\n"
"fmla    v2.4s,  v17.4s,  v30.s[0]       \r\n"
"fmla    v3.4s,  v18.4s,  v30.s[1]       \r\n"
"fmla    v4.4s,  v19.4s,  v30.s[1]       \r\n"
"fmla    v5.4s,  v20.4s,  v30.s[1]       \r\n"
"fmla    v6.4s,  v21.4s,  v30.s[2]       \r\n"
"fmla    v7.4s,  v22.4s,  v30.s[2]       \r\n"
"fmla    v8.4s,  v23.4s,  v30.s[2]       \r\n"
"fmla    v9.4s,  v24.4s,  v30.s[3]       \r\n"
"fmla    v10.4s,  v25.4s,  v30.s[3]       \r\n"
"fmla    v11.4s,  v26.4s,  v30.s[3]       \r\n"
"fmla    v12.4s,  v27.4s,  v31.s[0]       \r\n"
"fmla    v13.4s,  v28.4s,  v31.s[0]       \r\n"
"fmla    v14.4s,  v29.4s,  v31.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_itm0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_itm1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_itm2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_itm3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_itm4]] \r\n"
:
: [addr_itm0] "r" (itm+10*0),
[addr_itm1] "r" (itm+10*1),
[addr_itm2] "r" (itm+10*2),
[addr_itm3] "r" (itm+10*3),
[addr_itm4] "r" (itm+10*4)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_c0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_c1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_c2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_c3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29");
}
asm volatile(
"fadd     v0.4s, v15.4s,  v0.4s \r\n"
"fadd     v1.4s, v16.4s,  v1.4s \r\n"
"fadd     v2.4s, v17.4s,  v2.4s \r\n"
"fadd     v3.4s, v18.4s,  v3.4s \r\n"
"fadd     v4.4s, v19.4s,  v4.4s \r\n"
"fadd     v5.4s, v20.4s,  v5.4s \r\n"
"fadd     v6.4s, v21.4s,  v6.4s \r\n"
"fadd     v7.4s, v22.4s,  v7.4s \r\n"
"fadd     v8.4s, v23.4s,  v8.4s \r\n"
"fadd     v9.4s, v24.4s,  v9.4s \r\n"
"fadd     v10.4s, v25.4s,  v10.4s \r\n"
"fadd     v11.4s, v26.4s,  v11.4s \r\n"
"fadd     v12.4s, v27.4s,  v12.4s \r\n"
"fadd     v13.4s, v28.4s,  v13.4s \r\n"
"fadd     v14.4s, v29.4s,  v14.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v15.4s, v16.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v15.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v15.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v15.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v15.s[1]       \r\n"
"fmul    v4.4s,  v4.4s,  v15.s[1]       \r\n"
"fmul    v5.4s,  v5.4s,  v15.s[1]       \r\n"
"fmul    v6.4s,  v6.4s,  v15.s[2]       \r\n"
"fmul    v7.4s,  v7.4s,  v15.s[2]       \r\n"
"fmul    v8.4s,  v8.4s,  v15.s[2]       \r\n"
"fmul    v9.4s,  v9.4s,  v15.s[3]       \r\n"
"fmul    v10.4s,  v10.4s,  v15.s[3]       \r\n"
"fmul    v11.4s,  v11.4s,  v15.s[3]       \r\n"
"fmul    v12.4s,  v12.4s,  v16.s[0]       \r\n"
"fmul    v13.4s,  v13.4s,  v16.s[0]       \r\n"
"fmul    v14.4s,  v14.4s,  v16.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_c0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_c1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_c2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_c3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29");
asm volatile(
"fadd     v0.4s, v15.4s,  v0.4s \r\n"
"fadd     v1.4s, v16.4s,  v1.4s \r\n"
"fadd     v2.4s, v17.4s,  v2.4s \r\n"
"fadd     v3.4s, v18.4s,  v3.4s \r\n"
"fadd     v4.4s, v19.4s,  v4.4s \r\n"
"fadd     v5.4s, v20.4s,  v5.4s \r\n"
"fadd     v6.4s, v21.4s,  v6.4s \r\n"
"fadd     v7.4s, v22.4s,  v7.4s \r\n"
"fadd     v8.4s, v23.4s,  v8.4s \r\n"
"fadd     v9.4s, v24.4s,  v9.4s \r\n"
"fadd     v10.4s, v25.4s,  v10.4s \r\n"
"fadd     v11.4s, v26.4s,  v11.4s \r\n"
"fadd     v12.4s, v27.4s,  v12.4s \r\n"
"fadd     v13.4s, v28.4s,  v13.4s \r\n"
"fadd     v14.4s, v29.4s,  v14.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v30.4s, v31.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_c0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_c1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_c2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_c3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v15.4s,  v30.s[0]       \r\n"
"fmla    v1.4s,  v16.4s,  v30.s[0]       \r\n"
"fmla    v2.4s,  v17.4s,  v30.s[0]       \r\n"
"fmla    v3.4s,  v18.4s,  v30.s[1]       \r\n"
"fmla    v4.4s,  v19.4s,  v30.s[1]       \r\n"
"fmla    v5.4s,  v20.4s,  v30.s[1]       \r\n"
"fmla    v6.4s,  v21.4s,  v30.s[2]       \r\n"
"fmla    v7.4s,  v22.4s,  v30.s[2]       \r\n"
"fmla    v8.4s,  v23.4s,  v30.s[2]       \r\n"
"fmla    v9.4s,  v24.4s,  v30.s[3]       \r\n"
"fmla    v10.4s,  v25.4s,  v30.s[3]       \r\n"
"fmla    v11.4s,  v26.4s,  v30.s[3]       \r\n"
"fmla    v12.4s,  v27.4s,  v31.s[0]       \r\n"
"fmla    v13.4s,  v28.4s,  v31.s[0]       \r\n"
"fmla    v14.4s,  v29.4s,  v31.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v15.4s, v16.4s}, [%[addr_bias]] \r\n"
"dup    v17.4s, v15.s[0]               \r\n"
"dup    v18.4s, v15.s[1]               \r\n"
"dup    v19.4s, v15.s[2]               \r\n"
"dup    v20.4s, v15.s[3]               \r\n"
"dup    v21.4s, v16.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v17.4s \r\n"
"fadd     v1.4s, v1.4s,  v17.4s \r\n"
"fadd     v2.4s, v2.4s,  v17.4s \r\n"
"fadd     v3.4s, v3.4s,  v18.4s \r\n"
"fadd     v4.4s, v4.4s,  v18.4s \r\n"
"fadd     v5.4s, v5.4s,  v18.4s \r\n"
"fadd     v6.4s, v6.4s,  v19.4s \r\n"
"fadd     v7.4s, v7.4s,  v19.4s \r\n"
"fadd     v8.4s, v8.4s,  v19.4s \r\n"
"fadd     v9.4s, v9.4s,  v20.4s \r\n"
"fadd     v10.4s, v10.4s,  v20.4s \r\n"
"fadd     v11.4s, v11.4s,  v20.4s \r\n"
"fadd     v12.4s, v12.4s,  v21.4s \r\n"
"fadd     v13.4s, v13.4s,  v21.4s \r\n"
"fadd     v14.4s, v14.4s,  v21.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5", "v5", "v6", "v6", "v7", "v7", "v8", "v8", "v9", "v9", "v10", "v10", "v11", "v11", "v12", "v12", "v13", "v13", "v14", "v14", "v15", "v15", "v16", "v16", "v17", "v17", "v18", "v18", "v19", "v19", "v20", "v20", "v21");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v15.4s, w9             \r\n"
"fmax    v0.4s, v15.4s,  v0.4s \r\n"
"fmax    v1.4s, v15.4s,  v1.4s \r\n"
"fmax    v2.4s, v15.4s,  v2.4s \r\n"
"fmax    v3.4s, v15.4s,  v3.4s \r\n"
"fmax    v4.4s, v15.4s,  v4.4s \r\n"
"fmax    v5.4s, v15.4s,  v5.4s \r\n"
"fmax    v6.4s, v15.4s,  v6.4s \r\n"
"fmax    v7.4s, v15.4s,  v7.4s \r\n"
"fmax    v8.4s, v15.4s,  v8.4s \r\n"
"fmax    v9.4s, v15.4s,  v9.4s \r\n"
"fmax    v10.4s, v15.4s,  v10.4s \r\n"
"fmax    v11.4s, v15.4s,  v11.4s \r\n"
"fmax    v12.4s, v15.4s,  v12.4s \r\n"
"fmax    v13.4s, v15.4s,  v13.4s \r\n"
"fmax    v14.4s, v15.4s,  v14.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"str     q0, [%[addr_itm],   0] \r\n"
"str     q1, [%[addr_itm],   16] \r\n"
"str     d2, [%[addr_itm],   32] \r\n"
"str     q3, [%[addr_itm],   40] \r\n"
"str     q4, [%[addr_itm],   56] \r\n"
"str     d5, [%[addr_itm],   72] \r\n"
"str     q6, [%[addr_itm],   80] \r\n"
"str     q7, [%[addr_itm],   96] \r\n"
"str     d8, [%[addr_itm],   112] \r\n"
"str     q9, [%[addr_itm],   120] \r\n"
"str     q10, [%[addr_itm],   136] \r\n"
"str     d11, [%[addr_itm],   152] \r\n"
"str     q12, [%[addr_itm],   160] \r\n"
"str     q13, [%[addr_itm],   176] \r\n"
"str     d14, [%[addr_itm],   192] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"str     q0, [%[addr_c0],   0] \r\n"
"str     q1, [%[addr_c0],   16] \r\n"
"str     d2, [%[addr_c0],   32] \r\n"
"str     q3, [%[addr_c1],   0] \r\n"
"str     q4, [%[addr_c1],   16] \r\n"
"str     d5, [%[addr_c1],   32] \r\n"
"str     q6, [%[addr_c2],   0] \r\n"
"str     q7, [%[addr_c2],   16] \r\n"
"str     d8, [%[addr_c2],   32] \r\n"
"str     q9, [%[addr_c3],   0] \r\n"
"str     q10, [%[addr_c3],   16] \r\n"
"str     d11, [%[addr_c3],   32] \r\n"
"str     q12, [%[addr_c4],   0] \r\n"
"str     q13, [%[addr_c4],   16] \r\n"
"str     d14, [%[addr_c4],   32] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 5, 9, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v15", "v16");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+9*(kk+0))
: "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v20", "v21", "v22");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmul	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmul	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmul	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmul	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmul	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmul	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmul	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmul	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmul	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v15", "v16", "v17");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+9*kk+0*9),
[addr_b1] "r" (b+9*kk+1*9)
: "v20", "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v20", "v21", "v22", "v23", "v24", "v25");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmul	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmul	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmul	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmul	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmul	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmul	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmul	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmul	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmul	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v23.4s, v16.s[3]  \r\n"
"	fmla	v7.4s,  v24.4s, v16.s[3]  \r\n"
"	fmla	v8.4s,  v25.4s, v16.s[3]  \r\n"
"	fmla	v9.4s,  v23.4s, v17.s[0]  \r\n"
"	fmla	v10.4s,  v24.4s, v17.s[0]  \r\n"
"	fmla	v11.4s,  v25.4s, v17.s[0]  \r\n"
"	fmla	v12.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v17.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s, v18.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v15", "v16", "v17", "v18");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+9*kk+0*9),
[addr_b1] "r" (b+9*kk+1*9),
[addr_b2] "r" (b+9*kk+2*9)
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmul	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmul	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmul	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmul	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmul	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmul	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmul	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmul	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmul	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v23.4s, v16.s[3]  \r\n"
"	fmla	v7.4s,  v24.4s, v16.s[3]  \r\n"
"	fmla	v8.4s,  v25.4s, v16.s[3]  \r\n"
"	fmla	v9.4s,  v23.4s, v17.s[0]  \r\n"
"	fmla	v10.4s,  v24.4s, v17.s[0]  \r\n"
"	fmla	v11.4s,  v25.4s, v17.s[0]  \r\n"
"	fmla	v12.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v17.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v17.s[3]  \r\n"
"	fmla	v4.4s,  v27.4s, v17.s[3]  \r\n"
"	fmla	v5.4s,  v28.4s, v17.s[3]  \r\n"
"	fmla	v6.4s,  v26.4s, v18.s[0]  \r\n"
"	fmla	v7.4s,  v27.4s, v18.s[0]  \r\n"
"	fmla	v8.4s,  v28.4s, v18.s[0]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v18.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s, v18.4s}, [%[addr_a0]] \r\n"
"ld1    {v19.4s}, [%[addr_a1]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*16),
[addr_a1] "r" (a+5*kk+1*16)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+9*kk+0*9),
[addr_b1] "r" (b+9*kk+1*9),
[addr_b2] "r" (b+9*kk+2*9),
[addr_b3] "r" (b+9*kk+3*9)
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmul	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmul	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmul	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmul	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmul	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmul	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmul	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmul	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmul	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
else {
asm volatile(
"	fmla	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmla	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmla	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmla	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmla	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmla	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmla	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmla	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmla	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmla	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmla	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmla	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmla	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmla	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
kk+=4;
for(; kk<k; kk+=4) {
asm volatile(
"ld1    {v15.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*4)
: "v15");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+9*(kk+0))
: "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v20", "v21", "v22");
}
asm volatile(
"	fmla	v0.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v23.4s, v16.s[3]  \r\n"
"	fmla	v7.4s,  v24.4s, v16.s[3]  \r\n"
"	fmla	v8.4s,  v25.4s, v16.s[3]  \r\n"
"	fmla	v9.4s,  v23.4s, v17.s[0]  \r\n"
"	fmla	v10.4s,  v24.4s, v17.s[0]  \r\n"
"	fmla	v11.4s,  v25.4s, v17.s[0]  \r\n"
"	fmla	v12.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v17.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"ld1    {v16.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+1*4)
: "v16");
if constexpr(ReB) {
asm volatile(
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+9*(kk+1))
: "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v23", "v24", "v25");
}
asm volatile(
"	fmla	v0.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v17.s[3]  \r\n"
"	fmla	v4.4s,  v27.4s, v17.s[3]  \r\n"
"	fmla	v5.4s,  v28.4s, v17.s[3]  \r\n"
"	fmla	v6.4s,  v26.4s, v18.s[0]  \r\n"
"	fmla	v7.4s,  v27.4s, v18.s[0]  \r\n"
"	fmla	v8.4s,  v28.4s, v18.s[0]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v18.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"ld1    {v17.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+2*4)
: "v17");
if constexpr(ReB) {
asm volatile(
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+9*(kk+2))
: "v26", "v27", "v28");
}
else {
asm volatile(
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v26", "v27", "v28");
}
asm volatile(
"	fmla	v0.4s,  v29.4s, v18.s[3]  \r\n"
"	fmla	v1.4s,  v30.4s, v18.s[3]  \r\n"
"	fmla	v2.4s,  v31.4s, v18.s[3]  \r\n"
"	fmla	v3.4s,  v29.4s, v19.s[0]  \r\n"
"	fmla	v4.4s,  v30.4s, v19.s[0]  \r\n"
"	fmla	v5.4s,  v31.4s, v19.s[0]  \r\n"
"	fmla	v6.4s,  v29.4s, v19.s[1]  \r\n"
"	fmla	v7.4s,  v30.4s, v19.s[1]  \r\n"
"	fmla	v8.4s,  v31.4s, v19.s[1]  \r\n"
"	fmla	v9.4s,  v29.4s, v19.s[2]  \r\n"
"	fmla	v10.4s,  v30.4s, v19.s[2]  \r\n"
"	fmla	v11.4s,  v31.4s, v19.s[2]  \r\n"
"	fmla	v12.4s,  v29.4s, v19.s[3]  \r\n"
"	fmla	v13.4s,  v30.4s, v19.s[3]  \r\n"
"	fmla	v14.4s,  v31.4s, v19.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"ld1    {v18.4s, v19.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+3*4)
: "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+9*(kk+3))
: "v29", "v30", "v31");
}
else {
asm volatile(
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v29", "v30", "v31");
}
asm volatile(
"	fmla	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmla	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmla	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmla	v3.4s,  v20.4s, v15.s[1]  \r\n"
"	fmla	v4.4s,  v21.4s, v15.s[1]  \r\n"
"	fmla	v5.4s,  v22.4s, v15.s[1]  \r\n"
"	fmla	v6.4s,  v20.4s, v15.s[2]  \r\n"
"	fmla	v7.4s,  v21.4s, v15.s[2]  \r\n"
"	fmla	v8.4s,  v22.4s, v15.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v15.s[3]  \r\n"
"	fmla	v10.4s,  v21.4s, v15.s[3]  \r\n"
"	fmla	v11.4s,  v22.4s, v15.s[3]  \r\n"
"	fmla	v12.4s,  v20.4s, v16.s[0]  \r\n"
"	fmla	v13.4s,  v21.4s, v16.s[0]  \r\n"
"	fmla	v14.4s,  v22.4s, v16.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
asm volatile(
"	fmla	v0.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v23.4s, v16.s[3]  \r\n"
"	fmla	v7.4s,  v24.4s, v16.s[3]  \r\n"
"	fmla	v8.4s,  v25.4s, v16.s[3]  \r\n"
"	fmla	v9.4s,  v23.4s, v17.s[0]  \r\n"
"	fmla	v10.4s,  v24.4s, v17.s[0]  \r\n"
"	fmla	v11.4s,  v25.4s, v17.s[0]  \r\n"
"	fmla	v12.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v17.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v17.s[3]  \r\n"
"	fmla	v4.4s,  v27.4s, v17.s[3]  \r\n"
"	fmla	v5.4s,  v28.4s, v17.s[3]  \r\n"
"	fmla	v6.4s,  v26.4s, v18.s[0]  \r\n"
"	fmla	v7.4s,  v27.4s, v18.s[0]  \r\n"
"	fmla	v8.4s,  v28.4s, v18.s[0]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v18.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
asm volatile(
"	fmla	v0.4s,  v29.4s, v18.s[3]  \r\n"
"	fmla	v1.4s,  v30.4s, v18.s[3]  \r\n"
"	fmla	v2.4s,  v31.4s, v18.s[3]  \r\n"
"	fmla	v3.4s,  v29.4s, v19.s[0]  \r\n"
"	fmla	v4.4s,  v30.4s, v19.s[0]  \r\n"
"	fmla	v5.4s,  v31.4s, v19.s[0]  \r\n"
"	fmla	v6.4s,  v29.4s, v19.s[1]  \r\n"
"	fmla	v7.4s,  v30.4s, v19.s[1]  \r\n"
"	fmla	v8.4s,  v31.4s, v19.s[1]  \r\n"
"	fmla	v9.4s,  v29.4s, v19.s[2]  \r\n"
"	fmla	v10.4s,  v30.4s, v19.s[2]  \r\n"
"	fmla	v11.4s,  v31.4s, v19.s[2]  \r\n"
"	fmla	v12.4s,  v29.4s, v19.s[3]  \r\n"
"	fmla	v13.4s,  v30.4s, v19.s[3]  \r\n"
"	fmla	v14.4s,  v31.4s, v19.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s15, [%[addr_a0]] \r\n"
"ldr    s16, [%[addr_a1]] \r\n"
"ldr    s17, [%[addr_a2]] \r\n"
"ldr    s18, [%[addr_a3]] \r\n"
"ldr    s19, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+9*(kk+0))
: "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v20", "v21", "v22");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v4.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v5.4s,  v22.4s, v16.s[0]  \r\n"
"	fmul	v6.4s,  v20.4s, v17.s[0]  \r\n"
"	fmul	v7.4s,  v21.4s, v17.s[0]  \r\n"
"	fmul	v8.4s,  v22.4s, v17.s[0]  \r\n"
"	fmul	v9.4s,  v20.4s, v18.s[0]  \r\n"
"	fmul	v10.4s,  v21.4s, v18.s[0]  \r\n"
"	fmul	v11.4s,  v22.4s, v18.s[0]  \r\n"
"	fmul	v12.4s,  v20.4s, v19.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v19.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v19.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d15, [%[addr_a0]] \r\n"
"ldr    d16, [%[addr_a1]] \r\n"
"ldr    d17, [%[addr_a2]] \r\n"
"ldr    d18, [%[addr_a3]] \r\n"
"ldr    d19, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+9*kk+0*9),
[addr_b1] "r" (b+9*kk+1*9)
: "v20", "v21", "v22", "v23", "v24", "v25");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v20", "v21", "v22", "v23", "v24", "v25");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v4.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v5.4s,  v22.4s, v16.s[0]  \r\n"
"	fmul	v6.4s,  v20.4s, v17.s[0]  \r\n"
"	fmul	v7.4s,  v21.4s, v17.s[0]  \r\n"
"	fmul	v8.4s,  v22.4s, v17.s[0]  \r\n"
"	fmul	v9.4s,  v20.4s, v18.s[0]  \r\n"
"	fmul	v10.4s,  v21.4s, v18.s[0]  \r\n"
"	fmul	v11.4s,  v22.4s, v18.s[0]  \r\n"
"	fmul	v12.4s,  v20.4s, v19.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v19.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v19.s[0]  \r\n"
"	fmla	v0.4s,  v23.4s, v15.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v15.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v15.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v6.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v7.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v8.4s,  v25.4s, v17.s[1]  \r\n"
"	fmla	v9.4s,  v23.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v24.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v25.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v23.4s, v19.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v19.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v19.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q15, [%[addr_a0]] \r\n"
"ldr    q16, [%[addr_a1]] \r\n"
"ldr    q17, [%[addr_a2]] \r\n"
"ldr    q18, [%[addr_a3]] \r\n"
"ldr    q19, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+9*kk+0*9),
[addr_b1] "r" (b+9*kk+1*9),
[addr_b2] "r" (b+9*kk+2*9)
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28");
}
asm volatile(
"	fmul	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmul	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmul	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmul	v3.4s,  v20.4s, v16.s[0]  \r\n"
"	fmul	v4.4s,  v21.4s, v16.s[0]  \r\n"
"	fmul	v5.4s,  v22.4s, v16.s[0]  \r\n"
"	fmul	v6.4s,  v20.4s, v17.s[0]  \r\n"
"	fmul	v7.4s,  v21.4s, v17.s[0]  \r\n"
"	fmul	v8.4s,  v22.4s, v17.s[0]  \r\n"
"	fmul	v9.4s,  v20.4s, v18.s[0]  \r\n"
"	fmul	v10.4s,  v21.4s, v18.s[0]  \r\n"
"	fmul	v11.4s,  v22.4s, v18.s[0]  \r\n"
"	fmul	v12.4s,  v20.4s, v19.s[0]  \r\n"
"	fmul	v13.4s,  v21.4s, v19.s[0]  \r\n"
"	fmul	v14.4s,  v22.4s, v19.s[0]  \r\n"
"	fmla	v0.4s,  v23.4s, v15.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v15.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v15.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v6.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v7.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v8.4s,  v25.4s, v17.s[1]  \r\n"
"	fmla	v9.4s,  v23.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v24.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v25.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v23.4s, v19.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v19.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v19.s[1]  \r\n"
"	fmla	v0.4s,  v26.4s, v15.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v15.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v15.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v27.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v28.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v7.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v8.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[2]  \r\n"
"	fmla	v12.4s,  v26.4s, v19.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v19.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v19.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
"dup     v4.4s, %w[zero] \r\n"
"dup     v5.4s, %w[zero] \r\n"
"dup     v6.4s, %w[zero] \r\n"
"dup     v7.4s, %w[zero] \r\n"
"dup     v8.4s, %w[zero] \r\n"
"dup     v9.4s, %w[zero] \r\n"
"dup     v10.4s, %w[zero] \r\n"
"dup     v11.4s, %w[zero] \r\n"
"dup     v12.4s, %w[zero] \r\n"
"dup     v13.4s, %w[zero] \r\n"
"dup     v14.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
asm volatile(
"ldr    q15, [%[addr_a0]] \r\n"
"ldr    q16, [%[addr_a1]] \r\n"
"ldr    q17, [%[addr_a2]] \r\n"
"ldr    q18, [%[addr_a3]] \r\n"
"ldr    q19, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v15", "v16", "v17", "v18", "v19");
if constexpr(ReB) {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+9*kk+0*9),
[addr_b1] "r" (b+9*kk+1*9),
[addr_b2] "r" (b+9*kk+2*9),
[addr_b3] "r" (b+9*kk+3*9)
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
else {
asm volatile(
"ld1    {v20.4s, v21.4s, v22.4s}, [%[addr_b0]] \r\n"
"ld1    {v23.4s, v24.4s, v25.4s}, [%[addr_b1]] \r\n"
"ld1    {v26.4s, v27.4s, v28.4s}, [%[addr_b2]] \r\n"
"ld1    {v29.4s, v30.4s, v31.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
asm volatile(
"	fmla	v0.4s,  v20.4s, v15.s[0]  \r\n"
"	fmla	v1.4s,  v21.4s, v15.s[0]  \r\n"
"	fmla	v2.4s,  v22.4s, v15.s[0]  \r\n"
"	fmla	v3.4s,  v20.4s, v16.s[0]  \r\n"
"	fmla	v4.4s,  v21.4s, v16.s[0]  \r\n"
"	fmla	v5.4s,  v22.4s, v16.s[0]  \r\n"
"	fmla	v6.4s,  v20.4s, v17.s[0]  \r\n"
"	fmla	v7.4s,  v21.4s, v17.s[0]  \r\n"
"	fmla	v8.4s,  v22.4s, v17.s[0]  \r\n"
"	fmla	v9.4s,  v20.4s, v18.s[0]  \r\n"
"	fmla	v10.4s,  v21.4s, v18.s[0]  \r\n"
"	fmla	v11.4s,  v22.4s, v18.s[0]  \r\n"
"	fmla	v12.4s,  v20.4s, v19.s[0]  \r\n"
"	fmla	v13.4s,  v21.4s, v19.s[0]  \r\n"
"	fmla	v14.4s,  v22.4s, v19.s[0]  \r\n"
"	fmla	v0.4s,  v23.4s, v15.s[1]  \r\n"
"	fmla	v1.4s,  v24.4s, v15.s[1]  \r\n"
"	fmla	v2.4s,  v25.4s, v15.s[1]  \r\n"
"	fmla	v3.4s,  v23.4s, v16.s[1]  \r\n"
"	fmla	v4.4s,  v24.4s, v16.s[1]  \r\n"
"	fmla	v5.4s,  v25.4s, v16.s[1]  \r\n"
"	fmla	v6.4s,  v23.4s, v17.s[1]  \r\n"
"	fmla	v7.4s,  v24.4s, v17.s[1]  \r\n"
"	fmla	v8.4s,  v25.4s, v17.s[1]  \r\n"
"	fmla	v9.4s,  v23.4s, v18.s[1]  \r\n"
"	fmla	v10.4s,  v24.4s, v18.s[1]  \r\n"
"	fmla	v11.4s,  v25.4s, v18.s[1]  \r\n"
"	fmla	v12.4s,  v23.4s, v19.s[1]  \r\n"
"	fmla	v13.4s,  v24.4s, v19.s[1]  \r\n"
"	fmla	v14.4s,  v25.4s, v19.s[1]  \r\n"
"	fmla	v0.4s,  v26.4s, v15.s[2]  \r\n"
"	fmla	v1.4s,  v27.4s, v15.s[2]  \r\n"
"	fmla	v2.4s,  v28.4s, v15.s[2]  \r\n"
"	fmla	v3.4s,  v26.4s, v16.s[2]  \r\n"
"	fmla	v4.4s,  v27.4s, v16.s[2]  \r\n"
"	fmla	v5.4s,  v28.4s, v16.s[2]  \r\n"
"	fmla	v6.4s,  v26.4s, v17.s[2]  \r\n"
"	fmla	v7.4s,  v27.4s, v17.s[2]  \r\n"
"	fmla	v8.4s,  v28.4s, v17.s[2]  \r\n"
"	fmla	v9.4s,  v26.4s, v18.s[2]  \r\n"
"	fmla	v10.4s,  v27.4s, v18.s[2]  \r\n"
"	fmla	v11.4s,  v28.4s, v18.s[2]  \r\n"
"	fmla	v12.4s,  v26.4s, v19.s[2]  \r\n"
"	fmla	v13.4s,  v27.4s, v19.s[2]  \r\n"
"	fmla	v14.4s,  v28.4s, v19.s[2]  \r\n"
"	fmla	v0.4s,  v29.4s, v15.s[3]  \r\n"
"	fmla	v1.4s,  v30.4s, v15.s[3]  \r\n"
"	fmla	v2.4s,  v31.4s, v15.s[3]  \r\n"
"	fmla	v3.4s,  v29.4s, v16.s[3]  \r\n"
"	fmla	v4.4s,  v30.4s, v16.s[3]  \r\n"
"	fmla	v5.4s,  v31.4s, v16.s[3]  \r\n"
"	fmla	v6.4s,  v29.4s, v17.s[3]  \r\n"
"	fmla	v7.4s,  v30.4s, v17.s[3]  \r\n"
"	fmla	v8.4s,  v31.4s, v17.s[3]  \r\n"
"	fmla	v9.4s,  v29.4s, v18.s[3]  \r\n"
"	fmla	v10.4s,  v30.4s, v18.s[3]  \r\n"
"	fmla	v11.4s,  v31.4s, v18.s[3]  \r\n"
"	fmla	v12.4s,  v29.4s, v19.s[3]  \r\n"
"	fmla	v13.4s,  v30.4s, v19.s[3]  \r\n"
"	fmla	v14.4s,  v31.4s, v19.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v15.4s, v16.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v15.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v15.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v15.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v15.s[1]       \r\n"
"fmul    v4.4s,  v4.4s,  v15.s[1]       \r\n"
"fmul    v5.4s,  v5.4s,  v15.s[1]       \r\n"
"fmul    v6.4s,  v6.4s,  v15.s[2]       \r\n"
"fmul    v7.4s,  v7.4s,  v15.s[2]       \r\n"
"fmul    v8.4s,  v8.4s,  v15.s[2]       \r\n"
"fmul    v9.4s,  v9.4s,  v15.s[3]       \r\n"
"fmul    v10.4s,  v10.4s,  v15.s[3]       \r\n"
"fmul    v11.4s,  v11.4s,  v15.s[3]       \r\n"
"fmul    v12.4s,  v12.4s,  v16.s[0]       \r\n"
"fmul    v13.4s,  v13.4s,  v16.s[0]       \r\n"
"fmul    v14.4s,  v14.4s,  v16.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v30.4s, v31.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_c0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_c1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_c2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_c3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v15.4s,  v30.s[0]       \r\n"
"fmla    v1.4s,  v16.4s,  v30.s[0]       \r\n"
"fmla    v2.4s,  v17.4s,  v30.s[0]       \r\n"
"fmla    v3.4s,  v18.4s,  v30.s[1]       \r\n"
"fmla    v4.4s,  v19.4s,  v30.s[1]       \r\n"
"fmla    v5.4s,  v20.4s,  v30.s[1]       \r\n"
"fmla    v6.4s,  v21.4s,  v30.s[2]       \r\n"
"fmla    v7.4s,  v22.4s,  v30.s[2]       \r\n"
"fmla    v8.4s,  v23.4s,  v30.s[2]       \r\n"
"fmla    v9.4s,  v24.4s,  v30.s[3]       \r\n"
"fmla    v10.4s,  v25.4s,  v30.s[3]       \r\n"
"fmla    v11.4s,  v26.4s,  v30.s[3]       \r\n"
"fmla    v12.4s,  v27.4s,  v31.s[0]       \r\n"
"fmla    v13.4s,  v28.4s,  v31.s[0]       \r\n"
"fmla    v14.4s,  v29.4s,  v31.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_itm0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_itm1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_itm2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_itm3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_itm4]] \r\n"
:
: [addr_itm0] "r" (itm+9*0),
[addr_itm1] "r" (itm+9*1),
[addr_itm2] "r" (itm+9*2),
[addr_itm3] "r" (itm+9*3),
[addr_itm4] "r" (itm+9*4)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_c0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_c1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_c2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_c3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29");
}
asm volatile(
"fadd     v0.4s, v15.4s,  v0.4s \r\n"
"fadd     v1.4s, v16.4s,  v1.4s \r\n"
"fadd     v2.4s, v17.4s,  v2.4s \r\n"
"fadd     v3.4s, v18.4s,  v3.4s \r\n"
"fadd     v4.4s, v19.4s,  v4.4s \r\n"
"fadd     v5.4s, v20.4s,  v5.4s \r\n"
"fadd     v6.4s, v21.4s,  v6.4s \r\n"
"fadd     v7.4s, v22.4s,  v7.4s \r\n"
"fadd     v8.4s, v23.4s,  v8.4s \r\n"
"fadd     v9.4s, v24.4s,  v9.4s \r\n"
"fadd     v10.4s, v25.4s,  v10.4s \r\n"
"fadd     v11.4s, v26.4s,  v11.4s \r\n"
"fadd     v12.4s, v27.4s,  v12.4s \r\n"
"fadd     v13.4s, v28.4s,  v13.4s \r\n"
"fadd     v14.4s, v29.4s,  v14.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v15.4s, v16.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v15.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v15.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v15.s[0]       \r\n"
"fmul    v3.4s,  v3.4s,  v15.s[1]       \r\n"
"fmul    v4.4s,  v4.4s,  v15.s[1]       \r\n"
"fmul    v5.4s,  v5.4s,  v15.s[1]       \r\n"
"fmul    v6.4s,  v6.4s,  v15.s[2]       \r\n"
"fmul    v7.4s,  v7.4s,  v15.s[2]       \r\n"
"fmul    v8.4s,  v8.4s,  v15.s[2]       \r\n"
"fmul    v9.4s,  v9.4s,  v15.s[3]       \r\n"
"fmul    v10.4s,  v10.4s,  v15.s[3]       \r\n"
"fmul    v11.4s,  v11.4s,  v15.s[3]       \r\n"
"fmul    v12.4s,  v12.4s,  v16.s[0]       \r\n"
"fmul    v13.4s,  v13.4s,  v16.s[0]       \r\n"
"fmul    v14.4s,  v14.4s,  v16.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_c0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_c1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_c2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_c3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29");
asm volatile(
"fadd     v0.4s, v15.4s,  v0.4s \r\n"
"fadd     v1.4s, v16.4s,  v1.4s \r\n"
"fadd     v2.4s, v17.4s,  v2.4s \r\n"
"fadd     v3.4s, v18.4s,  v3.4s \r\n"
"fadd     v4.4s, v19.4s,  v4.4s \r\n"
"fadd     v5.4s, v20.4s,  v5.4s \r\n"
"fadd     v6.4s, v21.4s,  v6.4s \r\n"
"fadd     v7.4s, v22.4s,  v7.4s \r\n"
"fadd     v8.4s, v23.4s,  v8.4s \r\n"
"fadd     v9.4s, v24.4s,  v9.4s \r\n"
"fadd     v10.4s, v25.4s,  v10.4s \r\n"
"fadd     v11.4s, v26.4s,  v11.4s \r\n"
"fadd     v12.4s, v27.4s,  v12.4s \r\n"
"fadd     v13.4s, v28.4s,  v13.4s \r\n"
"fadd     v14.4s, v29.4s,  v14.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v30.4s, v31.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v15.4s, v16.4s, v17.4s}, [%[addr_c0]] \r\n"
"ld1    {v18.4s, v19.4s, v20.4s}, [%[addr_c1]] \r\n"
"ld1    {v21.4s, v22.4s, v23.4s}, [%[addr_c2]] \r\n"
"ld1    {v24.4s, v25.4s, v26.4s}, [%[addr_c3]] \r\n"
"ld1    {v27.4s, v28.4s, v29.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v15.4s,  v30.s[0]       \r\n"
"fmla    v1.4s,  v16.4s,  v30.s[0]       \r\n"
"fmla    v2.4s,  v17.4s,  v30.s[0]       \r\n"
"fmla    v3.4s,  v18.4s,  v30.s[1]       \r\n"
"fmla    v4.4s,  v19.4s,  v30.s[1]       \r\n"
"fmla    v5.4s,  v20.4s,  v30.s[1]       \r\n"
"fmla    v6.4s,  v21.4s,  v30.s[2]       \r\n"
"fmla    v7.4s,  v22.4s,  v30.s[2]       \r\n"
"fmla    v8.4s,  v23.4s,  v30.s[2]       \r\n"
"fmla    v9.4s,  v24.4s,  v30.s[3]       \r\n"
"fmla    v10.4s,  v25.4s,  v30.s[3]       \r\n"
"fmla    v11.4s,  v26.4s,  v30.s[3]       \r\n"
"fmla    v12.4s,  v27.4s,  v31.s[0]       \r\n"
"fmla    v13.4s,  v28.4s,  v31.s[0]       \r\n"
"fmla    v14.4s,  v29.4s,  v31.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22", "v23", "v24", "v25", "v26", "v27", "v28", "v29", "v30", "v31");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v15.4s, v16.4s}, [%[addr_bias]] \r\n"
"dup    v17.4s, v15.s[0]               \r\n"
"dup    v18.4s, v15.s[1]               \r\n"
"dup    v19.4s, v15.s[2]               \r\n"
"dup    v20.4s, v15.s[3]               \r\n"
"dup    v21.4s, v16.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v17.4s \r\n"
"fadd     v1.4s, v1.4s,  v17.4s \r\n"
"fadd     v2.4s, v2.4s,  v17.4s \r\n"
"fadd     v3.4s, v3.4s,  v18.4s \r\n"
"fadd     v4.4s, v4.4s,  v18.4s \r\n"
"fadd     v5.4s, v5.4s,  v18.4s \r\n"
"fadd     v6.4s, v6.4s,  v19.4s \r\n"
"fadd     v7.4s, v7.4s,  v19.4s \r\n"
"fadd     v8.4s, v8.4s,  v19.4s \r\n"
"fadd     v9.4s, v9.4s,  v20.4s \r\n"
"fadd     v10.4s, v10.4s,  v20.4s \r\n"
"fadd     v11.4s, v11.4s,  v20.4s \r\n"
"fadd     v12.4s, v12.4s,  v21.4s \r\n"
"fadd     v13.4s, v13.4s,  v21.4s \r\n"
"fadd     v14.4s, v14.4s,  v21.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5", "v5", "v6", "v6", "v7", "v7", "v8", "v8", "v9", "v9", "v10", "v10", "v11", "v11", "v12", "v12", "v13", "v13", "v14", "v14", "v15", "v15", "v16", "v16", "v17", "v17", "v18", "v18", "v19", "v19", "v20", "v20", "v21");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v15.4s, w9             \r\n"
"fmax    v0.4s, v15.4s,  v0.4s \r\n"
"fmax    v1.4s, v15.4s,  v1.4s \r\n"
"fmax    v2.4s, v15.4s,  v2.4s \r\n"
"fmax    v3.4s, v15.4s,  v3.4s \r\n"
"fmax    v4.4s, v15.4s,  v4.4s \r\n"
"fmax    v5.4s, v15.4s,  v5.4s \r\n"
"fmax    v6.4s, v15.4s,  v6.4s \r\n"
"fmax    v7.4s, v15.4s,  v7.4s \r\n"
"fmax    v8.4s, v15.4s,  v8.4s \r\n"
"fmax    v9.4s, v15.4s,  v9.4s \r\n"
"fmax    v10.4s, v15.4s,  v10.4s \r\n"
"fmax    v11.4s, v15.4s,  v11.4s \r\n"
"fmax    v12.4s, v15.4s,  v12.4s \r\n"
"fmax    v13.4s, v15.4s,  v13.4s \r\n"
"fmax    v14.4s, v15.4s,  v14.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"str     q0, [%[addr_itm],   0] \r\n"
"str     q1, [%[addr_itm],   16] \r\n"
"str     s2, [%[addr_itm],   32] \r\n"
"str     q3, [%[addr_itm],   36] \r\n"
"str     q4, [%[addr_itm],   52] \r\n"
"str     s5, [%[addr_itm],   68] \r\n"
"str     q6, [%[addr_itm],   72] \r\n"
"str     q7, [%[addr_itm],   88] \r\n"
"str     s8, [%[addr_itm],   104] \r\n"
"str     q9, [%[addr_itm],   108] \r\n"
"str     q10, [%[addr_itm],   124] \r\n"
"str     s11, [%[addr_itm],   140] \r\n"
"str     q12, [%[addr_itm],   144] \r\n"
"str     q13, [%[addr_itm],   160] \r\n"
"str     s14, [%[addr_itm],   176] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"str     q0, [%[addr_c0],   0] \r\n"
"str     q1, [%[addr_c0],   16] \r\n"
"str     s2, [%[addr_c0],   32] \r\n"
"str     q3, [%[addr_c1],   0] \r\n"
"str     q4, [%[addr_c1],   16] \r\n"
"str     s5, [%[addr_c1],   32] \r\n"
"str     q6, [%[addr_c2],   0] \r\n"
"str     q7, [%[addr_c2],   16] \r\n"
"str     s8, [%[addr_c2],   32] \r\n"
"str     q9, [%[addr_c3],   0] \r\n"
"str     q10, [%[addr_c3],   16] \r\n"
"str     s11, [%[addr_c3],   32] \r\n"
"str     q12, [%[addr_c4],   0] \r\n"
"str     q13, [%[addr_c4],   16] \r\n"
"str     s14, [%[addr_c4],   32] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 5, 8, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v10.4s, v11.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v10", "v11");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+8*(kk+0))
: "v15", "v16");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v15", "v16");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmul	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmul	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmul	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmul	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmul	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmul	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v10", "v11", "v12");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+8*kk+0*8),
[addr_b1] "r" (b+8*kk+1*8)
: "v15", "v16", "v17", "v18");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v15", "v16", "v17", "v18");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmul	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmul	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmul	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmul	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmul	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmul	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v17.4s, v11.s[3]  \r\n"
"	fmla	v5.4s,  v18.4s, v11.s[3]  \r\n"
"	fmla	v6.4s,  v17.4s, v12.s[0]  \r\n"
"	fmla	v7.4s,  v18.4s, v12.s[0]  \r\n"
"	fmla	v8.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v12.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s, v13.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v10", "v11", "v12", "v13");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+8*kk+0*8),
[addr_b1] "r" (b+8*kk+1*8),
[addr_b2] "r" (b+8*kk+2*8)
: "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmul	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmul	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmul	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmul	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmul	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmul	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v17.4s, v11.s[3]  \r\n"
"	fmla	v5.4s,  v18.4s, v11.s[3]  \r\n"
"	fmla	v6.4s,  v17.4s, v12.s[0]  \r\n"
"	fmla	v7.4s,  v18.4s, v12.s[0]  \r\n"
"	fmla	v8.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v12.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v12.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v12.s[3]  \r\n"
"	fmla	v4.4s,  v19.4s, v13.s[0]  \r\n"
"	fmla	v5.4s,  v20.4s, v13.s[0]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v13.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s, v13.4s}, [%[addr_a0]] \r\n"
"ld1    {v14.4s}, [%[addr_a1]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*16),
[addr_a1] "r" (a+5*kk+1*16)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
"ld1    {v21.4s, v22.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+8*kk+0*8),
[addr_b1] "r" (b+8*kk+1*8),
[addr_b2] "r" (b+8*kk+2*8),
[addr_b3] "r" (b+8*kk+3*8)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
"ld1    {v21.4s, v22.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmul	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmul	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmul	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmul	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmul	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmul	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"	fmla	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmla	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmla	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmla	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmla	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmla	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmla	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmla	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmla	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
kk+=4;
for(; kk<k; kk+=4) {
asm volatile(
"ld1    {v10.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*4)
: "v10");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+8*(kk+0))
: "v15", "v16");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v15", "v16");
}
asm volatile(
"	fmla	v0.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v17.4s, v11.s[3]  \r\n"
"	fmla	v5.4s,  v18.4s, v11.s[3]  \r\n"
"	fmla	v6.4s,  v17.4s, v12.s[0]  \r\n"
"	fmla	v7.4s,  v18.4s, v12.s[0]  \r\n"
"	fmla	v8.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v12.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"ld1    {v11.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+1*4)
: "v11");
if constexpr(ReB) {
asm volatile(
"ld1    {v17.4s, v18.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+8*(kk+1))
: "v17", "v18");
}
else {
asm volatile(
"ld1    {v17.4s, v18.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v17", "v18");
}
asm volatile(
"	fmla	v0.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v12.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v12.s[3]  \r\n"
"	fmla	v4.4s,  v19.4s, v13.s[0]  \r\n"
"	fmla	v5.4s,  v20.4s, v13.s[0]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v13.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"ld1    {v12.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+2*4)
: "v12");
if constexpr(ReB) {
asm volatile(
"ld1    {v19.4s, v20.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+8*(kk+2))
: "v19", "v20");
}
else {
asm volatile(
"ld1    {v19.4s, v20.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v19", "v20");
}
asm volatile(
"	fmla	v0.4s,  v21.4s, v13.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v13.s[3]  \r\n"
"	fmla	v2.4s,  v21.4s, v14.s[0]  \r\n"
"	fmla	v3.4s,  v22.4s, v14.s[0]  \r\n"
"	fmla	v4.4s,  v21.4s, v14.s[1]  \r\n"
"	fmla	v5.4s,  v22.4s, v14.s[1]  \r\n"
"	fmla	v6.4s,  v21.4s, v14.s[2]  \r\n"
"	fmla	v7.4s,  v22.4s, v14.s[2]  \r\n"
"	fmla	v8.4s,  v21.4s, v14.s[3]  \r\n"
"	fmla	v9.4s,  v22.4s, v14.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"ld1    {v13.4s, v14.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+3*4)
: "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+8*(kk+3))
: "v21", "v22");
}
else {
asm volatile(
"ld1    {v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v21", "v22");
}
asm volatile(
"	fmla	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmla	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmla	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmla	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmla	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmla	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmla	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmla	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmla	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"	fmla	v0.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v17.4s, v11.s[3]  \r\n"
"	fmla	v5.4s,  v18.4s, v11.s[3]  \r\n"
"	fmla	v6.4s,  v17.4s, v12.s[0]  \r\n"
"	fmla	v7.4s,  v18.4s, v12.s[0]  \r\n"
"	fmla	v8.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v12.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v12.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v12.s[3]  \r\n"
"	fmla	v4.4s,  v19.4s, v13.s[0]  \r\n"
"	fmla	v5.4s,  v20.4s, v13.s[0]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v13.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v21.4s, v13.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v13.s[3]  \r\n"
"	fmla	v2.4s,  v21.4s, v14.s[0]  \r\n"
"	fmla	v3.4s,  v22.4s, v14.s[0]  \r\n"
"	fmla	v4.4s,  v21.4s, v14.s[1]  \r\n"
"	fmla	v5.4s,  v22.4s, v14.s[1]  \r\n"
"	fmla	v6.4s,  v21.4s, v14.s[2]  \r\n"
"	fmla	v7.4s,  v22.4s, v14.s[2]  \r\n"
"	fmla	v8.4s,  v21.4s, v14.s[3]  \r\n"
"	fmla	v9.4s,  v22.4s, v14.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s10, [%[addr_a0]] \r\n"
"ldr    s11, [%[addr_a1]] \r\n"
"ldr    s12, [%[addr_a2]] \r\n"
"ldr    s13, [%[addr_a3]] \r\n"
"ldr    s14, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+8*(kk+0))
: "v15", "v16");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v15", "v16");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v3.4s,  v16.4s, v11.s[0]  \r\n"
"	fmul	v4.4s,  v15.4s, v12.s[0]  \r\n"
"	fmul	v5.4s,  v16.4s, v12.s[0]  \r\n"
"	fmul	v6.4s,  v15.4s, v13.s[0]  \r\n"
"	fmul	v7.4s,  v16.4s, v13.s[0]  \r\n"
"	fmul	v8.4s,  v15.4s, v14.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v14.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d10, [%[addr_a0]] \r\n"
"ldr    d11, [%[addr_a1]] \r\n"
"ldr    d12, [%[addr_a2]] \r\n"
"ldr    d13, [%[addr_a3]] \r\n"
"ldr    d14, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+8*kk+0*8),
[addr_b1] "r" (b+8*kk+1*8)
: "v15", "v16", "v17", "v18");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v15", "v16", "v17", "v18");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v3.4s,  v16.4s, v11.s[0]  \r\n"
"	fmul	v4.4s,  v15.4s, v12.s[0]  \r\n"
"	fmul	v5.4s,  v16.4s, v12.s[0]  \r\n"
"	fmul	v6.4s,  v15.4s, v13.s[0]  \r\n"
"	fmul	v7.4s,  v16.4s, v13.s[0]  \r\n"
"	fmul	v8.4s,  v15.4s, v14.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v14.s[0]  \r\n"
"	fmla	v0.4s,  v17.4s, v10.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v10.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v4.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v5.4s,  v18.4s, v12.s[1]  \r\n"
"	fmla	v6.4s,  v17.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v18.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v17.4s, v14.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v14.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q10, [%[addr_a0]] \r\n"
"ldr    q11, [%[addr_a1]] \r\n"
"ldr    q12, [%[addr_a2]] \r\n"
"ldr    q13, [%[addr_a3]] \r\n"
"ldr    q14, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+8*kk+0*8),
[addr_b1] "r" (b+8*kk+1*8),
[addr_b2] "r" (b+8*kk+2*8)
: "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v3.4s,  v16.4s, v11.s[0]  \r\n"
"	fmul	v4.4s,  v15.4s, v12.s[0]  \r\n"
"	fmul	v5.4s,  v16.4s, v12.s[0]  \r\n"
"	fmul	v6.4s,  v15.4s, v13.s[0]  \r\n"
"	fmul	v7.4s,  v16.4s, v13.s[0]  \r\n"
"	fmul	v8.4s,  v15.4s, v14.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v14.s[0]  \r\n"
"	fmla	v0.4s,  v17.4s, v10.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v10.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v4.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v5.4s,  v18.4s, v12.s[1]  \r\n"
"	fmla	v6.4s,  v17.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v18.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v17.4s, v14.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v14.s[1]  \r\n"
"	fmla	v0.4s,  v19.4s, v10.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v10.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v20.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v5.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[2]  \r\n"
"	fmla	v8.4s,  v19.4s, v14.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v14.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
"dup     v4.4s, %w[zero] \r\n"
"dup     v5.4s, %w[zero] \r\n"
"dup     v6.4s, %w[zero] \r\n"
"dup     v7.4s, %w[zero] \r\n"
"dup     v8.4s, %w[zero] \r\n"
"dup     v9.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"ldr    q10, [%[addr_a0]] \r\n"
"ldr    q11, [%[addr_a1]] \r\n"
"ldr    q12, [%[addr_a2]] \r\n"
"ldr    q13, [%[addr_a3]] \r\n"
"ldr    q14, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
"ld1    {v21.4s, v22.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+8*kk+0*8),
[addr_b1] "r" (b+8*kk+1*8),
[addr_b2] "r" (b+8*kk+2*8),
[addr_b3] "r" (b+8*kk+3*8)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
"ld1    {v21.4s, v22.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22");
}
asm volatile(
"	fmla	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmla	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmla	v2.4s,  v15.4s, v11.s[0]  \r\n"
"	fmla	v3.4s,  v16.4s, v11.s[0]  \r\n"
"	fmla	v4.4s,  v15.4s, v12.s[0]  \r\n"
"	fmla	v5.4s,  v16.4s, v12.s[0]  \r\n"
"	fmla	v6.4s,  v15.4s, v13.s[0]  \r\n"
"	fmla	v7.4s,  v16.4s, v13.s[0]  \r\n"
"	fmla	v8.4s,  v15.4s, v14.s[0]  \r\n"
"	fmla	v9.4s,  v16.4s, v14.s[0]  \r\n"
"	fmla	v0.4s,  v17.4s, v10.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v10.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v4.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v5.4s,  v18.4s, v12.s[1]  \r\n"
"	fmla	v6.4s,  v17.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v18.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v17.4s, v14.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v14.s[1]  \r\n"
"	fmla	v0.4s,  v19.4s, v10.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v10.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v20.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v5.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[2]  \r\n"
"	fmla	v8.4s,  v19.4s, v14.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v14.s[2]  \r\n"
"	fmla	v0.4s,  v21.4s, v10.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v10.s[3]  \r\n"
"	fmla	v2.4s,  v21.4s, v11.s[3]  \r\n"
"	fmla	v3.4s,  v22.4s, v11.s[3]  \r\n"
"	fmla	v4.4s,  v21.4s, v12.s[3]  \r\n"
"	fmla	v5.4s,  v22.4s, v12.s[3]  \r\n"
"	fmla	v6.4s,  v21.4s, v13.s[3]  \r\n"
"	fmla	v7.4s,  v22.4s, v13.s[3]  \r\n"
"	fmla	v8.4s,  v21.4s, v14.s[3]  \r\n"
"	fmla	v9.4s,  v22.4s, v14.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v10.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v10.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v10.s[1]       \r\n"
"fmul    v3.4s,  v3.4s,  v10.s[1]       \r\n"
"fmul    v4.4s,  v4.4s,  v10.s[2]       \r\n"
"fmul    v5.4s,  v5.4s,  v10.s[2]       \r\n"
"fmul    v6.4s,  v6.4s,  v10.s[3]       \r\n"
"fmul    v7.4s,  v7.4s,  v10.s[3]       \r\n"
"fmul    v8.4s,  v8.4s,  v11.s[0]       \r\n"
"fmul    v9.4s,  v9.4s,  v11.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v20.4s, v21.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v10.4s, v11.4s}, [%[addr_c0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_c1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_c2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_c3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v10.4s,  v20.s[0]       \r\n"
"fmla    v1.4s,  v11.4s,  v20.s[0]       \r\n"
"fmla    v2.4s,  v12.4s,  v20.s[1]       \r\n"
"fmla    v3.4s,  v13.4s,  v20.s[1]       \r\n"
"fmla    v4.4s,  v14.4s,  v20.s[2]       \r\n"
"fmla    v5.4s,  v15.4s,  v20.s[2]       \r\n"
"fmla    v6.4s,  v16.4s,  v20.s[3]       \r\n"
"fmla    v7.4s,  v17.4s,  v20.s[3]       \r\n"
"fmla    v8.4s,  v18.4s,  v21.s[0]       \r\n"
"fmla    v9.4s,  v19.4s,  v21.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v10.4s, v11.4s}, [%[addr_itm0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_itm1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_itm2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_itm3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_itm4]] \r\n"
:
: [addr_itm0] "r" (itm+8*0),
[addr_itm1] "r" (itm+8*1),
[addr_itm2] "r" (itm+8*2),
[addr_itm3] "r" (itm+8*3),
[addr_itm4] "r" (itm+8*4)
: "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19");
}
else {
asm volatile(
"ld1    {v10.4s, v11.4s}, [%[addr_c0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_c1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_c2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_c3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19");
}
asm volatile(
"fadd     v0.4s, v10.4s,  v0.4s \r\n"
"fadd     v1.4s, v11.4s,  v1.4s \r\n"
"fadd     v2.4s, v12.4s,  v2.4s \r\n"
"fadd     v3.4s, v13.4s,  v3.4s \r\n"
"fadd     v4.4s, v14.4s,  v4.4s \r\n"
"fadd     v5.4s, v15.4s,  v5.4s \r\n"
"fadd     v6.4s, v16.4s,  v6.4s \r\n"
"fadd     v7.4s, v17.4s,  v7.4s \r\n"
"fadd     v8.4s, v18.4s,  v8.4s \r\n"
"fadd     v9.4s, v19.4s,  v9.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v10.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v10.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v10.s[1]       \r\n"
"fmul    v3.4s,  v3.4s,  v10.s[1]       \r\n"
"fmul    v4.4s,  v4.4s,  v10.s[2]       \r\n"
"fmul    v5.4s,  v5.4s,  v10.s[2]       \r\n"
"fmul    v6.4s,  v6.4s,  v10.s[3]       \r\n"
"fmul    v7.4s,  v7.4s,  v10.s[3]       \r\n"
"fmul    v8.4s,  v8.4s,  v11.s[0]       \r\n"
"fmul    v9.4s,  v9.4s,  v11.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v10.4s, v11.4s}, [%[addr_c0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_c1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_c2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_c3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19");
asm volatile(
"fadd     v0.4s, v10.4s,  v0.4s \r\n"
"fadd     v1.4s, v11.4s,  v1.4s \r\n"
"fadd     v2.4s, v12.4s,  v2.4s \r\n"
"fadd     v3.4s, v13.4s,  v3.4s \r\n"
"fadd     v4.4s, v14.4s,  v4.4s \r\n"
"fadd     v5.4s, v15.4s,  v5.4s \r\n"
"fadd     v6.4s, v16.4s,  v6.4s \r\n"
"fadd     v7.4s, v17.4s,  v7.4s \r\n"
"fadd     v8.4s, v18.4s,  v8.4s \r\n"
"fadd     v9.4s, v19.4s,  v9.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v20.4s, v21.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v10.4s, v11.4s}, [%[addr_c0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_c1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_c2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_c3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v10.4s,  v20.s[0]       \r\n"
"fmla    v1.4s,  v11.4s,  v20.s[0]       \r\n"
"fmla    v2.4s,  v12.4s,  v20.s[1]       \r\n"
"fmla    v3.4s,  v13.4s,  v20.s[1]       \r\n"
"fmla    v4.4s,  v14.4s,  v20.s[2]       \r\n"
"fmla    v5.4s,  v15.4s,  v20.s[2]       \r\n"
"fmla    v6.4s,  v16.4s,  v20.s[3]       \r\n"
"fmla    v7.4s,  v17.4s,  v20.s[3]       \r\n"
"fmla    v8.4s,  v18.4s,  v21.s[0]       \r\n"
"fmla    v9.4s,  v19.4s,  v21.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_bias]] \r\n"
"dup    v12.4s, v10.s[0]               \r\n"
"dup    v13.4s, v10.s[1]               \r\n"
"dup    v14.4s, v10.s[2]               \r\n"
"dup    v15.4s, v10.s[3]               \r\n"
"dup    v16.4s, v11.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v12.4s \r\n"
"fadd     v1.4s, v1.4s,  v12.4s \r\n"
"fadd     v2.4s, v2.4s,  v13.4s \r\n"
"fadd     v3.4s, v3.4s,  v13.4s \r\n"
"fadd     v4.4s, v4.4s,  v14.4s \r\n"
"fadd     v5.4s, v5.4s,  v14.4s \r\n"
"fadd     v6.4s, v6.4s,  v15.4s \r\n"
"fadd     v7.4s, v7.4s,  v15.4s \r\n"
"fadd     v8.4s, v8.4s,  v16.4s \r\n"
"fadd     v9.4s, v9.4s,  v16.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5", "v5", "v6", "v6", "v7", "v7", "v8", "v8", "v9", "v9", "v10", "v10", "v11", "v11", "v12", "v12", "v13", "v13", "v14", "v14", "v15", "v15", "v16");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v10.4s, w9             \r\n"
"fmax    v0.4s, v10.4s,  v0.4s \r\n"
"fmax    v1.4s, v10.4s,  v1.4s \r\n"
"fmax    v2.4s, v10.4s,  v2.4s \r\n"
"fmax    v3.4s, v10.4s,  v3.4s \r\n"
"fmax    v4.4s, v10.4s,  v4.4s \r\n"
"fmax    v5.4s, v10.4s,  v5.4s \r\n"
"fmax    v6.4s, v10.4s,  v6.4s \r\n"
"fmax    v7.4s, v10.4s,  v7.4s \r\n"
"fmax    v8.4s, v10.4s,  v8.4s \r\n"
"fmax    v9.4s, v10.4s,  v9.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"st1    { v0.4s,  v1.4s,  v2.4s,  v3.4s}, [%[addr_itm0]] \r\n"
"st1    { v4.4s,  v5.4s,  v6.4s,  v7.4s}, [%[addr_itm1]] \r\n"
"st1    { v8.4s,  v9.4s}, [%[addr_itm2]] \r\n"
:
: [addr_itm0] "r" (itm+8*0),
[addr_itm1] "r" (itm+8*2),
[addr_itm2] "r" (itm+8*4)
: "memory");}
else {
asm volatile(
"st1    {v0.4s, v1.4s}, [%[addr_c0]] \r\n"
"st1    {v2.4s, v3.4s}, [%[addr_c1]] \r\n"
"st1    {v4.4s, v5.4s}, [%[addr_c2]] \r\n"
"st1    {v6.4s, v7.4s}, [%[addr_c3]] \r\n"
"st1    {v8.4s, v9.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 5, 7, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v10.4s, v11.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v10", "v11");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+7*(kk+0))
: "v15", "v16");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v15", "v16");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmul	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmul	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmul	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmul	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmul	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmul	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v10", "v11", "v12");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+7*kk+0*7),
[addr_b1] "r" (b+7*kk+1*7)
: "v15", "v16", "v17", "v18");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v15", "v16", "v17", "v18");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmul	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmul	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmul	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmul	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmul	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmul	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v17.4s, v11.s[3]  \r\n"
"	fmla	v5.4s,  v18.4s, v11.s[3]  \r\n"
"	fmla	v6.4s,  v17.4s, v12.s[0]  \r\n"
"	fmla	v7.4s,  v18.4s, v12.s[0]  \r\n"
"	fmla	v8.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v12.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s, v13.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v10", "v11", "v12", "v13");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+7*kk+0*7),
[addr_b1] "r" (b+7*kk+1*7),
[addr_b2] "r" (b+7*kk+2*7)
: "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmul	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmul	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmul	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmul	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmul	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmul	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v17.4s, v11.s[3]  \r\n"
"	fmla	v5.4s,  v18.4s, v11.s[3]  \r\n"
"	fmla	v6.4s,  v17.4s, v12.s[0]  \r\n"
"	fmla	v7.4s,  v18.4s, v12.s[0]  \r\n"
"	fmla	v8.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v12.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v12.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v12.s[3]  \r\n"
"	fmla	v4.4s,  v19.4s, v13.s[0]  \r\n"
"	fmla	v5.4s,  v20.4s, v13.s[0]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v13.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s, v13.4s}, [%[addr_a0]] \r\n"
"ld1    {v14.4s}, [%[addr_a1]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*16),
[addr_a1] "r" (a+5*kk+1*16)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
"ld1    {v21.4s, v22.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+7*kk+0*7),
[addr_b1] "r" (b+7*kk+1*7),
[addr_b2] "r" (b+7*kk+2*7),
[addr_b3] "r" (b+7*kk+3*7)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
"ld1    {v21.4s, v22.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmul	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmul	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmul	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmul	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmul	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmul	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"	fmla	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmla	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmla	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmla	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmla	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmla	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmla	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmla	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmla	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
kk+=4;
for(; kk<k; kk+=4) {
asm volatile(
"ld1    {v10.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*4)
: "v10");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+7*(kk+0))
: "v15", "v16");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v15", "v16");
}
asm volatile(
"	fmla	v0.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v17.4s, v11.s[3]  \r\n"
"	fmla	v5.4s,  v18.4s, v11.s[3]  \r\n"
"	fmla	v6.4s,  v17.4s, v12.s[0]  \r\n"
"	fmla	v7.4s,  v18.4s, v12.s[0]  \r\n"
"	fmla	v8.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v12.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"ld1    {v11.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+1*4)
: "v11");
if constexpr(ReB) {
asm volatile(
"ld1    {v17.4s, v18.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+7*(kk+1))
: "v17", "v18");
}
else {
asm volatile(
"ld1    {v17.4s, v18.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v17", "v18");
}
asm volatile(
"	fmla	v0.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v12.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v12.s[3]  \r\n"
"	fmla	v4.4s,  v19.4s, v13.s[0]  \r\n"
"	fmla	v5.4s,  v20.4s, v13.s[0]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v13.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"ld1    {v12.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+2*4)
: "v12");
if constexpr(ReB) {
asm volatile(
"ld1    {v19.4s, v20.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+7*(kk+2))
: "v19", "v20");
}
else {
asm volatile(
"ld1    {v19.4s, v20.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v19", "v20");
}
asm volatile(
"	fmla	v0.4s,  v21.4s, v13.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v13.s[3]  \r\n"
"	fmla	v2.4s,  v21.4s, v14.s[0]  \r\n"
"	fmla	v3.4s,  v22.4s, v14.s[0]  \r\n"
"	fmla	v4.4s,  v21.4s, v14.s[1]  \r\n"
"	fmla	v5.4s,  v22.4s, v14.s[1]  \r\n"
"	fmla	v6.4s,  v21.4s, v14.s[2]  \r\n"
"	fmla	v7.4s,  v22.4s, v14.s[2]  \r\n"
"	fmla	v8.4s,  v21.4s, v14.s[3]  \r\n"
"	fmla	v9.4s,  v22.4s, v14.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"ld1    {v13.4s, v14.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+3*4)
: "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+7*(kk+3))
: "v21", "v22");
}
else {
asm volatile(
"ld1    {v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v21", "v22");
}
asm volatile(
"	fmla	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmla	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmla	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmla	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmla	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmla	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmla	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmla	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmla	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"	fmla	v0.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v17.4s, v11.s[3]  \r\n"
"	fmla	v5.4s,  v18.4s, v11.s[3]  \r\n"
"	fmla	v6.4s,  v17.4s, v12.s[0]  \r\n"
"	fmla	v7.4s,  v18.4s, v12.s[0]  \r\n"
"	fmla	v8.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v12.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v12.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v12.s[3]  \r\n"
"	fmla	v4.4s,  v19.4s, v13.s[0]  \r\n"
"	fmla	v5.4s,  v20.4s, v13.s[0]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v13.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v21.4s, v13.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v13.s[3]  \r\n"
"	fmla	v2.4s,  v21.4s, v14.s[0]  \r\n"
"	fmla	v3.4s,  v22.4s, v14.s[0]  \r\n"
"	fmla	v4.4s,  v21.4s, v14.s[1]  \r\n"
"	fmla	v5.4s,  v22.4s, v14.s[1]  \r\n"
"	fmla	v6.4s,  v21.4s, v14.s[2]  \r\n"
"	fmla	v7.4s,  v22.4s, v14.s[2]  \r\n"
"	fmla	v8.4s,  v21.4s, v14.s[3]  \r\n"
"	fmla	v9.4s,  v22.4s, v14.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s10, [%[addr_a0]] \r\n"
"ldr    s11, [%[addr_a1]] \r\n"
"ldr    s12, [%[addr_a2]] \r\n"
"ldr    s13, [%[addr_a3]] \r\n"
"ldr    s14, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+7*(kk+0))
: "v15", "v16");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v15", "v16");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v3.4s,  v16.4s, v11.s[0]  \r\n"
"	fmul	v4.4s,  v15.4s, v12.s[0]  \r\n"
"	fmul	v5.4s,  v16.4s, v12.s[0]  \r\n"
"	fmul	v6.4s,  v15.4s, v13.s[0]  \r\n"
"	fmul	v7.4s,  v16.4s, v13.s[0]  \r\n"
"	fmul	v8.4s,  v15.4s, v14.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v14.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d10, [%[addr_a0]] \r\n"
"ldr    d11, [%[addr_a1]] \r\n"
"ldr    d12, [%[addr_a2]] \r\n"
"ldr    d13, [%[addr_a3]] \r\n"
"ldr    d14, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+7*kk+0*7),
[addr_b1] "r" (b+7*kk+1*7)
: "v15", "v16", "v17", "v18");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v15", "v16", "v17", "v18");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v3.4s,  v16.4s, v11.s[0]  \r\n"
"	fmul	v4.4s,  v15.4s, v12.s[0]  \r\n"
"	fmul	v5.4s,  v16.4s, v12.s[0]  \r\n"
"	fmul	v6.4s,  v15.4s, v13.s[0]  \r\n"
"	fmul	v7.4s,  v16.4s, v13.s[0]  \r\n"
"	fmul	v8.4s,  v15.4s, v14.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v14.s[0]  \r\n"
"	fmla	v0.4s,  v17.4s, v10.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v10.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v4.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v5.4s,  v18.4s, v12.s[1]  \r\n"
"	fmla	v6.4s,  v17.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v18.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v17.4s, v14.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v14.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q10, [%[addr_a0]] \r\n"
"ldr    q11, [%[addr_a1]] \r\n"
"ldr    q12, [%[addr_a2]] \r\n"
"ldr    q13, [%[addr_a3]] \r\n"
"ldr    q14, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+7*kk+0*7),
[addr_b1] "r" (b+7*kk+1*7),
[addr_b2] "r" (b+7*kk+2*7)
: "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v3.4s,  v16.4s, v11.s[0]  \r\n"
"	fmul	v4.4s,  v15.4s, v12.s[0]  \r\n"
"	fmul	v5.4s,  v16.4s, v12.s[0]  \r\n"
"	fmul	v6.4s,  v15.4s, v13.s[0]  \r\n"
"	fmul	v7.4s,  v16.4s, v13.s[0]  \r\n"
"	fmul	v8.4s,  v15.4s, v14.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v14.s[0]  \r\n"
"	fmla	v0.4s,  v17.4s, v10.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v10.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v4.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v5.4s,  v18.4s, v12.s[1]  \r\n"
"	fmla	v6.4s,  v17.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v18.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v17.4s, v14.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v14.s[1]  \r\n"
"	fmla	v0.4s,  v19.4s, v10.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v10.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v20.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v5.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[2]  \r\n"
"	fmla	v8.4s,  v19.4s, v14.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v14.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
"dup     v4.4s, %w[zero] \r\n"
"dup     v5.4s, %w[zero] \r\n"
"dup     v6.4s, %w[zero] \r\n"
"dup     v7.4s, %w[zero] \r\n"
"dup     v8.4s, %w[zero] \r\n"
"dup     v9.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"ldr    q10, [%[addr_a0]] \r\n"
"ldr    q11, [%[addr_a1]] \r\n"
"ldr    q12, [%[addr_a2]] \r\n"
"ldr    q13, [%[addr_a3]] \r\n"
"ldr    q14, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
"ld1    {v21.4s, v22.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+7*kk+0*7),
[addr_b1] "r" (b+7*kk+1*7),
[addr_b2] "r" (b+7*kk+2*7),
[addr_b3] "r" (b+7*kk+3*7)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
"ld1    {v21.4s, v22.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22");
}
asm volatile(
"	fmla	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmla	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmla	v2.4s,  v15.4s, v11.s[0]  \r\n"
"	fmla	v3.4s,  v16.4s, v11.s[0]  \r\n"
"	fmla	v4.4s,  v15.4s, v12.s[0]  \r\n"
"	fmla	v5.4s,  v16.4s, v12.s[0]  \r\n"
"	fmla	v6.4s,  v15.4s, v13.s[0]  \r\n"
"	fmla	v7.4s,  v16.4s, v13.s[0]  \r\n"
"	fmla	v8.4s,  v15.4s, v14.s[0]  \r\n"
"	fmla	v9.4s,  v16.4s, v14.s[0]  \r\n"
"	fmla	v0.4s,  v17.4s, v10.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v10.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v4.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v5.4s,  v18.4s, v12.s[1]  \r\n"
"	fmla	v6.4s,  v17.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v18.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v17.4s, v14.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v14.s[1]  \r\n"
"	fmla	v0.4s,  v19.4s, v10.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v10.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v20.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v5.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[2]  \r\n"
"	fmla	v8.4s,  v19.4s, v14.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v14.s[2]  \r\n"
"	fmla	v0.4s,  v21.4s, v10.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v10.s[3]  \r\n"
"	fmla	v2.4s,  v21.4s, v11.s[3]  \r\n"
"	fmla	v3.4s,  v22.4s, v11.s[3]  \r\n"
"	fmla	v4.4s,  v21.4s, v12.s[3]  \r\n"
"	fmla	v5.4s,  v22.4s, v12.s[3]  \r\n"
"	fmla	v6.4s,  v21.4s, v13.s[3]  \r\n"
"	fmla	v7.4s,  v22.4s, v13.s[3]  \r\n"
"	fmla	v8.4s,  v21.4s, v14.s[3]  \r\n"
"	fmla	v9.4s,  v22.4s, v14.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v10.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v10.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v10.s[1]       \r\n"
"fmul    v3.4s,  v3.4s,  v10.s[1]       \r\n"
"fmul    v4.4s,  v4.4s,  v10.s[2]       \r\n"
"fmul    v5.4s,  v5.4s,  v10.s[2]       \r\n"
"fmul    v6.4s,  v6.4s,  v10.s[3]       \r\n"
"fmul    v7.4s,  v7.4s,  v10.s[3]       \r\n"
"fmul    v8.4s,  v8.4s,  v11.s[0]       \r\n"
"fmul    v9.4s,  v9.4s,  v11.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v20.4s, v21.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v10.4s, v11.4s}, [%[addr_c0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_c1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_c2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_c3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v10.4s,  v20.s[0]       \r\n"
"fmla    v1.4s,  v11.4s,  v20.s[0]       \r\n"
"fmla    v2.4s,  v12.4s,  v20.s[1]       \r\n"
"fmla    v3.4s,  v13.4s,  v20.s[1]       \r\n"
"fmla    v4.4s,  v14.4s,  v20.s[2]       \r\n"
"fmla    v5.4s,  v15.4s,  v20.s[2]       \r\n"
"fmla    v6.4s,  v16.4s,  v20.s[3]       \r\n"
"fmla    v7.4s,  v17.4s,  v20.s[3]       \r\n"
"fmla    v8.4s,  v18.4s,  v21.s[0]       \r\n"
"fmla    v9.4s,  v19.4s,  v21.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v10.4s, v11.4s}, [%[addr_itm0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_itm1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_itm2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_itm3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_itm4]] \r\n"
:
: [addr_itm0] "r" (itm+7*0),
[addr_itm1] "r" (itm+7*1),
[addr_itm2] "r" (itm+7*2),
[addr_itm3] "r" (itm+7*3),
[addr_itm4] "r" (itm+7*4)
: "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19");
}
else {
asm volatile(
"ld1    {v10.4s, v11.4s}, [%[addr_c0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_c1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_c2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_c3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19");
}
asm volatile(
"fadd     v0.4s, v10.4s,  v0.4s \r\n"
"fadd     v1.4s, v11.4s,  v1.4s \r\n"
"fadd     v2.4s, v12.4s,  v2.4s \r\n"
"fadd     v3.4s, v13.4s,  v3.4s \r\n"
"fadd     v4.4s, v14.4s,  v4.4s \r\n"
"fadd     v5.4s, v15.4s,  v5.4s \r\n"
"fadd     v6.4s, v16.4s,  v6.4s \r\n"
"fadd     v7.4s, v17.4s,  v7.4s \r\n"
"fadd     v8.4s, v18.4s,  v8.4s \r\n"
"fadd     v9.4s, v19.4s,  v9.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v10.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v10.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v10.s[1]       \r\n"
"fmul    v3.4s,  v3.4s,  v10.s[1]       \r\n"
"fmul    v4.4s,  v4.4s,  v10.s[2]       \r\n"
"fmul    v5.4s,  v5.4s,  v10.s[2]       \r\n"
"fmul    v6.4s,  v6.4s,  v10.s[3]       \r\n"
"fmul    v7.4s,  v7.4s,  v10.s[3]       \r\n"
"fmul    v8.4s,  v8.4s,  v11.s[0]       \r\n"
"fmul    v9.4s,  v9.4s,  v11.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v10.4s, v11.4s}, [%[addr_c0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_c1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_c2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_c3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19");
asm volatile(
"fadd     v0.4s, v10.4s,  v0.4s \r\n"
"fadd     v1.4s, v11.4s,  v1.4s \r\n"
"fadd     v2.4s, v12.4s,  v2.4s \r\n"
"fadd     v3.4s, v13.4s,  v3.4s \r\n"
"fadd     v4.4s, v14.4s,  v4.4s \r\n"
"fadd     v5.4s, v15.4s,  v5.4s \r\n"
"fadd     v6.4s, v16.4s,  v6.4s \r\n"
"fadd     v7.4s, v17.4s,  v7.4s \r\n"
"fadd     v8.4s, v18.4s,  v8.4s \r\n"
"fadd     v9.4s, v19.4s,  v9.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v20.4s, v21.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v10.4s, v11.4s}, [%[addr_c0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_c1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_c2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_c3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v10.4s,  v20.s[0]       \r\n"
"fmla    v1.4s,  v11.4s,  v20.s[0]       \r\n"
"fmla    v2.4s,  v12.4s,  v20.s[1]       \r\n"
"fmla    v3.4s,  v13.4s,  v20.s[1]       \r\n"
"fmla    v4.4s,  v14.4s,  v20.s[2]       \r\n"
"fmla    v5.4s,  v15.4s,  v20.s[2]       \r\n"
"fmla    v6.4s,  v16.4s,  v20.s[3]       \r\n"
"fmla    v7.4s,  v17.4s,  v20.s[3]       \r\n"
"fmla    v8.4s,  v18.4s,  v21.s[0]       \r\n"
"fmla    v9.4s,  v19.4s,  v21.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_bias]] \r\n"
"dup    v12.4s, v10.s[0]               \r\n"
"dup    v13.4s, v10.s[1]               \r\n"
"dup    v14.4s, v10.s[2]               \r\n"
"dup    v15.4s, v10.s[3]               \r\n"
"dup    v16.4s, v11.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v12.4s \r\n"
"fadd     v1.4s, v1.4s,  v12.4s \r\n"
"fadd     v2.4s, v2.4s,  v13.4s \r\n"
"fadd     v3.4s, v3.4s,  v13.4s \r\n"
"fadd     v4.4s, v4.4s,  v14.4s \r\n"
"fadd     v5.4s, v5.4s,  v14.4s \r\n"
"fadd     v6.4s, v6.4s,  v15.4s \r\n"
"fadd     v7.4s, v7.4s,  v15.4s \r\n"
"fadd     v8.4s, v8.4s,  v16.4s \r\n"
"fadd     v9.4s, v9.4s,  v16.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5", "v5", "v6", "v6", "v7", "v7", "v8", "v8", "v9", "v9", "v10", "v10", "v11", "v11", "v12", "v12", "v13", "v13", "v14", "v14", "v15", "v15", "v16");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v10.4s, w9             \r\n"
"fmax    v0.4s, v10.4s,  v0.4s \r\n"
"fmax    v1.4s, v10.4s,  v1.4s \r\n"
"fmax    v2.4s, v10.4s,  v2.4s \r\n"
"fmax    v3.4s, v10.4s,  v3.4s \r\n"
"fmax    v4.4s, v10.4s,  v4.4s \r\n"
"fmax    v5.4s, v10.4s,  v5.4s \r\n"
"fmax    v6.4s, v10.4s,  v6.4s \r\n"
"fmax    v7.4s, v10.4s,  v7.4s \r\n"
"fmax    v8.4s, v10.4s,  v8.4s \r\n"
"fmax    v9.4s, v10.4s,  v9.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"mov    s10,  v1.s[2]           \r\n"
"mov    s11,  v3.s[2]           \r\n"
"mov    s12,  v5.s[2]           \r\n"
"mov    s13,  v7.s[2]           \r\n"
"mov    s14,  v9.s[2]           \r\n"
"str     q0, [%[addr_itm],   0] \r\n"
"str     d1, [%[addr_itm],   16] \r\n"
"str     s10, [%[addr_itm],   24] \r\n"
"str     q2, [%[addr_itm],   28] \r\n"
"str     d3, [%[addr_itm],   44] \r\n"
"str     s11, [%[addr_itm],   52] \r\n"
"str     q4, [%[addr_itm],   56] \r\n"
"str     d5, [%[addr_itm],   72] \r\n"
"str     s12, [%[addr_itm],   80] \r\n"
"str     q6, [%[addr_itm],   84] \r\n"
"str     d7, [%[addr_itm],   100] \r\n"
"str     s13, [%[addr_itm],   108] \r\n"
"str     q8, [%[addr_itm],   112] \r\n"
"str     d9, [%[addr_itm],   128] \r\n"
"str     s14, [%[addr_itm],   136] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"mov    s10,  v1.s[2]           \r\n"
"mov    s11,  v3.s[2]           \r\n"
"mov    s12,  v5.s[2]           \r\n"
"mov    s13,  v7.s[2]           \r\n"
"mov    s14,  v9.s[2]           \r\n"
"str     q0, [%[addr_c0],   0] \r\n"
"str     d1, [%[addr_c0],   16] \r\n"
"str     s10, [%[addr_c0],   24] \r\n"
"str     q2, [%[addr_c1],   0] \r\n"
"str     d3, [%[addr_c1],   16] \r\n"
"str     s11, [%[addr_c1],   24] \r\n"
"str     q4, [%[addr_c2],   0] \r\n"
"str     d5, [%[addr_c2],   16] \r\n"
"str     s12, [%[addr_c2],   24] \r\n"
"str     q6, [%[addr_c3],   0] \r\n"
"str     d7, [%[addr_c3],   16] \r\n"
"str     s13, [%[addr_c3],   24] \r\n"
"str     q8, [%[addr_c4],   0] \r\n"
"str     d9, [%[addr_c4],   16] \r\n"
"str     s14, [%[addr_c4],   24] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 5, 6, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v10.4s, v11.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v10", "v11");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+6*(kk+0))
: "v15", "v16");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v15", "v16");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmul	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmul	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmul	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmul	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmul	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmul	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v10", "v11", "v12");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+6*kk+0*6),
[addr_b1] "r" (b+6*kk+1*6)
: "v15", "v16", "v17", "v18");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v15", "v16", "v17", "v18");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmul	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmul	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmul	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmul	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmul	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmul	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v17.4s, v11.s[3]  \r\n"
"	fmla	v5.4s,  v18.4s, v11.s[3]  \r\n"
"	fmla	v6.4s,  v17.4s, v12.s[0]  \r\n"
"	fmla	v7.4s,  v18.4s, v12.s[0]  \r\n"
"	fmla	v8.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v12.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s, v13.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v10", "v11", "v12", "v13");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+6*kk+0*6),
[addr_b1] "r" (b+6*kk+1*6),
[addr_b2] "r" (b+6*kk+2*6)
: "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmul	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmul	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmul	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmul	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmul	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmul	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v17.4s, v11.s[3]  \r\n"
"	fmla	v5.4s,  v18.4s, v11.s[3]  \r\n"
"	fmla	v6.4s,  v17.4s, v12.s[0]  \r\n"
"	fmla	v7.4s,  v18.4s, v12.s[0]  \r\n"
"	fmla	v8.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v12.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v12.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v12.s[3]  \r\n"
"	fmla	v4.4s,  v19.4s, v13.s[0]  \r\n"
"	fmla	v5.4s,  v20.4s, v13.s[0]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v13.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s, v13.4s}, [%[addr_a0]] \r\n"
"ld1    {v14.4s}, [%[addr_a1]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*16),
[addr_a1] "r" (a+5*kk+1*16)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
"ld1    {v21.4s, v22.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+6*kk+0*6),
[addr_b1] "r" (b+6*kk+1*6),
[addr_b2] "r" (b+6*kk+2*6),
[addr_b3] "r" (b+6*kk+3*6)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
"ld1    {v21.4s, v22.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmul	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmul	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmul	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmul	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmul	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmul	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"	fmla	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmla	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmla	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmla	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmla	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmla	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmla	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmla	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmla	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
kk+=4;
for(; kk<k; kk+=4) {
asm volatile(
"ld1    {v10.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*4)
: "v10");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+6*(kk+0))
: "v15", "v16");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v15", "v16");
}
asm volatile(
"	fmla	v0.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v17.4s, v11.s[3]  \r\n"
"	fmla	v5.4s,  v18.4s, v11.s[3]  \r\n"
"	fmla	v6.4s,  v17.4s, v12.s[0]  \r\n"
"	fmla	v7.4s,  v18.4s, v12.s[0]  \r\n"
"	fmla	v8.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v12.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"ld1    {v11.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+1*4)
: "v11");
if constexpr(ReB) {
asm volatile(
"ld1    {v17.4s, v18.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+6*(kk+1))
: "v17", "v18");
}
else {
asm volatile(
"ld1    {v17.4s, v18.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v17", "v18");
}
asm volatile(
"	fmla	v0.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v12.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v12.s[3]  \r\n"
"	fmla	v4.4s,  v19.4s, v13.s[0]  \r\n"
"	fmla	v5.4s,  v20.4s, v13.s[0]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v13.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"ld1    {v12.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+2*4)
: "v12");
if constexpr(ReB) {
asm volatile(
"ld1    {v19.4s, v20.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+6*(kk+2))
: "v19", "v20");
}
else {
asm volatile(
"ld1    {v19.4s, v20.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v19", "v20");
}
asm volatile(
"	fmla	v0.4s,  v21.4s, v13.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v13.s[3]  \r\n"
"	fmla	v2.4s,  v21.4s, v14.s[0]  \r\n"
"	fmla	v3.4s,  v22.4s, v14.s[0]  \r\n"
"	fmla	v4.4s,  v21.4s, v14.s[1]  \r\n"
"	fmla	v5.4s,  v22.4s, v14.s[1]  \r\n"
"	fmla	v6.4s,  v21.4s, v14.s[2]  \r\n"
"	fmla	v7.4s,  v22.4s, v14.s[2]  \r\n"
"	fmla	v8.4s,  v21.4s, v14.s[3]  \r\n"
"	fmla	v9.4s,  v22.4s, v14.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"ld1    {v13.4s, v14.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+3*4)
: "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+6*(kk+3))
: "v21", "v22");
}
else {
asm volatile(
"ld1    {v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v21", "v22");
}
asm volatile(
"	fmla	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmla	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmla	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmla	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmla	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmla	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmla	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmla	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmla	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"	fmla	v0.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v17.4s, v11.s[3]  \r\n"
"	fmla	v5.4s,  v18.4s, v11.s[3]  \r\n"
"	fmla	v6.4s,  v17.4s, v12.s[0]  \r\n"
"	fmla	v7.4s,  v18.4s, v12.s[0]  \r\n"
"	fmla	v8.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v12.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v12.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v12.s[3]  \r\n"
"	fmla	v4.4s,  v19.4s, v13.s[0]  \r\n"
"	fmla	v5.4s,  v20.4s, v13.s[0]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v13.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v21.4s, v13.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v13.s[3]  \r\n"
"	fmla	v2.4s,  v21.4s, v14.s[0]  \r\n"
"	fmla	v3.4s,  v22.4s, v14.s[0]  \r\n"
"	fmla	v4.4s,  v21.4s, v14.s[1]  \r\n"
"	fmla	v5.4s,  v22.4s, v14.s[1]  \r\n"
"	fmla	v6.4s,  v21.4s, v14.s[2]  \r\n"
"	fmla	v7.4s,  v22.4s, v14.s[2]  \r\n"
"	fmla	v8.4s,  v21.4s, v14.s[3]  \r\n"
"	fmla	v9.4s,  v22.4s, v14.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s10, [%[addr_a0]] \r\n"
"ldr    s11, [%[addr_a1]] \r\n"
"ldr    s12, [%[addr_a2]] \r\n"
"ldr    s13, [%[addr_a3]] \r\n"
"ldr    s14, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+6*(kk+0))
: "v15", "v16");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v15", "v16");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v3.4s,  v16.4s, v11.s[0]  \r\n"
"	fmul	v4.4s,  v15.4s, v12.s[0]  \r\n"
"	fmul	v5.4s,  v16.4s, v12.s[0]  \r\n"
"	fmul	v6.4s,  v15.4s, v13.s[0]  \r\n"
"	fmul	v7.4s,  v16.4s, v13.s[0]  \r\n"
"	fmul	v8.4s,  v15.4s, v14.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v14.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d10, [%[addr_a0]] \r\n"
"ldr    d11, [%[addr_a1]] \r\n"
"ldr    d12, [%[addr_a2]] \r\n"
"ldr    d13, [%[addr_a3]] \r\n"
"ldr    d14, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+6*kk+0*6),
[addr_b1] "r" (b+6*kk+1*6)
: "v15", "v16", "v17", "v18");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v15", "v16", "v17", "v18");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v3.4s,  v16.4s, v11.s[0]  \r\n"
"	fmul	v4.4s,  v15.4s, v12.s[0]  \r\n"
"	fmul	v5.4s,  v16.4s, v12.s[0]  \r\n"
"	fmul	v6.4s,  v15.4s, v13.s[0]  \r\n"
"	fmul	v7.4s,  v16.4s, v13.s[0]  \r\n"
"	fmul	v8.4s,  v15.4s, v14.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v14.s[0]  \r\n"
"	fmla	v0.4s,  v17.4s, v10.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v10.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v4.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v5.4s,  v18.4s, v12.s[1]  \r\n"
"	fmla	v6.4s,  v17.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v18.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v17.4s, v14.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v14.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q10, [%[addr_a0]] \r\n"
"ldr    q11, [%[addr_a1]] \r\n"
"ldr    q12, [%[addr_a2]] \r\n"
"ldr    q13, [%[addr_a3]] \r\n"
"ldr    q14, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+6*kk+0*6),
[addr_b1] "r" (b+6*kk+1*6),
[addr_b2] "r" (b+6*kk+2*6)
: "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v3.4s,  v16.4s, v11.s[0]  \r\n"
"	fmul	v4.4s,  v15.4s, v12.s[0]  \r\n"
"	fmul	v5.4s,  v16.4s, v12.s[0]  \r\n"
"	fmul	v6.4s,  v15.4s, v13.s[0]  \r\n"
"	fmul	v7.4s,  v16.4s, v13.s[0]  \r\n"
"	fmul	v8.4s,  v15.4s, v14.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v14.s[0]  \r\n"
"	fmla	v0.4s,  v17.4s, v10.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v10.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v4.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v5.4s,  v18.4s, v12.s[1]  \r\n"
"	fmla	v6.4s,  v17.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v18.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v17.4s, v14.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v14.s[1]  \r\n"
"	fmla	v0.4s,  v19.4s, v10.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v10.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v20.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v5.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[2]  \r\n"
"	fmla	v8.4s,  v19.4s, v14.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v14.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
"dup     v4.4s, %w[zero] \r\n"
"dup     v5.4s, %w[zero] \r\n"
"dup     v6.4s, %w[zero] \r\n"
"dup     v7.4s, %w[zero] \r\n"
"dup     v8.4s, %w[zero] \r\n"
"dup     v9.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"ldr    q10, [%[addr_a0]] \r\n"
"ldr    q11, [%[addr_a1]] \r\n"
"ldr    q12, [%[addr_a2]] \r\n"
"ldr    q13, [%[addr_a3]] \r\n"
"ldr    q14, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
"ld1    {v21.4s, v22.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+6*kk+0*6),
[addr_b1] "r" (b+6*kk+1*6),
[addr_b2] "r" (b+6*kk+2*6),
[addr_b3] "r" (b+6*kk+3*6)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
"ld1    {v21.4s, v22.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22");
}
asm volatile(
"	fmla	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmla	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmla	v2.4s,  v15.4s, v11.s[0]  \r\n"
"	fmla	v3.4s,  v16.4s, v11.s[0]  \r\n"
"	fmla	v4.4s,  v15.4s, v12.s[0]  \r\n"
"	fmla	v5.4s,  v16.4s, v12.s[0]  \r\n"
"	fmla	v6.4s,  v15.4s, v13.s[0]  \r\n"
"	fmla	v7.4s,  v16.4s, v13.s[0]  \r\n"
"	fmla	v8.4s,  v15.4s, v14.s[0]  \r\n"
"	fmla	v9.4s,  v16.4s, v14.s[0]  \r\n"
"	fmla	v0.4s,  v17.4s, v10.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v10.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v4.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v5.4s,  v18.4s, v12.s[1]  \r\n"
"	fmla	v6.4s,  v17.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v18.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v17.4s, v14.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v14.s[1]  \r\n"
"	fmla	v0.4s,  v19.4s, v10.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v10.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v20.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v5.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[2]  \r\n"
"	fmla	v8.4s,  v19.4s, v14.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v14.s[2]  \r\n"
"	fmla	v0.4s,  v21.4s, v10.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v10.s[3]  \r\n"
"	fmla	v2.4s,  v21.4s, v11.s[3]  \r\n"
"	fmla	v3.4s,  v22.4s, v11.s[3]  \r\n"
"	fmla	v4.4s,  v21.4s, v12.s[3]  \r\n"
"	fmla	v5.4s,  v22.4s, v12.s[3]  \r\n"
"	fmla	v6.4s,  v21.4s, v13.s[3]  \r\n"
"	fmla	v7.4s,  v22.4s, v13.s[3]  \r\n"
"	fmla	v8.4s,  v21.4s, v14.s[3]  \r\n"
"	fmla	v9.4s,  v22.4s, v14.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v10.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v10.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v10.s[1]       \r\n"
"fmul    v3.4s,  v3.4s,  v10.s[1]       \r\n"
"fmul    v4.4s,  v4.4s,  v10.s[2]       \r\n"
"fmul    v5.4s,  v5.4s,  v10.s[2]       \r\n"
"fmul    v6.4s,  v6.4s,  v10.s[3]       \r\n"
"fmul    v7.4s,  v7.4s,  v10.s[3]       \r\n"
"fmul    v8.4s,  v8.4s,  v11.s[0]       \r\n"
"fmul    v9.4s,  v9.4s,  v11.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v20.4s, v21.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v10.4s, v11.4s}, [%[addr_c0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_c1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_c2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_c3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v10.4s,  v20.s[0]       \r\n"
"fmla    v1.4s,  v11.4s,  v20.s[0]       \r\n"
"fmla    v2.4s,  v12.4s,  v20.s[1]       \r\n"
"fmla    v3.4s,  v13.4s,  v20.s[1]       \r\n"
"fmla    v4.4s,  v14.4s,  v20.s[2]       \r\n"
"fmla    v5.4s,  v15.4s,  v20.s[2]       \r\n"
"fmla    v6.4s,  v16.4s,  v20.s[3]       \r\n"
"fmla    v7.4s,  v17.4s,  v20.s[3]       \r\n"
"fmla    v8.4s,  v18.4s,  v21.s[0]       \r\n"
"fmla    v9.4s,  v19.4s,  v21.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v10.4s, v11.4s}, [%[addr_itm0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_itm1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_itm2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_itm3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_itm4]] \r\n"
:
: [addr_itm0] "r" (itm+6*0),
[addr_itm1] "r" (itm+6*1),
[addr_itm2] "r" (itm+6*2),
[addr_itm3] "r" (itm+6*3),
[addr_itm4] "r" (itm+6*4)
: "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19");
}
else {
asm volatile(
"ld1    {v10.4s, v11.4s}, [%[addr_c0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_c1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_c2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_c3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19");
}
asm volatile(
"fadd     v0.4s, v10.4s,  v0.4s \r\n"
"fadd     v1.4s, v11.4s,  v1.4s \r\n"
"fadd     v2.4s, v12.4s,  v2.4s \r\n"
"fadd     v3.4s, v13.4s,  v3.4s \r\n"
"fadd     v4.4s, v14.4s,  v4.4s \r\n"
"fadd     v5.4s, v15.4s,  v5.4s \r\n"
"fadd     v6.4s, v16.4s,  v6.4s \r\n"
"fadd     v7.4s, v17.4s,  v7.4s \r\n"
"fadd     v8.4s, v18.4s,  v8.4s \r\n"
"fadd     v9.4s, v19.4s,  v9.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v10.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v10.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v10.s[1]       \r\n"
"fmul    v3.4s,  v3.4s,  v10.s[1]       \r\n"
"fmul    v4.4s,  v4.4s,  v10.s[2]       \r\n"
"fmul    v5.4s,  v5.4s,  v10.s[2]       \r\n"
"fmul    v6.4s,  v6.4s,  v10.s[3]       \r\n"
"fmul    v7.4s,  v7.4s,  v10.s[3]       \r\n"
"fmul    v8.4s,  v8.4s,  v11.s[0]       \r\n"
"fmul    v9.4s,  v9.4s,  v11.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v10.4s, v11.4s}, [%[addr_c0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_c1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_c2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_c3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19");
asm volatile(
"fadd     v0.4s, v10.4s,  v0.4s \r\n"
"fadd     v1.4s, v11.4s,  v1.4s \r\n"
"fadd     v2.4s, v12.4s,  v2.4s \r\n"
"fadd     v3.4s, v13.4s,  v3.4s \r\n"
"fadd     v4.4s, v14.4s,  v4.4s \r\n"
"fadd     v5.4s, v15.4s,  v5.4s \r\n"
"fadd     v6.4s, v16.4s,  v6.4s \r\n"
"fadd     v7.4s, v17.4s,  v7.4s \r\n"
"fadd     v8.4s, v18.4s,  v8.4s \r\n"
"fadd     v9.4s, v19.4s,  v9.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v20.4s, v21.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v10.4s, v11.4s}, [%[addr_c0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_c1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_c2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_c3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v10.4s,  v20.s[0]       \r\n"
"fmla    v1.4s,  v11.4s,  v20.s[0]       \r\n"
"fmla    v2.4s,  v12.4s,  v20.s[1]       \r\n"
"fmla    v3.4s,  v13.4s,  v20.s[1]       \r\n"
"fmla    v4.4s,  v14.4s,  v20.s[2]       \r\n"
"fmla    v5.4s,  v15.4s,  v20.s[2]       \r\n"
"fmla    v6.4s,  v16.4s,  v20.s[3]       \r\n"
"fmla    v7.4s,  v17.4s,  v20.s[3]       \r\n"
"fmla    v8.4s,  v18.4s,  v21.s[0]       \r\n"
"fmla    v9.4s,  v19.4s,  v21.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_bias]] \r\n"
"dup    v12.4s, v10.s[0]               \r\n"
"dup    v13.4s, v10.s[1]               \r\n"
"dup    v14.4s, v10.s[2]               \r\n"
"dup    v15.4s, v10.s[3]               \r\n"
"dup    v16.4s, v11.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v12.4s \r\n"
"fadd     v1.4s, v1.4s,  v12.4s \r\n"
"fadd     v2.4s, v2.4s,  v13.4s \r\n"
"fadd     v3.4s, v3.4s,  v13.4s \r\n"
"fadd     v4.4s, v4.4s,  v14.4s \r\n"
"fadd     v5.4s, v5.4s,  v14.4s \r\n"
"fadd     v6.4s, v6.4s,  v15.4s \r\n"
"fadd     v7.4s, v7.4s,  v15.4s \r\n"
"fadd     v8.4s, v8.4s,  v16.4s \r\n"
"fadd     v9.4s, v9.4s,  v16.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5", "v5", "v6", "v6", "v7", "v7", "v8", "v8", "v9", "v9", "v10", "v10", "v11", "v11", "v12", "v12", "v13", "v13", "v14", "v14", "v15", "v15", "v16");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v10.4s, w9             \r\n"
"fmax    v0.4s, v10.4s,  v0.4s \r\n"
"fmax    v1.4s, v10.4s,  v1.4s \r\n"
"fmax    v2.4s, v10.4s,  v2.4s \r\n"
"fmax    v3.4s, v10.4s,  v3.4s \r\n"
"fmax    v4.4s, v10.4s,  v4.4s \r\n"
"fmax    v5.4s, v10.4s,  v5.4s \r\n"
"fmax    v6.4s, v10.4s,  v6.4s \r\n"
"fmax    v7.4s, v10.4s,  v7.4s \r\n"
"fmax    v8.4s, v10.4s,  v8.4s \r\n"
"fmax    v9.4s, v10.4s,  v9.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"str     q0, [%[addr_itm],   0] \r\n"
"str     d1, [%[addr_itm],   16] \r\n"
"str     q2, [%[addr_itm],   24] \r\n"
"str     d3, [%[addr_itm],   40] \r\n"
"str     q4, [%[addr_itm],   48] \r\n"
"str     d5, [%[addr_itm],   64] \r\n"
"str     q6, [%[addr_itm],   72] \r\n"
"str     d7, [%[addr_itm],   88] \r\n"
"str     q8, [%[addr_itm],   96] \r\n"
"str     d9, [%[addr_itm],   112] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"str     q0, [%[addr_c0],   0] \r\n"
"str     d1, [%[addr_c0],   16] \r\n"
"str     q2, [%[addr_c1],   0] \r\n"
"str     d3, [%[addr_c1],   16] \r\n"
"str     q4, [%[addr_c2],   0] \r\n"
"str     d5, [%[addr_c2],   16] \r\n"
"str     q6, [%[addr_c3],   0] \r\n"
"str     d7, [%[addr_c3],   16] \r\n"
"str     q8, [%[addr_c4],   0] \r\n"
"str     d9, [%[addr_c4],   16] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 5, 5, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v10.4s, v11.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v10", "v11");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+5*(kk+0))
: "v15", "v16");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v15", "v16");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmul	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmul	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmul	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmul	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmul	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmul	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v10", "v11", "v12");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+5*kk+0*5),
[addr_b1] "r" (b+5*kk+1*5)
: "v15", "v16", "v17", "v18");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v15", "v16", "v17", "v18");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmul	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmul	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmul	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmul	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmul	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmul	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v17.4s, v11.s[3]  \r\n"
"	fmla	v5.4s,  v18.4s, v11.s[3]  \r\n"
"	fmla	v6.4s,  v17.4s, v12.s[0]  \r\n"
"	fmla	v7.4s,  v18.4s, v12.s[0]  \r\n"
"	fmla	v8.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v12.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s, v13.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v10", "v11", "v12", "v13");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+5*kk+0*5),
[addr_b1] "r" (b+5*kk+1*5),
[addr_b2] "r" (b+5*kk+2*5)
: "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmul	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmul	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmul	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmul	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmul	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmul	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v17.4s, v11.s[3]  \r\n"
"	fmla	v5.4s,  v18.4s, v11.s[3]  \r\n"
"	fmla	v6.4s,  v17.4s, v12.s[0]  \r\n"
"	fmla	v7.4s,  v18.4s, v12.s[0]  \r\n"
"	fmla	v8.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v12.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v12.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v12.s[3]  \r\n"
"	fmla	v4.4s,  v19.4s, v13.s[0]  \r\n"
"	fmla	v5.4s,  v20.4s, v13.s[0]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v13.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v10.4s, v11.4s, v12.4s, v13.4s}, [%[addr_a0]] \r\n"
"ld1    {v14.4s}, [%[addr_a1]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*16),
[addr_a1] "r" (a+5*kk+1*16)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
"ld1    {v21.4s, v22.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+5*kk+0*5),
[addr_b1] "r" (b+5*kk+1*5),
[addr_b2] "r" (b+5*kk+2*5),
[addr_b3] "r" (b+5*kk+3*5)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
"ld1    {v21.4s, v22.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmul	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmul	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmul	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmul	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmul	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmul	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"	fmla	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmla	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmla	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmla	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmla	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmla	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmla	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmla	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmla	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
kk+=4;
for(; kk<k; kk+=4) {
asm volatile(
"ld1    {v10.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*4)
: "v10");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+5*(kk+0))
: "v15", "v16");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v15", "v16");
}
asm volatile(
"	fmla	v0.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v17.4s, v11.s[3]  \r\n"
"	fmla	v5.4s,  v18.4s, v11.s[3]  \r\n"
"	fmla	v6.4s,  v17.4s, v12.s[0]  \r\n"
"	fmla	v7.4s,  v18.4s, v12.s[0]  \r\n"
"	fmla	v8.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v12.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"ld1    {v11.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+1*4)
: "v11");
if constexpr(ReB) {
asm volatile(
"ld1    {v17.4s, v18.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+5*(kk+1))
: "v17", "v18");
}
else {
asm volatile(
"ld1    {v17.4s, v18.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v17", "v18");
}
asm volatile(
"	fmla	v0.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v12.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v12.s[3]  \r\n"
"	fmla	v4.4s,  v19.4s, v13.s[0]  \r\n"
"	fmla	v5.4s,  v20.4s, v13.s[0]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v13.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"ld1    {v12.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+2*4)
: "v12");
if constexpr(ReB) {
asm volatile(
"ld1    {v19.4s, v20.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+5*(kk+2))
: "v19", "v20");
}
else {
asm volatile(
"ld1    {v19.4s, v20.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v19", "v20");
}
asm volatile(
"	fmla	v0.4s,  v21.4s, v13.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v13.s[3]  \r\n"
"	fmla	v2.4s,  v21.4s, v14.s[0]  \r\n"
"	fmla	v3.4s,  v22.4s, v14.s[0]  \r\n"
"	fmla	v4.4s,  v21.4s, v14.s[1]  \r\n"
"	fmla	v5.4s,  v22.4s, v14.s[1]  \r\n"
"	fmla	v6.4s,  v21.4s, v14.s[2]  \r\n"
"	fmla	v7.4s,  v22.4s, v14.s[2]  \r\n"
"	fmla	v8.4s,  v21.4s, v14.s[3]  \r\n"
"	fmla	v9.4s,  v22.4s, v14.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"ld1    {v13.4s, v14.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+3*4)
: "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+5*(kk+3))
: "v21", "v22");
}
else {
asm volatile(
"ld1    {v21.4s, v22.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v21", "v22");
}
asm volatile(
"	fmla	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmla	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmla	v2.4s,  v15.4s, v10.s[1]  \r\n"
"	fmla	v3.4s,  v16.4s, v10.s[1]  \r\n"
"	fmla	v4.4s,  v15.4s, v10.s[2]  \r\n"
"	fmla	v5.4s,  v16.4s, v10.s[2]  \r\n"
"	fmla	v6.4s,  v15.4s, v10.s[3]  \r\n"
"	fmla	v7.4s,  v16.4s, v10.s[3]  \r\n"
"	fmla	v8.4s,  v15.4s, v11.s[0]  \r\n"
"	fmla	v9.4s,  v16.4s, v11.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"	fmla	v0.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v17.4s, v11.s[3]  \r\n"
"	fmla	v5.4s,  v18.4s, v11.s[3]  \r\n"
"	fmla	v6.4s,  v17.4s, v12.s[0]  \r\n"
"	fmla	v7.4s,  v18.4s, v12.s[0]  \r\n"
"	fmla	v8.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v12.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v12.s[3]  \r\n"
"	fmla	v3.4s,  v20.4s, v12.s[3]  \r\n"
"	fmla	v4.4s,  v19.4s, v13.s[0]  \r\n"
"	fmla	v5.4s,  v20.4s, v13.s[0]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v13.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
asm volatile(
"	fmla	v0.4s,  v21.4s, v13.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v13.s[3]  \r\n"
"	fmla	v2.4s,  v21.4s, v14.s[0]  \r\n"
"	fmla	v3.4s,  v22.4s, v14.s[0]  \r\n"
"	fmla	v4.4s,  v21.4s, v14.s[1]  \r\n"
"	fmla	v5.4s,  v22.4s, v14.s[1]  \r\n"
"	fmla	v6.4s,  v21.4s, v14.s[2]  \r\n"
"	fmla	v7.4s,  v22.4s, v14.s[2]  \r\n"
"	fmla	v8.4s,  v21.4s, v14.s[3]  \r\n"
"	fmla	v9.4s,  v22.4s, v14.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s10, [%[addr_a0]] \r\n"
"ldr    s11, [%[addr_a1]] \r\n"
"ldr    s12, [%[addr_a2]] \r\n"
"ldr    s13, [%[addr_a3]] \r\n"
"ldr    s14, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+5*(kk+0))
: "v15", "v16");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v15", "v16");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v3.4s,  v16.4s, v11.s[0]  \r\n"
"	fmul	v4.4s,  v15.4s, v12.s[0]  \r\n"
"	fmul	v5.4s,  v16.4s, v12.s[0]  \r\n"
"	fmul	v6.4s,  v15.4s, v13.s[0]  \r\n"
"	fmul	v7.4s,  v16.4s, v13.s[0]  \r\n"
"	fmul	v8.4s,  v15.4s, v14.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v14.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d10, [%[addr_a0]] \r\n"
"ldr    d11, [%[addr_a1]] \r\n"
"ldr    d12, [%[addr_a2]] \r\n"
"ldr    d13, [%[addr_a3]] \r\n"
"ldr    d14, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+5*kk+0*5),
[addr_b1] "r" (b+5*kk+1*5)
: "v15", "v16", "v17", "v18");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v15", "v16", "v17", "v18");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v3.4s,  v16.4s, v11.s[0]  \r\n"
"	fmul	v4.4s,  v15.4s, v12.s[0]  \r\n"
"	fmul	v5.4s,  v16.4s, v12.s[0]  \r\n"
"	fmul	v6.4s,  v15.4s, v13.s[0]  \r\n"
"	fmul	v7.4s,  v16.4s, v13.s[0]  \r\n"
"	fmul	v8.4s,  v15.4s, v14.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v14.s[0]  \r\n"
"	fmla	v0.4s,  v17.4s, v10.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v10.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v4.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v5.4s,  v18.4s, v12.s[1]  \r\n"
"	fmla	v6.4s,  v17.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v18.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v17.4s, v14.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v14.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q10, [%[addr_a0]] \r\n"
"ldr    q11, [%[addr_a1]] \r\n"
"ldr    q12, [%[addr_a2]] \r\n"
"ldr    q13, [%[addr_a3]] \r\n"
"ldr    q14, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+5*kk+0*5),
[addr_b1] "r" (b+5*kk+1*5),
[addr_b2] "r" (b+5*kk+2*5)
: "v15", "v16", "v17", "v18", "v19", "v20");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v15", "v16", "v17", "v18", "v19", "v20");
}
asm volatile(
"	fmul	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmul	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmul	v2.4s,  v15.4s, v11.s[0]  \r\n"
"	fmul	v3.4s,  v16.4s, v11.s[0]  \r\n"
"	fmul	v4.4s,  v15.4s, v12.s[0]  \r\n"
"	fmul	v5.4s,  v16.4s, v12.s[0]  \r\n"
"	fmul	v6.4s,  v15.4s, v13.s[0]  \r\n"
"	fmul	v7.4s,  v16.4s, v13.s[0]  \r\n"
"	fmul	v8.4s,  v15.4s, v14.s[0]  \r\n"
"	fmul	v9.4s,  v16.4s, v14.s[0]  \r\n"
"	fmla	v0.4s,  v17.4s, v10.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v10.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v4.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v5.4s,  v18.4s, v12.s[1]  \r\n"
"	fmla	v6.4s,  v17.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v18.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v17.4s, v14.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v14.s[1]  \r\n"
"	fmla	v0.4s,  v19.4s, v10.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v10.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v20.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v5.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[2]  \r\n"
"	fmla	v8.4s,  v19.4s, v14.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v14.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
"dup     v4.4s, %w[zero] \r\n"
"dup     v5.4s, %w[zero] \r\n"
"dup     v6.4s, %w[zero] \r\n"
"dup     v7.4s, %w[zero] \r\n"
"dup     v8.4s, %w[zero] \r\n"
"dup     v9.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"ldr    q10, [%[addr_a0]] \r\n"
"ldr    q11, [%[addr_a1]] \r\n"
"ldr    q12, [%[addr_a2]] \r\n"
"ldr    q13, [%[addr_a3]] \r\n"
"ldr    q14, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v10", "v11", "v12", "v13", "v14");
if constexpr(ReB) {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
"ld1    {v21.4s, v22.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+5*kk+0*5),
[addr_b1] "r" (b+5*kk+1*5),
[addr_b2] "r" (b+5*kk+2*5),
[addr_b3] "r" (b+5*kk+3*5)
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22");
}
else {
asm volatile(
"ld1    {v15.4s, v16.4s}, [%[addr_b0]] \r\n"
"ld1    {v17.4s, v18.4s}, [%[addr_b1]] \r\n"
"ld1    {v19.4s, v20.4s}, [%[addr_b2]] \r\n"
"ld1    {v21.4s, v22.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v15", "v16", "v17", "v18", "v19", "v20", "v21", "v22");
}
asm volatile(
"	fmla	v0.4s,  v15.4s, v10.s[0]  \r\n"
"	fmla	v1.4s,  v16.4s, v10.s[0]  \r\n"
"	fmla	v2.4s,  v15.4s, v11.s[0]  \r\n"
"	fmla	v3.4s,  v16.4s, v11.s[0]  \r\n"
"	fmla	v4.4s,  v15.4s, v12.s[0]  \r\n"
"	fmla	v5.4s,  v16.4s, v12.s[0]  \r\n"
"	fmla	v6.4s,  v15.4s, v13.s[0]  \r\n"
"	fmla	v7.4s,  v16.4s, v13.s[0]  \r\n"
"	fmla	v8.4s,  v15.4s, v14.s[0]  \r\n"
"	fmla	v9.4s,  v16.4s, v14.s[0]  \r\n"
"	fmla	v0.4s,  v17.4s, v10.s[1]  \r\n"
"	fmla	v1.4s,  v18.4s, v10.s[1]  \r\n"
"	fmla	v2.4s,  v17.4s, v11.s[1]  \r\n"
"	fmla	v3.4s,  v18.4s, v11.s[1]  \r\n"
"	fmla	v4.4s,  v17.4s, v12.s[1]  \r\n"
"	fmla	v5.4s,  v18.4s, v12.s[1]  \r\n"
"	fmla	v6.4s,  v17.4s, v13.s[1]  \r\n"
"	fmla	v7.4s,  v18.4s, v13.s[1]  \r\n"
"	fmla	v8.4s,  v17.4s, v14.s[1]  \r\n"
"	fmla	v9.4s,  v18.4s, v14.s[1]  \r\n"
"	fmla	v0.4s,  v19.4s, v10.s[2]  \r\n"
"	fmla	v1.4s,  v20.4s, v10.s[2]  \r\n"
"	fmla	v2.4s,  v19.4s, v11.s[2]  \r\n"
"	fmla	v3.4s,  v20.4s, v11.s[2]  \r\n"
"	fmla	v4.4s,  v19.4s, v12.s[2]  \r\n"
"	fmla	v5.4s,  v20.4s, v12.s[2]  \r\n"
"	fmla	v6.4s,  v19.4s, v13.s[2]  \r\n"
"	fmla	v7.4s,  v20.4s, v13.s[2]  \r\n"
"	fmla	v8.4s,  v19.4s, v14.s[2]  \r\n"
"	fmla	v9.4s,  v20.4s, v14.s[2]  \r\n"
"	fmla	v0.4s,  v21.4s, v10.s[3]  \r\n"
"	fmla	v1.4s,  v22.4s, v10.s[3]  \r\n"
"	fmla	v2.4s,  v21.4s, v11.s[3]  \r\n"
"	fmla	v3.4s,  v22.4s, v11.s[3]  \r\n"
"	fmla	v4.4s,  v21.4s, v12.s[3]  \r\n"
"	fmla	v5.4s,  v22.4s, v12.s[3]  \r\n"
"	fmla	v6.4s,  v21.4s, v13.s[3]  \r\n"
"	fmla	v7.4s,  v22.4s, v13.s[3]  \r\n"
"	fmla	v8.4s,  v21.4s, v14.s[3]  \r\n"
"	fmla	v9.4s,  v22.4s, v14.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v10.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v10.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v10.s[1]       \r\n"
"fmul    v3.4s,  v3.4s,  v10.s[1]       \r\n"
"fmul    v4.4s,  v4.4s,  v10.s[2]       \r\n"
"fmul    v5.4s,  v5.4s,  v10.s[2]       \r\n"
"fmul    v6.4s,  v6.4s,  v10.s[3]       \r\n"
"fmul    v7.4s,  v7.4s,  v10.s[3]       \r\n"
"fmul    v8.4s,  v8.4s,  v11.s[0]       \r\n"
"fmul    v9.4s,  v9.4s,  v11.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v20.4s, v21.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v10.4s, v11.4s}, [%[addr_c0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_c1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_c2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_c3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v10.4s,  v20.s[0]       \r\n"
"fmla    v1.4s,  v11.4s,  v20.s[0]       \r\n"
"fmla    v2.4s,  v12.4s,  v20.s[1]       \r\n"
"fmla    v3.4s,  v13.4s,  v20.s[1]       \r\n"
"fmla    v4.4s,  v14.4s,  v20.s[2]       \r\n"
"fmla    v5.4s,  v15.4s,  v20.s[2]       \r\n"
"fmla    v6.4s,  v16.4s,  v20.s[3]       \r\n"
"fmla    v7.4s,  v17.4s,  v20.s[3]       \r\n"
"fmla    v8.4s,  v18.4s,  v21.s[0]       \r\n"
"fmla    v9.4s,  v19.4s,  v21.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v10.4s, v11.4s}, [%[addr_itm0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_itm1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_itm2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_itm3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_itm4]] \r\n"
:
: [addr_itm0] "r" (itm+5*0),
[addr_itm1] "r" (itm+5*1),
[addr_itm2] "r" (itm+5*2),
[addr_itm3] "r" (itm+5*3),
[addr_itm4] "r" (itm+5*4)
: "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19");
}
else {
asm volatile(
"ld1    {v10.4s, v11.4s}, [%[addr_c0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_c1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_c2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_c3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19");
}
asm volatile(
"fadd     v0.4s, v10.4s,  v0.4s \r\n"
"fadd     v1.4s, v11.4s,  v1.4s \r\n"
"fadd     v2.4s, v12.4s,  v2.4s \r\n"
"fadd     v3.4s, v13.4s,  v3.4s \r\n"
"fadd     v4.4s, v14.4s,  v4.4s \r\n"
"fadd     v5.4s, v15.4s,  v5.4s \r\n"
"fadd     v6.4s, v16.4s,  v6.4s \r\n"
"fadd     v7.4s, v17.4s,  v7.4s \r\n"
"fadd     v8.4s, v18.4s,  v8.4s \r\n"
"fadd     v9.4s, v19.4s,  v9.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v10.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v10.s[0]       \r\n"
"fmul    v2.4s,  v2.4s,  v10.s[1]       \r\n"
"fmul    v3.4s,  v3.4s,  v10.s[1]       \r\n"
"fmul    v4.4s,  v4.4s,  v10.s[2]       \r\n"
"fmul    v5.4s,  v5.4s,  v10.s[2]       \r\n"
"fmul    v6.4s,  v6.4s,  v10.s[3]       \r\n"
"fmul    v7.4s,  v7.4s,  v10.s[3]       \r\n"
"fmul    v8.4s,  v8.4s,  v11.s[0]       \r\n"
"fmul    v9.4s,  v9.4s,  v11.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v10.4s, v11.4s}, [%[addr_c0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_c1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_c2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_c3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19");
asm volatile(
"fadd     v0.4s, v10.4s,  v0.4s \r\n"
"fadd     v1.4s, v11.4s,  v1.4s \r\n"
"fadd     v2.4s, v12.4s,  v2.4s \r\n"
"fadd     v3.4s, v13.4s,  v3.4s \r\n"
"fadd     v4.4s, v14.4s,  v4.4s \r\n"
"fadd     v5.4s, v15.4s,  v5.4s \r\n"
"fadd     v6.4s, v16.4s,  v6.4s \r\n"
"fadd     v7.4s, v17.4s,  v7.4s \r\n"
"fadd     v8.4s, v18.4s,  v8.4s \r\n"
"fadd     v9.4s, v19.4s,  v9.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v20.4s, v21.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v10.4s, v11.4s}, [%[addr_c0]] \r\n"
"ld1    {v12.4s, v13.4s}, [%[addr_c1]] \r\n"
"ld1    {v14.4s, v15.4s}, [%[addr_c2]] \r\n"
"ld1    {v16.4s, v17.4s}, [%[addr_c3]] \r\n"
"ld1    {v18.4s, v19.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v10.4s,  v20.s[0]       \r\n"
"fmla    v1.4s,  v11.4s,  v20.s[0]       \r\n"
"fmla    v2.4s,  v12.4s,  v20.s[1]       \r\n"
"fmla    v3.4s,  v13.4s,  v20.s[1]       \r\n"
"fmla    v4.4s,  v14.4s,  v20.s[2]       \r\n"
"fmla    v5.4s,  v15.4s,  v20.s[2]       \r\n"
"fmla    v6.4s,  v16.4s,  v20.s[3]       \r\n"
"fmla    v7.4s,  v17.4s,  v20.s[3]       \r\n"
"fmla    v8.4s,  v18.4s,  v21.s[0]       \r\n"
"fmla    v9.4s,  v19.4s,  v21.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12", "v13", "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_bias]] \r\n"
"dup    v12.4s, v10.s[0]               \r\n"
"dup    v13.4s, v10.s[1]               \r\n"
"dup    v14.4s, v10.s[2]               \r\n"
"dup    v15.4s, v10.s[3]               \r\n"
"dup    v16.4s, v11.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v12.4s \r\n"
"fadd     v1.4s, v1.4s,  v12.4s \r\n"
"fadd     v2.4s, v2.4s,  v13.4s \r\n"
"fadd     v3.4s, v3.4s,  v13.4s \r\n"
"fadd     v4.4s, v4.4s,  v14.4s \r\n"
"fadd     v5.4s, v5.4s,  v14.4s \r\n"
"fadd     v6.4s, v6.4s,  v15.4s \r\n"
"fadd     v7.4s, v7.4s,  v15.4s \r\n"
"fadd     v8.4s, v8.4s,  v16.4s \r\n"
"fadd     v9.4s, v9.4s,  v16.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5", "v5", "v6", "v6", "v7", "v7", "v8", "v8", "v9", "v9", "v10", "v10", "v11", "v11", "v12", "v12", "v13", "v13", "v14", "v14", "v15", "v15", "v16");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v10.4s, w9             \r\n"
"fmax    v0.4s, v10.4s,  v0.4s \r\n"
"fmax    v1.4s, v10.4s,  v1.4s \r\n"
"fmax    v2.4s, v10.4s,  v2.4s \r\n"
"fmax    v3.4s, v10.4s,  v3.4s \r\n"
"fmax    v4.4s, v10.4s,  v4.4s \r\n"
"fmax    v5.4s, v10.4s,  v5.4s \r\n"
"fmax    v6.4s, v10.4s,  v6.4s \r\n"
"fmax    v7.4s, v10.4s,  v7.4s \r\n"
"fmax    v8.4s, v10.4s,  v8.4s \r\n"
"fmax    v9.4s, v10.4s,  v9.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"str     q0, [%[addr_itm],   0] \r\n"
"str     s1, [%[addr_itm],   16] \r\n"
"str     q2, [%[addr_itm],   20] \r\n"
"str     s3, [%[addr_itm],   36] \r\n"
"str     q4, [%[addr_itm],   40] \r\n"
"str     s5, [%[addr_itm],   56] \r\n"
"str     q6, [%[addr_itm],   60] \r\n"
"str     s7, [%[addr_itm],   76] \r\n"
"str     q8, [%[addr_itm],   80] \r\n"
"str     s9, [%[addr_itm],   96] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"str     q0, [%[addr_c0],   0] \r\n"
"str     s1, [%[addr_c0],   16] \r\n"
"str     q2, [%[addr_c1],   0] \r\n"
"str     s3, [%[addr_c1],   16] \r\n"
"str     q4, [%[addr_c2],   0] \r\n"
"str     s5, [%[addr_c2],   16] \r\n"
"str     q6, [%[addr_c3],   0] \r\n"
"str     s7, [%[addr_c3],   16] \r\n"
"str     q8, [%[addr_c4],   0] \r\n"
"str     s9, [%[addr_c4],   16] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 5, 4, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v5.4s, v6.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v5", "v6");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+4*(kk+0))
: "v10");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v10");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmul	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmul	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmul	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v5", "v6", "v7");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+4*kk+0*4),
[addr_b1] "r" (b+4*kk+1*4)
: "v10", "v11");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v10", "v11");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmul	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmul	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmul	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v11.4s, v6.s[3]  \r\n"
"	fmla	v3.4s,  v11.4s, v7.s[0]  \r\n"
"	fmla	v4.4s,  v11.4s, v7.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v5", "v6", "v7", "v8");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+4*kk+0*4),
[addr_b1] "r" (b+4*kk+1*4),
[addr_b2] "r" (b+4*kk+2*4)
: "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmul	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmul	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmul	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v11.4s, v6.s[3]  \r\n"
"	fmla	v3.4s,  v11.4s, v7.s[0]  \r\n"
"	fmla	v4.4s,  v11.4s, v7.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v7.s[3]  \r\n"
"	fmla	v2.4s,  v12.4s, v8.s[0]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v12.4s, v8.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_a0]] \r\n"
"ld1    {v9.4s}, [%[addr_a1]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*16),
[addr_a1] "r" (a+5*kk+1*16)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+4*kk+0*4),
[addr_b1] "r" (b+4*kk+1*4),
[addr_b2] "r" (b+4*kk+2*4),
[addr_b3] "r" (b+4*kk+3*4)
: "v10", "v11", "v12", "v13");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v10", "v11", "v12", "v13");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmul	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmul	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmul	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
else {
asm volatile(
"	fmla	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
kk+=4;
for(; kk<k; kk+=4) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*4)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+4*(kk+0))
: "v10");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v10");
}
asm volatile(
"	fmla	v0.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v11.4s, v6.s[3]  \r\n"
"	fmla	v3.4s,  v11.4s, v7.s[0]  \r\n"
"	fmla	v4.4s,  v11.4s, v7.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"ld1    {v6.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+1*4)
: "v6");
if constexpr(ReB) {
asm volatile(
"ld1    {v11.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+4*(kk+1))
: "v11");
}
else {
asm volatile(
"ld1    {v11.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v11");
}
asm volatile(
"	fmla	v0.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v7.s[3]  \r\n"
"	fmla	v2.4s,  v12.4s, v8.s[0]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v12.4s, v8.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"ld1    {v7.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+2*4)
: "v7");
if constexpr(ReB) {
asm volatile(
"ld1    {v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+4*(kk+2))
: "v12");
}
else {
asm volatile(
"ld1    {v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v12");
}
asm volatile(
"	fmla	v0.4s,  v13.4s, v8.s[3]  \r\n"
"	fmla	v1.4s,  v13.4s, v9.s[0]  \r\n"
"	fmla	v2.4s,  v13.4s, v9.s[1]  \r\n"
"	fmla	v3.4s,  v13.4s, v9.s[2]  \r\n"
"	fmla	v4.4s,  v13.4s, v9.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"ld1    {v8.4s, v9.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+3*4)
: "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v13.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+4*(kk+3))
: "v13");
}
else {
asm volatile(
"ld1    {v13.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v13");
}
asm volatile(
"	fmla	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
asm volatile(
"	fmla	v0.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v11.4s, v6.s[3]  \r\n"
"	fmla	v3.4s,  v11.4s, v7.s[0]  \r\n"
"	fmla	v4.4s,  v11.4s, v7.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v7.s[3]  \r\n"
"	fmla	v2.4s,  v12.4s, v8.s[0]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v12.4s, v8.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v13.4s, v8.s[3]  \r\n"
"	fmla	v1.4s,  v13.4s, v9.s[0]  \r\n"
"	fmla	v2.4s,  v13.4s, v9.s[1]  \r\n"
"	fmla	v3.4s,  v13.4s, v9.s[2]  \r\n"
"	fmla	v4.4s,  v13.4s, v9.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s5, [%[addr_a0]] \r\n"
"ldr    s6, [%[addr_a1]] \r\n"
"ldr    s7, [%[addr_a2]] \r\n"
"ldr    s8, [%[addr_a3]] \r\n"
"ldr    s9, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+4*(kk+0))
: "v10");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v10");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v6.s[0]  \r\n"
"	fmul	v2.4s,  v10.4s, v7.s[0]  \r\n"
"	fmul	v3.4s,  v10.4s, v8.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v9.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d5, [%[addr_a0]] \r\n"
"ldr    d6, [%[addr_a1]] \r\n"
"ldr    d7, [%[addr_a2]] \r\n"
"ldr    d8, [%[addr_a3]] \r\n"
"ldr    d9, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+4*kk+0*4),
[addr_b1] "r" (b+4*kk+1*4)
: "v10", "v11");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v10", "v11");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v6.s[0]  \r\n"
"	fmul	v2.4s,  v10.4s, v7.s[0]  \r\n"
"	fmul	v3.4s,  v10.4s, v8.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v9.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v7.s[1]  \r\n"
"	fmla	v3.4s,  v11.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v11.4s, v9.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q5, [%[addr_a0]] \r\n"
"ldr    q6, [%[addr_a1]] \r\n"
"ldr    q7, [%[addr_a2]] \r\n"
"ldr    q8, [%[addr_a3]] \r\n"
"ldr    q9, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+4*kk+0*4),
[addr_b1] "r" (b+4*kk+1*4),
[addr_b2] "r" (b+4*kk+2*4)
: "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v6.s[0]  \r\n"
"	fmul	v2.4s,  v10.4s, v7.s[0]  \r\n"
"	fmul	v3.4s,  v10.4s, v8.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v9.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v7.s[1]  \r\n"
"	fmla	v3.4s,  v11.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v11.4s, v9.s[1]  \r\n"
"	fmla	v0.4s,  v12.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[2]  \r\n"
"	fmla	v4.4s,  v12.4s, v9.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
"dup     v4.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3", "v4");
}
asm volatile(
"ldr    q5, [%[addr_a0]] \r\n"
"ldr    q6, [%[addr_a1]] \r\n"
"ldr    q7, [%[addr_a2]] \r\n"
"ldr    q8, [%[addr_a3]] \r\n"
"ldr    q9, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+4*kk+0*4),
[addr_b1] "r" (b+4*kk+1*4),
[addr_b2] "r" (b+4*kk+2*4),
[addr_b3] "r" (b+4*kk+3*4)
: "v10", "v11", "v12", "v13");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v10", "v11", "v12", "v13");
}
asm volatile(
"	fmla	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v10.4s, v6.s[0]  \r\n"
"	fmla	v2.4s,  v10.4s, v7.s[0]  \r\n"
"	fmla	v3.4s,  v10.4s, v8.s[0]  \r\n"
"	fmla	v4.4s,  v10.4s, v9.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v7.s[1]  \r\n"
"	fmla	v3.4s,  v11.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v11.4s, v9.s[1]  \r\n"
"	fmla	v0.4s,  v12.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[2]  \r\n"
"	fmla	v4.4s,  v12.4s, v9.s[2]  \r\n"
"	fmla	v0.4s,  v13.4s, v5.s[3]  \r\n"
"	fmla	v1.4s,  v13.4s, v6.s[3]  \r\n"
"	fmla	v2.4s,  v13.4s, v7.s[3]  \r\n"
"	fmla	v3.4s,  v13.4s, v8.s[3]  \r\n"
"	fmla	v4.4s,  v13.4s, v9.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v5.4s, v6.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v5.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v5.s[1]       \r\n"
"fmul    v2.4s,  v2.4s,  v5.s[2]       \r\n"
"fmul    v3.4s,  v3.4s,  v5.s[3]       \r\n"
"fmul    v4.4s,  v4.4s,  v6.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v5.4s}, [%[addr_c0]] \r\n"
"ld1    {v6.4s}, [%[addr_c1]] \r\n"
"ld1    {v7.4s}, [%[addr_c2]] \r\n"
"ld1    {v8.4s}, [%[addr_c3]] \r\n"
"ld1    {v9.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v5.4s,  v10.s[0]       \r\n"
"fmla    v1.4s,  v6.4s,  v10.s[1]       \r\n"
"fmla    v2.4s,  v7.4s,  v10.s[2]       \r\n"
"fmla    v3.4s,  v8.4s,  v10.s[3]       \r\n"
"fmla    v4.4s,  v9.4s,  v11.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v5.4s}, [%[addr_itm0]] \r\n"
"ld1    {v6.4s}, [%[addr_itm1]] \r\n"
"ld1    {v7.4s}, [%[addr_itm2]] \r\n"
"ld1    {v8.4s}, [%[addr_itm3]] \r\n"
"ld1    {v9.4s}, [%[addr_itm4]] \r\n"
:
: [addr_itm0] "r" (itm+4*0),
[addr_itm1] "r" (itm+4*1),
[addr_itm2] "r" (itm+4*2),
[addr_itm3] "r" (itm+4*3),
[addr_itm4] "r" (itm+4*4)
: "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v5.4s}, [%[addr_c0]] \r\n"
"ld1    {v6.4s}, [%[addr_c1]] \r\n"
"ld1    {v7.4s}, [%[addr_c2]] \r\n"
"ld1    {v8.4s}, [%[addr_c3]] \r\n"
"ld1    {v9.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"fadd     v0.4s, v5.4s,  v0.4s \r\n"
"fadd     v1.4s, v6.4s,  v1.4s \r\n"
"fadd     v2.4s, v7.4s,  v2.4s \r\n"
"fadd     v3.4s, v8.4s,  v3.4s \r\n"
"fadd     v4.4s, v9.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v5.4s, v6.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v5.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v5.s[1]       \r\n"
"fmul    v2.4s,  v2.4s,  v5.s[2]       \r\n"
"fmul    v3.4s,  v3.4s,  v5.s[3]       \r\n"
"fmul    v4.4s,  v4.4s,  v6.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v5.4s}, [%[addr_c0]] \r\n"
"ld1    {v6.4s}, [%[addr_c1]] \r\n"
"ld1    {v7.4s}, [%[addr_c2]] \r\n"
"ld1    {v8.4s}, [%[addr_c3]] \r\n"
"ld1    {v9.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v5", "v6", "v7", "v8", "v9");
asm volatile(
"fadd     v0.4s, v5.4s,  v0.4s \r\n"
"fadd     v1.4s, v6.4s,  v1.4s \r\n"
"fadd     v2.4s, v7.4s,  v2.4s \r\n"
"fadd     v3.4s, v8.4s,  v3.4s \r\n"
"fadd     v4.4s, v9.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v5.4s}, [%[addr_c0]] \r\n"
"ld1    {v6.4s}, [%[addr_c1]] \r\n"
"ld1    {v7.4s}, [%[addr_c2]] \r\n"
"ld1    {v8.4s}, [%[addr_c3]] \r\n"
"ld1    {v9.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v5.4s,  v10.s[0]       \r\n"
"fmla    v1.4s,  v6.4s,  v10.s[1]       \r\n"
"fmla    v2.4s,  v7.4s,  v10.s[2]       \r\n"
"fmla    v3.4s,  v8.4s,  v10.s[3]       \r\n"
"fmla    v4.4s,  v9.4s,  v11.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v5.4s, v6.4s}, [%[addr_bias]] \r\n"
"dup    v7.4s, v5.s[0]               \r\n"
"dup    v8.4s, v5.s[1]               \r\n"
"dup    v9.4s, v5.s[2]               \r\n"
"dup    v10.4s, v5.s[3]               \r\n"
"dup    v11.4s, v6.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v7.4s \r\n"
"fadd     v1.4s, v1.4s,  v8.4s \r\n"
"fadd     v2.4s, v2.4s,  v9.4s \r\n"
"fadd     v3.4s, v3.4s,  v10.4s \r\n"
"fadd     v4.4s, v4.4s,  v11.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5", "v5", "v6", "v6", "v7", "v7", "v8", "v8", "v9", "v9", "v10", "v10", "v11");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v5.4s, w9             \r\n"
"fmax    v0.4s, v5.4s,  v0.4s \r\n"
"fmax    v1.4s, v5.4s,  v1.4s \r\n"
"fmax    v2.4s, v5.4s,  v2.4s \r\n"
"fmax    v3.4s, v5.4s,  v3.4s \r\n"
"fmax    v4.4s, v5.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"str     q0, [%[addr_itm],   0] \r\n"
"str     q1, [%[addr_itm],   16] \r\n"
"str     q2, [%[addr_itm],   32] \r\n"
"str     q3, [%[addr_itm],   48] \r\n"
"str     q4, [%[addr_itm],   64] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"str     q0, [%[addr_c0]] \r\n"
"str     q1, [%[addr_c1]] \r\n"
"str     q2, [%[addr_c2]] \r\n"
"str     q3, [%[addr_c3]] \r\n"
"str     q4, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 5, 3, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v5.4s, v6.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v5", "v6");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+3*(kk+0))
: "v10");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v10");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmul	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmul	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmul	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v5", "v6", "v7");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+3*kk+0*3),
[addr_b1] "r" (b+3*kk+1*3)
: "v10", "v11");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v10", "v11");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmul	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmul	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmul	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v11.4s, v6.s[3]  \r\n"
"	fmla	v3.4s,  v11.4s, v7.s[0]  \r\n"
"	fmla	v4.4s,  v11.4s, v7.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v5", "v6", "v7", "v8");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+3*kk+0*3),
[addr_b1] "r" (b+3*kk+1*3),
[addr_b2] "r" (b+3*kk+2*3)
: "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmul	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmul	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmul	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v11.4s, v6.s[3]  \r\n"
"	fmla	v3.4s,  v11.4s, v7.s[0]  \r\n"
"	fmla	v4.4s,  v11.4s, v7.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v7.s[3]  \r\n"
"	fmla	v2.4s,  v12.4s, v8.s[0]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v12.4s, v8.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_a0]] \r\n"
"ld1    {v9.4s}, [%[addr_a1]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*16),
[addr_a1] "r" (a+5*kk+1*16)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+3*kk+0*3),
[addr_b1] "r" (b+3*kk+1*3),
[addr_b2] "r" (b+3*kk+2*3),
[addr_b3] "r" (b+3*kk+3*3)
: "v10", "v11", "v12", "v13");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v10", "v11", "v12", "v13");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmul	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmul	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmul	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
else {
asm volatile(
"	fmla	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
kk+=4;
for(; kk<k; kk+=4) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*4)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+3*(kk+0))
: "v10");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v10");
}
asm volatile(
"	fmla	v0.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v11.4s, v6.s[3]  \r\n"
"	fmla	v3.4s,  v11.4s, v7.s[0]  \r\n"
"	fmla	v4.4s,  v11.4s, v7.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"ld1    {v6.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+1*4)
: "v6");
if constexpr(ReB) {
asm volatile(
"ld1    {v11.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+3*(kk+1))
: "v11");
}
else {
asm volatile(
"ld1    {v11.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v11");
}
asm volatile(
"	fmla	v0.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v7.s[3]  \r\n"
"	fmla	v2.4s,  v12.4s, v8.s[0]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v12.4s, v8.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"ld1    {v7.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+2*4)
: "v7");
if constexpr(ReB) {
asm volatile(
"ld1    {v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+3*(kk+2))
: "v12");
}
else {
asm volatile(
"ld1    {v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v12");
}
asm volatile(
"	fmla	v0.4s,  v13.4s, v8.s[3]  \r\n"
"	fmla	v1.4s,  v13.4s, v9.s[0]  \r\n"
"	fmla	v2.4s,  v13.4s, v9.s[1]  \r\n"
"	fmla	v3.4s,  v13.4s, v9.s[2]  \r\n"
"	fmla	v4.4s,  v13.4s, v9.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"ld1    {v8.4s, v9.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+3*4)
: "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v13.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+3*(kk+3))
: "v13");
}
else {
asm volatile(
"ld1    {v13.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v13");
}
asm volatile(
"	fmla	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
asm volatile(
"	fmla	v0.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v11.4s, v6.s[3]  \r\n"
"	fmla	v3.4s,  v11.4s, v7.s[0]  \r\n"
"	fmla	v4.4s,  v11.4s, v7.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v7.s[3]  \r\n"
"	fmla	v2.4s,  v12.4s, v8.s[0]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v12.4s, v8.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v13.4s, v8.s[3]  \r\n"
"	fmla	v1.4s,  v13.4s, v9.s[0]  \r\n"
"	fmla	v2.4s,  v13.4s, v9.s[1]  \r\n"
"	fmla	v3.4s,  v13.4s, v9.s[2]  \r\n"
"	fmla	v4.4s,  v13.4s, v9.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s5, [%[addr_a0]] \r\n"
"ldr    s6, [%[addr_a1]] \r\n"
"ldr    s7, [%[addr_a2]] \r\n"
"ldr    s8, [%[addr_a3]] \r\n"
"ldr    s9, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+3*(kk+0))
: "v10");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v10");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v6.s[0]  \r\n"
"	fmul	v2.4s,  v10.4s, v7.s[0]  \r\n"
"	fmul	v3.4s,  v10.4s, v8.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v9.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d5, [%[addr_a0]] \r\n"
"ldr    d6, [%[addr_a1]] \r\n"
"ldr    d7, [%[addr_a2]] \r\n"
"ldr    d8, [%[addr_a3]] \r\n"
"ldr    d9, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+3*kk+0*3),
[addr_b1] "r" (b+3*kk+1*3)
: "v10", "v11");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v10", "v11");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v6.s[0]  \r\n"
"	fmul	v2.4s,  v10.4s, v7.s[0]  \r\n"
"	fmul	v3.4s,  v10.4s, v8.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v9.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v7.s[1]  \r\n"
"	fmla	v3.4s,  v11.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v11.4s, v9.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q5, [%[addr_a0]] \r\n"
"ldr    q6, [%[addr_a1]] \r\n"
"ldr    q7, [%[addr_a2]] \r\n"
"ldr    q8, [%[addr_a3]] \r\n"
"ldr    q9, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+3*kk+0*3),
[addr_b1] "r" (b+3*kk+1*3),
[addr_b2] "r" (b+3*kk+2*3)
: "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v6.s[0]  \r\n"
"	fmul	v2.4s,  v10.4s, v7.s[0]  \r\n"
"	fmul	v3.4s,  v10.4s, v8.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v9.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v7.s[1]  \r\n"
"	fmla	v3.4s,  v11.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v11.4s, v9.s[1]  \r\n"
"	fmla	v0.4s,  v12.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[2]  \r\n"
"	fmla	v4.4s,  v12.4s, v9.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
"dup     v4.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3", "v4");
}
asm volatile(
"ldr    q5, [%[addr_a0]] \r\n"
"ldr    q6, [%[addr_a1]] \r\n"
"ldr    q7, [%[addr_a2]] \r\n"
"ldr    q8, [%[addr_a3]] \r\n"
"ldr    q9, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+3*kk+0*3),
[addr_b1] "r" (b+3*kk+1*3),
[addr_b2] "r" (b+3*kk+2*3),
[addr_b3] "r" (b+3*kk+3*3)
: "v10", "v11", "v12", "v13");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v10", "v11", "v12", "v13");
}
asm volatile(
"	fmla	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v10.4s, v6.s[0]  \r\n"
"	fmla	v2.4s,  v10.4s, v7.s[0]  \r\n"
"	fmla	v3.4s,  v10.4s, v8.s[0]  \r\n"
"	fmla	v4.4s,  v10.4s, v9.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v7.s[1]  \r\n"
"	fmla	v3.4s,  v11.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v11.4s, v9.s[1]  \r\n"
"	fmla	v0.4s,  v12.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[2]  \r\n"
"	fmla	v4.4s,  v12.4s, v9.s[2]  \r\n"
"	fmla	v0.4s,  v13.4s, v5.s[3]  \r\n"
"	fmla	v1.4s,  v13.4s, v6.s[3]  \r\n"
"	fmla	v2.4s,  v13.4s, v7.s[3]  \r\n"
"	fmla	v3.4s,  v13.4s, v8.s[3]  \r\n"
"	fmla	v4.4s,  v13.4s, v9.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v5.4s, v6.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v5.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v5.s[1]       \r\n"
"fmul    v2.4s,  v2.4s,  v5.s[2]       \r\n"
"fmul    v3.4s,  v3.4s,  v5.s[3]       \r\n"
"fmul    v4.4s,  v4.4s,  v6.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v5.4s}, [%[addr_c0]] \r\n"
"ld1    {v6.4s}, [%[addr_c1]] \r\n"
"ld1    {v7.4s}, [%[addr_c2]] \r\n"
"ld1    {v8.4s}, [%[addr_c3]] \r\n"
"ld1    {v9.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v5.4s,  v10.s[0]       \r\n"
"fmla    v1.4s,  v6.4s,  v10.s[1]       \r\n"
"fmla    v2.4s,  v7.4s,  v10.s[2]       \r\n"
"fmla    v3.4s,  v8.4s,  v10.s[3]       \r\n"
"fmla    v4.4s,  v9.4s,  v11.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v5.4s}, [%[addr_itm0]] \r\n"
"ld1    {v6.4s}, [%[addr_itm1]] \r\n"
"ld1    {v7.4s}, [%[addr_itm2]] \r\n"
"ld1    {v8.4s}, [%[addr_itm3]] \r\n"
"ld1    {v9.4s}, [%[addr_itm4]] \r\n"
:
: [addr_itm0] "r" (itm+3*0),
[addr_itm1] "r" (itm+3*1),
[addr_itm2] "r" (itm+3*2),
[addr_itm3] "r" (itm+3*3),
[addr_itm4] "r" (itm+3*4)
: "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v5.4s}, [%[addr_c0]] \r\n"
"ld1    {v6.4s}, [%[addr_c1]] \r\n"
"ld1    {v7.4s}, [%[addr_c2]] \r\n"
"ld1    {v8.4s}, [%[addr_c3]] \r\n"
"ld1    {v9.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"fadd     v0.4s, v5.4s,  v0.4s \r\n"
"fadd     v1.4s, v6.4s,  v1.4s \r\n"
"fadd     v2.4s, v7.4s,  v2.4s \r\n"
"fadd     v3.4s, v8.4s,  v3.4s \r\n"
"fadd     v4.4s, v9.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v5.4s, v6.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v5.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v5.s[1]       \r\n"
"fmul    v2.4s,  v2.4s,  v5.s[2]       \r\n"
"fmul    v3.4s,  v3.4s,  v5.s[3]       \r\n"
"fmul    v4.4s,  v4.4s,  v6.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v5.4s}, [%[addr_c0]] \r\n"
"ld1    {v6.4s}, [%[addr_c1]] \r\n"
"ld1    {v7.4s}, [%[addr_c2]] \r\n"
"ld1    {v8.4s}, [%[addr_c3]] \r\n"
"ld1    {v9.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v5", "v6", "v7", "v8", "v9");
asm volatile(
"fadd     v0.4s, v5.4s,  v0.4s \r\n"
"fadd     v1.4s, v6.4s,  v1.4s \r\n"
"fadd     v2.4s, v7.4s,  v2.4s \r\n"
"fadd     v3.4s, v8.4s,  v3.4s \r\n"
"fadd     v4.4s, v9.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v5.4s}, [%[addr_c0]] \r\n"
"ld1    {v6.4s}, [%[addr_c1]] \r\n"
"ld1    {v7.4s}, [%[addr_c2]] \r\n"
"ld1    {v8.4s}, [%[addr_c3]] \r\n"
"ld1    {v9.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v5.4s,  v10.s[0]       \r\n"
"fmla    v1.4s,  v6.4s,  v10.s[1]       \r\n"
"fmla    v2.4s,  v7.4s,  v10.s[2]       \r\n"
"fmla    v3.4s,  v8.4s,  v10.s[3]       \r\n"
"fmla    v4.4s,  v9.4s,  v11.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v5.4s, v6.4s}, [%[addr_bias]] \r\n"
"dup    v7.4s, v5.s[0]               \r\n"
"dup    v8.4s, v5.s[1]               \r\n"
"dup    v9.4s, v5.s[2]               \r\n"
"dup    v10.4s, v5.s[3]               \r\n"
"dup    v11.4s, v6.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v7.4s \r\n"
"fadd     v1.4s, v1.4s,  v8.4s \r\n"
"fadd     v2.4s, v2.4s,  v9.4s \r\n"
"fadd     v3.4s, v3.4s,  v10.4s \r\n"
"fadd     v4.4s, v4.4s,  v11.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5", "v5", "v6", "v6", "v7", "v7", "v8", "v8", "v9", "v9", "v10", "v10", "v11");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v5.4s, w9             \r\n"
"fmax    v0.4s, v5.4s,  v0.4s \r\n"
"fmax    v1.4s, v5.4s,  v1.4s \r\n"
"fmax    v2.4s, v5.4s,  v2.4s \r\n"
"fmax    v3.4s, v5.4s,  v3.4s \r\n"
"fmax    v4.4s, v5.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"mov    s5,  v0.s[2]           \r\n"
"mov    s6,  v1.s[2]           \r\n"
"mov    s7,  v2.s[2]           \r\n"
"mov    s8,  v3.s[2]           \r\n"
"mov    s9,  v4.s[2]           \r\n"
"str     d0, [%[addr_itm],   0] \r\n"
"str     s5, [%[addr_itm],   8] \r\n"
"str     d1, [%[addr_itm],   12] \r\n"
"str     s6, [%[addr_itm],   20] \r\n"
"str     d2, [%[addr_itm],   24] \r\n"
"str     s7, [%[addr_itm],   32] \r\n"
"str     d3, [%[addr_itm],   36] \r\n"
"str     s8, [%[addr_itm],   44] \r\n"
"str     d4, [%[addr_itm],   48] \r\n"
"str     s9, [%[addr_itm],   56] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"mov    s5,  v0.s[2]           \r\n"
"mov    s6,  v1.s[2]           \r\n"
"mov    s7,  v2.s[2]           \r\n"
"mov    s8,  v3.s[2]           \r\n"
"mov    s9,  v4.s[2]           \r\n"
"str     d0, [%[addr_c0],   0] \r\n"
"str     s5, [%[addr_c0],   8] \r\n"
"str     d1, [%[addr_c1],   0] \r\n"
"str     s6, [%[addr_c1],   8] \r\n"
"str     d2, [%[addr_c2],   0] \r\n"
"str     s7, [%[addr_c2],   8] \r\n"
"str     d3, [%[addr_c3],   0] \r\n"
"str     s8, [%[addr_c3],   8] \r\n"
"str     d4, [%[addr_c4],   0] \r\n"
"str     s9, [%[addr_c4],   8] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 5, 2, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v5.4s, v6.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v5", "v6");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+2*(kk+0))
: "v10");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v10");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmul	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmul	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmul	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v5", "v6", "v7");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+2*kk+0*2),
[addr_b1] "r" (b+2*kk+1*2)
: "v10", "v11");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v10", "v11");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmul	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmul	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmul	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v11.4s, v6.s[3]  \r\n"
"	fmla	v3.4s,  v11.4s, v7.s[0]  \r\n"
"	fmla	v4.4s,  v11.4s, v7.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v5", "v6", "v7", "v8");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+2*kk+0*2),
[addr_b1] "r" (b+2*kk+1*2),
[addr_b2] "r" (b+2*kk+2*2)
: "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmul	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmul	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmul	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v11.4s, v6.s[3]  \r\n"
"	fmla	v3.4s,  v11.4s, v7.s[0]  \r\n"
"	fmla	v4.4s,  v11.4s, v7.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v7.s[3]  \r\n"
"	fmla	v2.4s,  v12.4s, v8.s[0]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v12.4s, v8.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_a0]] \r\n"
"ld1    {v9.4s}, [%[addr_a1]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*16),
[addr_a1] "r" (a+5*kk+1*16)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+2*kk+0*2),
[addr_b1] "r" (b+2*kk+1*2),
[addr_b2] "r" (b+2*kk+2*2),
[addr_b3] "r" (b+2*kk+3*2)
: "v10", "v11", "v12", "v13");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v10", "v11", "v12", "v13");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmul	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmul	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmul	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
else {
asm volatile(
"	fmla	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
kk+=4;
for(; kk<k; kk+=4) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*4)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+2*(kk+0))
: "v10");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v10");
}
asm volatile(
"	fmla	v0.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v11.4s, v6.s[3]  \r\n"
"	fmla	v3.4s,  v11.4s, v7.s[0]  \r\n"
"	fmla	v4.4s,  v11.4s, v7.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"ld1    {v6.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+1*4)
: "v6");
if constexpr(ReB) {
asm volatile(
"ld1    {v11.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+2*(kk+1))
: "v11");
}
else {
asm volatile(
"ld1    {v11.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v11");
}
asm volatile(
"	fmla	v0.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v7.s[3]  \r\n"
"	fmla	v2.4s,  v12.4s, v8.s[0]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v12.4s, v8.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"ld1    {v7.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+2*4)
: "v7");
if constexpr(ReB) {
asm volatile(
"ld1    {v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+2*(kk+2))
: "v12");
}
else {
asm volatile(
"ld1    {v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v12");
}
asm volatile(
"	fmla	v0.4s,  v13.4s, v8.s[3]  \r\n"
"	fmla	v1.4s,  v13.4s, v9.s[0]  \r\n"
"	fmla	v2.4s,  v13.4s, v9.s[1]  \r\n"
"	fmla	v3.4s,  v13.4s, v9.s[2]  \r\n"
"	fmla	v4.4s,  v13.4s, v9.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"ld1    {v8.4s, v9.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+3*4)
: "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v13.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+2*(kk+3))
: "v13");
}
else {
asm volatile(
"ld1    {v13.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v13");
}
asm volatile(
"	fmla	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
asm volatile(
"	fmla	v0.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v11.4s, v6.s[3]  \r\n"
"	fmla	v3.4s,  v11.4s, v7.s[0]  \r\n"
"	fmla	v4.4s,  v11.4s, v7.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v7.s[3]  \r\n"
"	fmla	v2.4s,  v12.4s, v8.s[0]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v12.4s, v8.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v13.4s, v8.s[3]  \r\n"
"	fmla	v1.4s,  v13.4s, v9.s[0]  \r\n"
"	fmla	v2.4s,  v13.4s, v9.s[1]  \r\n"
"	fmla	v3.4s,  v13.4s, v9.s[2]  \r\n"
"	fmla	v4.4s,  v13.4s, v9.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s5, [%[addr_a0]] \r\n"
"ldr    s6, [%[addr_a1]] \r\n"
"ldr    s7, [%[addr_a2]] \r\n"
"ldr    s8, [%[addr_a3]] \r\n"
"ldr    s9, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+2*(kk+0))
: "v10");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v10");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v6.s[0]  \r\n"
"	fmul	v2.4s,  v10.4s, v7.s[0]  \r\n"
"	fmul	v3.4s,  v10.4s, v8.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v9.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d5, [%[addr_a0]] \r\n"
"ldr    d6, [%[addr_a1]] \r\n"
"ldr    d7, [%[addr_a2]] \r\n"
"ldr    d8, [%[addr_a3]] \r\n"
"ldr    d9, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+2*kk+0*2),
[addr_b1] "r" (b+2*kk+1*2)
: "v10", "v11");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v10", "v11");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v6.s[0]  \r\n"
"	fmul	v2.4s,  v10.4s, v7.s[0]  \r\n"
"	fmul	v3.4s,  v10.4s, v8.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v9.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v7.s[1]  \r\n"
"	fmla	v3.4s,  v11.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v11.4s, v9.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q5, [%[addr_a0]] \r\n"
"ldr    q6, [%[addr_a1]] \r\n"
"ldr    q7, [%[addr_a2]] \r\n"
"ldr    q8, [%[addr_a3]] \r\n"
"ldr    q9, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+2*kk+0*2),
[addr_b1] "r" (b+2*kk+1*2),
[addr_b2] "r" (b+2*kk+2*2)
: "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v6.s[0]  \r\n"
"	fmul	v2.4s,  v10.4s, v7.s[0]  \r\n"
"	fmul	v3.4s,  v10.4s, v8.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v9.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v7.s[1]  \r\n"
"	fmla	v3.4s,  v11.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v11.4s, v9.s[1]  \r\n"
"	fmla	v0.4s,  v12.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[2]  \r\n"
"	fmla	v4.4s,  v12.4s, v9.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
"dup     v4.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3", "v4");
}
asm volatile(
"ldr    q5, [%[addr_a0]] \r\n"
"ldr    q6, [%[addr_a1]] \r\n"
"ldr    q7, [%[addr_a2]] \r\n"
"ldr    q8, [%[addr_a3]] \r\n"
"ldr    q9, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+2*kk+0*2),
[addr_b1] "r" (b+2*kk+1*2),
[addr_b2] "r" (b+2*kk+2*2),
[addr_b3] "r" (b+2*kk+3*2)
: "v10", "v11", "v12", "v13");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v10", "v11", "v12", "v13");
}
asm volatile(
"	fmla	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v10.4s, v6.s[0]  \r\n"
"	fmla	v2.4s,  v10.4s, v7.s[0]  \r\n"
"	fmla	v3.4s,  v10.4s, v8.s[0]  \r\n"
"	fmla	v4.4s,  v10.4s, v9.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v7.s[1]  \r\n"
"	fmla	v3.4s,  v11.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v11.4s, v9.s[1]  \r\n"
"	fmla	v0.4s,  v12.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[2]  \r\n"
"	fmla	v4.4s,  v12.4s, v9.s[2]  \r\n"
"	fmla	v0.4s,  v13.4s, v5.s[3]  \r\n"
"	fmla	v1.4s,  v13.4s, v6.s[3]  \r\n"
"	fmla	v2.4s,  v13.4s, v7.s[3]  \r\n"
"	fmla	v3.4s,  v13.4s, v8.s[3]  \r\n"
"	fmla	v4.4s,  v13.4s, v9.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v5.4s, v6.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v5.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v5.s[1]       \r\n"
"fmul    v2.4s,  v2.4s,  v5.s[2]       \r\n"
"fmul    v3.4s,  v3.4s,  v5.s[3]       \r\n"
"fmul    v4.4s,  v4.4s,  v6.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v5.4s}, [%[addr_c0]] \r\n"
"ld1    {v6.4s}, [%[addr_c1]] \r\n"
"ld1    {v7.4s}, [%[addr_c2]] \r\n"
"ld1    {v8.4s}, [%[addr_c3]] \r\n"
"ld1    {v9.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v5.4s,  v10.s[0]       \r\n"
"fmla    v1.4s,  v6.4s,  v10.s[1]       \r\n"
"fmla    v2.4s,  v7.4s,  v10.s[2]       \r\n"
"fmla    v3.4s,  v8.4s,  v10.s[3]       \r\n"
"fmla    v4.4s,  v9.4s,  v11.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v5.4s}, [%[addr_itm0]] \r\n"
"ld1    {v6.4s}, [%[addr_itm1]] \r\n"
"ld1    {v7.4s}, [%[addr_itm2]] \r\n"
"ld1    {v8.4s}, [%[addr_itm3]] \r\n"
"ld1    {v9.4s}, [%[addr_itm4]] \r\n"
:
: [addr_itm0] "r" (itm+2*0),
[addr_itm1] "r" (itm+2*1),
[addr_itm2] "r" (itm+2*2),
[addr_itm3] "r" (itm+2*3),
[addr_itm4] "r" (itm+2*4)
: "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v5.4s}, [%[addr_c0]] \r\n"
"ld1    {v6.4s}, [%[addr_c1]] \r\n"
"ld1    {v7.4s}, [%[addr_c2]] \r\n"
"ld1    {v8.4s}, [%[addr_c3]] \r\n"
"ld1    {v9.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"fadd     v0.4s, v5.4s,  v0.4s \r\n"
"fadd     v1.4s, v6.4s,  v1.4s \r\n"
"fadd     v2.4s, v7.4s,  v2.4s \r\n"
"fadd     v3.4s, v8.4s,  v3.4s \r\n"
"fadd     v4.4s, v9.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v5.4s, v6.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v5.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v5.s[1]       \r\n"
"fmul    v2.4s,  v2.4s,  v5.s[2]       \r\n"
"fmul    v3.4s,  v3.4s,  v5.s[3]       \r\n"
"fmul    v4.4s,  v4.4s,  v6.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v5.4s}, [%[addr_c0]] \r\n"
"ld1    {v6.4s}, [%[addr_c1]] \r\n"
"ld1    {v7.4s}, [%[addr_c2]] \r\n"
"ld1    {v8.4s}, [%[addr_c3]] \r\n"
"ld1    {v9.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v5", "v6", "v7", "v8", "v9");
asm volatile(
"fadd     v0.4s, v5.4s,  v0.4s \r\n"
"fadd     v1.4s, v6.4s,  v1.4s \r\n"
"fadd     v2.4s, v7.4s,  v2.4s \r\n"
"fadd     v3.4s, v8.4s,  v3.4s \r\n"
"fadd     v4.4s, v9.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v5.4s}, [%[addr_c0]] \r\n"
"ld1    {v6.4s}, [%[addr_c1]] \r\n"
"ld1    {v7.4s}, [%[addr_c2]] \r\n"
"ld1    {v8.4s}, [%[addr_c3]] \r\n"
"ld1    {v9.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v5.4s,  v10.s[0]       \r\n"
"fmla    v1.4s,  v6.4s,  v10.s[1]       \r\n"
"fmla    v2.4s,  v7.4s,  v10.s[2]       \r\n"
"fmla    v3.4s,  v8.4s,  v10.s[3]       \r\n"
"fmla    v4.4s,  v9.4s,  v11.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v5.4s, v6.4s}, [%[addr_bias]] \r\n"
"dup    v7.4s, v5.s[0]               \r\n"
"dup    v8.4s, v5.s[1]               \r\n"
"dup    v9.4s, v5.s[2]               \r\n"
"dup    v10.4s, v5.s[3]               \r\n"
"dup    v11.4s, v6.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v7.4s \r\n"
"fadd     v1.4s, v1.4s,  v8.4s \r\n"
"fadd     v2.4s, v2.4s,  v9.4s \r\n"
"fadd     v3.4s, v3.4s,  v10.4s \r\n"
"fadd     v4.4s, v4.4s,  v11.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5", "v5", "v6", "v6", "v7", "v7", "v8", "v8", "v9", "v9", "v10", "v10", "v11");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v5.4s, w9             \r\n"
"fmax    v0.4s, v5.4s,  v0.4s \r\n"
"fmax    v1.4s, v5.4s,  v1.4s \r\n"
"fmax    v2.4s, v5.4s,  v2.4s \r\n"
"fmax    v3.4s, v5.4s,  v3.4s \r\n"
"fmax    v4.4s, v5.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"str     d0, [%[addr_itm],   0] \r\n"
"str     d1, [%[addr_itm],   8] \r\n"
"str     d2, [%[addr_itm],   16] \r\n"
"str     d3, [%[addr_itm],   24] \r\n"
"str     d4, [%[addr_itm],   32] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"str     d0, [%[addr_c0],   0] \r\n"
"str     d1, [%[addr_c1],   0] \r\n"
"str     d2, [%[addr_c2],   0] \r\n"
"str     d3, [%[addr_c3],   0] \r\n"
"str     d4, [%[addr_c4],   0] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "memory");}
}
};

template <typename Lhs, typename Rhs, typename Res, typename Itm, bool ReA, bool ReB, bool ReC, bool Load,
    bool Itm2Res, bool Blend, bool RScale, bool RScaleBlend, bool RBias, bool ReLU, bool FstIter>
struct GEMMKernel<Lhs, Rhs, Res, Itm, float, 5, 1, ReA, ReB, ReC, Load, Itm2Res, Blend, RScale, RScaleBlend, RBias, ReLU, FstIter> {
  static inline void Run(int k, const Lhs* a, int lda, const Rhs* b, int ldb, Res* c, int ldc, Itm* itm, const Res* rscale, const Res* rscale_blend, const Res* rbias) {
    int kk=0;
if constexpr(ReA) {
if(k%4==1) {
asm volatile(
"ld1    {v5.4s, v6.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v5", "v6");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+1*(kk+0))
: "v10");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v10");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmul	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmul	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmul	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=1;
}
if(k%4==2) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v5", "v6", "v7");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+1*kk+0*1),
[addr_b1] "r" (b+1*kk+1*1)
: "v10", "v11");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v10", "v11");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmul	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmul	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmul	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v11.4s, v6.s[3]  \r\n"
"	fmla	v3.4s,  v11.4s, v7.s[0]  \r\n"
"	fmla	v4.4s,  v11.4s, v7.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=2;
}
if(k%4==3) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*(kk+0))
: "v5", "v6", "v7", "v8");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+1*kk+0*1),
[addr_b1] "r" (b+1*kk+1*1),
[addr_b2] "r" (b+1*kk+2*1)
: "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmul	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmul	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmul	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v11.4s, v6.s[3]  \r\n"
"	fmla	v3.4s,  v11.4s, v7.s[0]  \r\n"
"	fmla	v4.4s,  v11.4s, v7.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v7.s[3]  \r\n"
"	fmla	v2.4s,  v12.4s, v8.s[0]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v12.4s, v8.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=3;
}
if(kk<k) {
asm volatile(
"ld1    {v5.4s, v6.4s, v7.4s, v8.4s}, [%[addr_a0]] \r\n"
"ld1    {v9.4s}, [%[addr_a1]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*16),
[addr_a1] "r" (a+5*kk+1*16)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+1*kk+0*1),
[addr_b1] "r" (b+1*kk+1*1),
[addr_b2] "r" (b+1*kk+2*1),
[addr_b3] "r" (b+1*kk+3*1)
: "v10", "v11", "v12", "v13");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v10", "v11", "v12", "v13");
}
if(kk==0) {
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmul	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmul	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmul	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
else {
asm volatile(
"	fmla	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
kk+=4;
for(; kk<k; kk+=4) {
asm volatile(
"ld1    {v5.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+0*4)
: "v5");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+1*(kk+0))
: "v10");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v10");
}
asm volatile(
"	fmla	v0.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v11.4s, v6.s[3]  \r\n"
"	fmla	v3.4s,  v11.4s, v7.s[0]  \r\n"
"	fmla	v4.4s,  v11.4s, v7.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"ld1    {v6.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+1*4)
: "v6");
if constexpr(ReB) {
asm volatile(
"ld1    {v11.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+1*(kk+1))
: "v11");
}
else {
asm volatile(
"ld1    {v11.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+1))
: "v11");
}
asm volatile(
"	fmla	v0.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v7.s[3]  \r\n"
"	fmla	v2.4s,  v12.4s, v8.s[0]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v12.4s, v8.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"ld1    {v7.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+2*4)
: "v7");
if constexpr(ReB) {
asm volatile(
"ld1    {v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+1*(kk+2))
: "v12");
}
else {
asm volatile(
"ld1    {v12.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+2))
: "v12");
}
asm volatile(
"	fmla	v0.4s,  v13.4s, v8.s[3]  \r\n"
"	fmla	v1.4s,  v13.4s, v9.s[0]  \r\n"
"	fmla	v2.4s,  v13.4s, v9.s[1]  \r\n"
"	fmla	v3.4s,  v13.4s, v9.s[2]  \r\n"
"	fmla	v4.4s,  v13.4s, v9.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"ld1    {v8.4s, v9.4s}, [%[addr_a0]] \r\n"
:
: [addr_a0] "r" (a+5*kk+3*4)
: "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v13.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+1*(kk+3))
: "v13");
}
else {
asm volatile(
"ld1    {v13.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+3))
: "v13");
}
asm volatile(
"	fmla	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v10.4s, v5.s[1]  \r\n"
"	fmla	v2.4s,  v10.4s, v5.s[2]  \r\n"
"	fmla	v3.4s,  v10.4s, v5.s[3]  \r\n"
"	fmla	v4.4s,  v10.4s, v6.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
asm volatile(
"	fmla	v0.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v11.4s, v6.s[3]  \r\n"
"	fmla	v3.4s,  v11.4s, v7.s[0]  \r\n"
"	fmla	v4.4s,  v11.4s, v7.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v7.s[3]  \r\n"
"	fmla	v2.4s,  v12.4s, v8.s[0]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v12.4s, v8.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
asm volatile(
"	fmla	v0.4s,  v13.4s, v8.s[3]  \r\n"
"	fmla	v1.4s,  v13.4s, v9.s[0]  \r\n"
"	fmla	v2.4s,  v13.4s, v9.s[1]  \r\n"
"	fmla	v3.4s,  v13.4s, v9.s[2]  \r\n"
"	fmla	v4.4s,  v13.4s, v9.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
else {
if(k%4==1) {
asm volatile(
"ldr    s5, [%[addr_a0]] \r\n"
"ldr    s6, [%[addr_a1]] \r\n"
"ldr    s7, [%[addr_a2]] \r\n"
"ldr    s8, [%[addr_a3]] \r\n"
"ldr    s9, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+1*(kk+0))
: "v10");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0))
: "v10");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v6.s[0]  \r\n"
"	fmul	v2.4s,  v10.4s, v7.s[0]  \r\n"
"	fmul	v3.4s,  v10.4s, v8.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v9.s[0]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=1;
}
if(k%4==2) {
asm volatile(
"ldr    d5, [%[addr_a0]] \r\n"
"ldr    d6, [%[addr_a1]] \r\n"
"ldr    d7, [%[addr_a2]] \r\n"
"ldr    d8, [%[addr_a3]] \r\n"
"ldr    d9, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+1*kk+0*1),
[addr_b1] "r" (b+1*kk+1*1)
: "v10", "v11");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1))
: "v10", "v11");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v6.s[0]  \r\n"
"	fmul	v2.4s,  v10.4s, v7.s[0]  \r\n"
"	fmul	v3.4s,  v10.4s, v8.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v9.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v7.s[1]  \r\n"
"	fmla	v3.4s,  v11.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v11.4s, v9.s[1]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=2;
}
if(k%4==3) {
asm volatile(
"ldr    q5, [%[addr_a0]] \r\n"
"ldr    q6, [%[addr_a1]] \r\n"
"ldr    q7, [%[addr_a2]] \r\n"
"ldr    q8, [%[addr_a3]] \r\n"
"ldr    q9, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+1*kk+0*1),
[addr_b1] "r" (b+1*kk+1*1),
[addr_b2] "r" (b+1*kk+2*1)
: "v10", "v11", "v12");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2))
: "v10", "v11", "v12");
}
asm volatile(
"	fmul	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmul	v1.4s,  v10.4s, v6.s[0]  \r\n"
"	fmul	v2.4s,  v10.4s, v7.s[0]  \r\n"
"	fmul	v3.4s,  v10.4s, v8.s[0]  \r\n"
"	fmul	v4.4s,  v10.4s, v9.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v7.s[1]  \r\n"
"	fmla	v3.4s,  v11.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v11.4s, v9.s[1]  \r\n"
"	fmla	v0.4s,  v12.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[2]  \r\n"
"	fmla	v4.4s,  v12.4s, v9.s[2]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
kk=3;
}
for(; kk<k; kk+=4) {
if(kk==0) {
asm volatile(
"dup     v0.4s, %w[zero] \r\n"
"dup     v1.4s, %w[zero] \r\n"
"dup     v2.4s, %w[zero] \r\n"
"dup     v3.4s, %w[zero] \r\n"
"dup     v4.4s, %w[zero] \r\n"
:
: [zero] "r" (0.0f): "v0", "v1", "v2", "v3", "v4");
}
asm volatile(
"ldr    q5, [%[addr_a0]] \r\n"
"ldr    q6, [%[addr_a1]] \r\n"
"ldr    q7, [%[addr_a2]] \r\n"
"ldr    q8, [%[addr_a3]] \r\n"
"ldr    q9, [%[addr_a4]] \r\n"
:
:[addr_a0] "r" (a+lda*0+kk),
[addr_a1] "r" (a+lda*1+kk),
[addr_a2] "r" (a+lda*2+kk),
[addr_a3] "r" (a+lda*3+kk),
[addr_a4] "r" (a+lda*4+kk)
: "v5", "v6", "v7", "v8", "v9");
if constexpr(ReB) {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+1*kk+0*1),
[addr_b1] "r" (b+1*kk+1*1),
[addr_b2] "r" (b+1*kk+2*1),
[addr_b3] "r" (b+1*kk+3*1)
: "v10", "v11", "v12", "v13");
}
else {
asm volatile(
"ld1    {v10.4s}, [%[addr_b0]] \r\n"
"ld1    {v11.4s}, [%[addr_b1]] \r\n"
"ld1    {v12.4s}, [%[addr_b2]] \r\n"
"ld1    {v13.4s}, [%[addr_b3]] \r\n"
:
: [addr_b0] "r" (b+ldb*(kk+0)),
[addr_b1] "r" (b+ldb*(kk+1)),
[addr_b2] "r" (b+ldb*(kk+2)),
[addr_b3] "r" (b+ldb*(kk+3))
: "v10", "v11", "v12", "v13");
}
asm volatile(
"	fmla	v0.4s,  v10.4s, v5.s[0]  \r\n"
"	fmla	v1.4s,  v10.4s, v6.s[0]  \r\n"
"	fmla	v2.4s,  v10.4s, v7.s[0]  \r\n"
"	fmla	v3.4s,  v10.4s, v8.s[0]  \r\n"
"	fmla	v4.4s,  v10.4s, v9.s[0]  \r\n"
"	fmla	v0.4s,  v11.4s, v5.s[1]  \r\n"
"	fmla	v1.4s,  v11.4s, v6.s[1]  \r\n"
"	fmla	v2.4s,  v11.4s, v7.s[1]  \r\n"
"	fmla	v3.4s,  v11.4s, v8.s[1]  \r\n"
"	fmla	v4.4s,  v11.4s, v9.s[1]  \r\n"
"	fmla	v0.4s,  v12.4s, v5.s[2]  \r\n"
"	fmla	v1.4s,  v12.4s, v6.s[2]  \r\n"
"	fmla	v2.4s,  v12.4s, v7.s[2]  \r\n"
"	fmla	v3.4s,  v12.4s, v8.s[2]  \r\n"
"	fmla	v4.4s,  v12.4s, v9.s[2]  \r\n"
"	fmla	v0.4s,  v13.4s, v5.s[3]  \r\n"
"	fmla	v1.4s,  v13.4s, v6.s[3]  \r\n"
"	fmla	v2.4s,  v13.4s, v7.s[3]  \r\n"
"	fmla	v3.4s,  v13.4s, v8.s[3]  \r\n"
"	fmla	v4.4s,  v13.4s, v9.s[3]  \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
if constexpr (RScale && (RScaleBlend || Blend) && !ReC) {
asm volatile(
"ld1   {v5.4s, v6.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v5.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v5.s[1]       \r\n"
"fmul    v2.4s,  v2.4s,  v5.s[2]       \r\n"
"fmul    v3.4s,  v3.4s,  v5.s[3]       \r\n"
"fmul    v4.4s,  v4.4s,  v6.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6");
}
if constexpr(Load) {
if constexpr(FstIter && RScaleBlend) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v5.4s}, [%[addr_c0]] \r\n"
"ld1    {v6.4s}, [%[addr_c1]] \r\n"
"ld1    {v7.4s}, [%[addr_c2]] \r\n"
"ld1    {v8.4s}, [%[addr_c3]] \r\n"
"ld1    {v9.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v5.4s,  v10.s[0]       \r\n"
"fmla    v1.4s,  v6.4s,  v10.s[1]       \r\n"
"fmla    v2.4s,  v7.4s,  v10.s[2]       \r\n"
"fmla    v3.4s,  v8.4s,  v10.s[3]       \r\n"
"fmla    v4.4s,  v9.4s,  v11.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11");
}
else {
if constexpr(ReC) {
asm volatile(
"ld1    {v5.4s}, [%[addr_itm0]] \r\n"
"ld1    {v6.4s}, [%[addr_itm1]] \r\n"
"ld1    {v7.4s}, [%[addr_itm2]] \r\n"
"ld1    {v8.4s}, [%[addr_itm3]] \r\n"
"ld1    {v9.4s}, [%[addr_itm4]] \r\n"
:
: [addr_itm0] "r" (itm+1*0),
[addr_itm1] "r" (itm+1*1),
[addr_itm2] "r" (itm+1*2),
[addr_itm3] "r" (itm+1*3),
[addr_itm4] "r" (itm+1*4)
: "v5", "v6", "v7", "v8", "v9");
}
else {
asm volatile(
"ld1    {v5.4s}, [%[addr_c0]] \r\n"
"ld1    {v6.4s}, [%[addr_c1]] \r\n"
"ld1    {v7.4s}, [%[addr_c2]] \r\n"
"ld1    {v8.4s}, [%[addr_c3]] \r\n"
"ld1    {v9.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v5", "v6", "v7", "v8", "v9");
}
asm volatile(
"fadd     v0.4s, v5.4s,  v0.4s \r\n"
"fadd     v1.4s, v6.4s,  v1.4s \r\n"
"fadd     v2.4s, v7.4s,  v2.4s \r\n"
"fadd     v3.4s, v8.4s,  v3.4s \r\n"
"fadd     v4.4s, v9.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
}
if constexpr (RScale && !((RScaleBlend || Blend) && !ReC)) {
asm volatile(
"ld1   {v5.4s, v6.4s}, [%[addr_scale]] \r\n"
"fmul    v0.4s,  v0.4s,  v5.s[0]       \r\n"
"fmul    v1.4s,  v1.4s,  v5.s[1]       \r\n"
"fmul    v2.4s,  v2.4s,  v5.s[2]       \r\n"
"fmul    v3.4s,  v3.4s,  v5.s[3]       \r\n"
"fmul    v4.4s,  v4.4s,  v6.s[0]       \r\n"
:
: [addr_scale] "r" (rscale)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6");
}
if constexpr(!RScaleBlend && Blend && Itm2Res && ReC) {
asm volatile(
"ld1    {v5.4s}, [%[addr_c0]] \r\n"
"ld1    {v6.4s}, [%[addr_c1]] \r\n"
"ld1    {v7.4s}, [%[addr_c2]] \r\n"
"ld1    {v8.4s}, [%[addr_c3]] \r\n"
"ld1    {v9.4s}, [%[addr_c4]] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v5", "v6", "v7", "v8", "v9");
asm volatile(
"fadd     v0.4s, v5.4s,  v0.4s \r\n"
"fadd     v1.4s, v6.4s,  v1.4s \r\n"
"fadd     v2.4s, v7.4s,  v2.4s \r\n"
"fadd     v3.4s, v8.4s,  v3.4s \r\n"
"fadd     v4.4s, v9.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4");
}
if constexpr(!Blend && RScaleBlend && Itm2Res && ReC) {
asm volatile(
"ld1   {v10.4s, v11.4s}, [%[addr_scale_blend]] \r\n"
"ld1    {v5.4s}, [%[addr_c0]] \r\n"
"ld1    {v6.4s}, [%[addr_c1]] \r\n"
"ld1    {v7.4s}, [%[addr_c2]] \r\n"
"ld1    {v8.4s}, [%[addr_c3]] \r\n"
"ld1    {v9.4s}, [%[addr_c4]] \r\n"
"fmla    v0.4s,  v5.4s,  v10.s[0]       \r\n"
"fmla    v1.4s,  v6.4s,  v10.s[1]       \r\n"
"fmla    v2.4s,  v7.4s,  v10.s[2]       \r\n"
"fmla    v3.4s,  v8.4s,  v10.s[3]       \r\n"
"fmla    v4.4s,  v9.4s,  v11.s[0]       \r\n"
:
: [addr_scale_blend]  "r" (rscale_blend+0),
[addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11");
}
if constexpr(RBias) {
asm volatile(
"ld1   {v5.4s, v6.4s}, [%[addr_bias]] \r\n"
"dup    v7.4s, v5.s[0]               \r\n"
"dup    v8.4s, v5.s[1]               \r\n"
"dup    v9.4s, v5.s[2]               \r\n"
"dup    v10.4s, v5.s[3]               \r\n"
"dup    v11.4s, v6.s[0]               \r\n"
"fadd     v0.4s, v0.4s,  v7.4s \r\n"
"fadd     v1.4s, v1.4s,  v8.4s \r\n"
"fadd     v2.4s, v2.4s,  v9.4s \r\n"
"fadd     v3.4s, v3.4s,  v10.4s \r\n"
"fadd     v4.4s, v4.4s,  v11.4s \r\n"
:
: [addr_bias] "r" (rbias)
: "v0", "v0", "v1", "v1", "v2", "v2", "v3", "v3", "v4", "v4", "v5", "v5", "v6", "v6", "v7", "v7", "v8", "v8", "v9", "v9", "v10", "v10", "v11");
}
if constexpr(ReLU) {
asm volatile(
"mov     w9, #0                \r\n"
"dup    v5.4s, w9             \r\n"
"fmax    v0.4s, v5.4s,  v0.4s \r\n"
"fmax    v1.4s, v5.4s,  v1.4s \r\n"
"fmax    v2.4s, v5.4s,  v2.4s \r\n"
"fmax    v3.4s, v5.4s,  v3.4s \r\n"
"fmax    v4.4s, v5.4s,  v4.4s \r\n"
:
:
: "v0", "v1", "v2", "v3", "v4", "v5", "w9");
}
if constexpr(ReC && !Itm2Res) {
asm volatile(
"str     s0, [%[addr_itm],   0] \r\n"
"str     s1, [%[addr_itm],   4] \r\n"
"str     s2, [%[addr_itm],   8] \r\n"
"str     s3, [%[addr_itm],   12] \r\n"
"str     s4, [%[addr_itm],   16] \r\n"
:
: [addr_itm] "r" (itm): "memory");}
else {
asm volatile(
"str     s0, [%[addr_c0],   0] \r\n"
"str     s1, [%[addr_c1],   0] \r\n"
"str     s2, [%[addr_c2],   0] \r\n"
"str     s3, [%[addr_c3],   0] \r\n"
"str     s4, [%[addr_c4],   0] \r\n"
:
: [addr_c0] "r" (c+ldc*0),
[addr_c1] "r" (c+ldc*1),
[addr_c2] "r" (c+ldc*2),
[addr_c3] "r" (c+ldc*3),
[addr_c4] "r" (c+ldc*4)
: "memory");}
}
};


#endif  // __aarch64

#endif  // GEMM_ROWMAJOR_NOTRANS_KERNELS_5X12_HPP_
