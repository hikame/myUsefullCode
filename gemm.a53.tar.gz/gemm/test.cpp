#include <iomanip>
#include <iostream>
#include <math.h>

#include "duration.hpp"
#include "gemm_algo.hpp"

using namespace std;
static inline void gemm_check(const int m, const int n, const int k,
                              const float *a, const int lda, const float *b,
                              const int ldb, float *c, const int ldc,
                              bool relu) {

  for (int i = 0; i < m; i++) {
    for (int j = 0; j < n; j++) {
      float val = 0.0f;
      for (int l = 0; l < k; l++) {
        val += a[lda * i + l] * b[ldb * l + j];
      }
      if (relu) {
        val = std::max(0.0f, val);
      }
      c[ldc * i + j] = val;
    }
  }
}

int main() {

  for (int p = 32; p < 256; p += 2) {
    int m = p;
    int n = p;
    int k = p;
    std::vector<float> A(m * k);
    std::vector<float> B(k * n);
    std::vector<float> C(m * n);
    std::vector<float> C_check(m * n);

    for (auto &item : A) {
      item = (rand() % 255) / 255.f;
    }
    for (auto &item : B) {
      item = (rand() % 255) / 255.f;
    }
    for (auto &item : C) {
      item = 0;
    }
    for (auto &item : C_check) {
      item = 0;
    }

    auto func =
        gemm_rowmajor_notrans::GEMM<float, float, float, float, float,
                                    CortexA53, false, false, false, 8, 12>::Run;

    Duration tt;
    func(m, n, k, A.data(), k, B.data(), n, C.data(), n, nullptr, nullptr,
         nullptr);
    func(m, n, k, A.data(), k, B.data(), n, C.data(), n, nullptr, nullptr,
         nullptr);

    int iter = 2;
    tt.start();
    for (int i = 0; i < iter; ++i) {
      func(m, n, k, A.data(), k, B.data(), n, C.data(), n, nullptr, nullptr,
           nullptr);
    }
    tt.end();

    double ops = 2.f * m * n * k;
    std::cout << "M : " << setw(4) << m << "  ";
    std::cout << "N : " << setw(4) << n << "  ";
    std::cout << "K : " << setw(4) << k << "  ";
    std::cout << "Ops : " << setw(5) << setiosflags(ios::fixed)
              << setprecision(2) << ops / 1e6 << " M "
              << "  \t\t";
    std::cout << "Duration : " << setw(5) << setiosflags(ios::fixed)
              << setprecision(2) << tt.getDuration() / iter << "  ";
    std::cout << "Gflops : " << setw(5) << setiosflags(ios::fixed)
              << setprecision(2) << (ops / 1e6) / (tt.getDuration() / iter)
              << " \tVS\t ";

    gemm_check(m, n, k, A.data(), k, B.data(), n, C_check.data(), n, false);
    gemm_check(m, n, k, A.data(), k, B.data(), n, C_check.data(), n, false);

    tt.start();
    for (int i = 0; i < iter; ++i) {
      gemm_check(m, n, k, A.data(), k, B.data(), n, C_check.data(), n, false);
    }
    tt.end();

    bool flag = false;
    for (int i = 0; i < m * n; ++i) {
      if (fabs(C[i] - C_check[i]) / fabs(C_check[i]) > 1e-5) {
        flag = true;
        std::cout << "C : " << C[i] << " "
                  << "C_check : " << C_check[i] << std::endl;
        break;
      }
      // if(i < 20) {
      //  std::cout << "C : " << C[i] << " " << "C_check : " << C_check[i] <<
      //  std::endl;
      //}
    }
    if (flag) {
      std::cout << "!!!!!Result is wrong!!!!!!" << std::endl;
    }

    std::cout << "Check Duration : " << setw(5) << setiosflags(ios::fixed)
              << setprecision(2) << tt.getDuration() / iter << "  ";
    std::cout << "Check Gflops : " << setw(5) << setiosflags(ios::fixed)
              << setprecision(2) << (ops / 1e6) / (tt.getDuration() / iter)
              << std::endl;
    ;
  }

  return 0;
}
